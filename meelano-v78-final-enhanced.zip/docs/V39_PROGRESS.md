# MeeLano V39 — Resilient AI Media & Script Fallback

## Purpose
V39 prevents video production from hard-stopping when the primary video AI provider is disabled, exhausted, unavailable, rate-limited, or a remote video job fails.

## Pipeline
Creative/brief → AI media intelligence → primary video provider → local scripted renderer fallback → Media Library → quality check → Creative review → Draft/Approval → platform publisher.

## Fallback behavior
- Primary OpenAI video generation is attempted when configured.
- On provider failure/expiry/unavailability, the system automatically analyzes available creative + technical media metadata using the existing multi-provider text AI failover.
- A local FFmpeg renderer converts the Creative storyboard/script into multiple vertical scenes, concatenates them into MP4, and can optionally mux a supplied audio asset.
- If FFmpeg is unavailable on shared hosting, the job is NOT marked permanently failed. It remains queued with exponential backoff and `deferred_fallback`, so installing/enabling a renderer later allows the same job to continue.
- No external command is executed with unescaped user-controlled paths.

## AI analysis
The analysis contract covers hook strength, narrative structure, scene plan, shot types, transitions, effects, on-screen text, music direction, sound design, pacing, platform adaptations, compliance risks, and reuse opportunities. Technical facts are separated from recommendations; the system never claims to have observed pixels/audio it did not receive.

## Shared hosting reality
cPanel shared hosting does not guarantee FFmpeg or permission to execute it. Therefore V39 detects availability at runtime instead of assuming it. `MEELANO_FFMPEG_PATH` and `MEELANO_FFPROBE_PATH` can point to approved binaries supplied by the hosting provider.
