# V66 — Production Observability & Queue Reliability

## Delivered
- `ProductionObservabilityService` for runtime, database, required-extension, schema, queue and stale-processing checks.
- Persisted snapshots in `system_observability_snapshots`.
- Protected API endpoints: `system_observability`, `system_observability_run`, `system_observability_recent`.
- `cron/observability_watchdog.php` for scheduled health snapshots and fail-safe admin alerts.
- `system.observability` and `system.observability.run` permissions.
- Admin Command Center observability card.

## Safety
- No secrets are returned by observability endpoints.
- Provider calls are not faked; this layer reports local readiness and queue state.
- Notification failures are swallowed so monitoring cannot take down the application.
- Missing optional GD is a warning; required runtime extensions remain failures.

## QA
- V66 deterministic checks: 10/10 PASS.
- PHP lint: 0 errors.
- API action cases: 135 unique, 0 duplicates.
- Existing V55/V59/V60/V64/V65 suites remain part of the release QA process.
