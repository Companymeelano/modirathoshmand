# MeeLano V45 — Unified Product Ad + AI Live Social Video Director

V45 is a merged continuation of V43 + V44. It preserves Custom Mockup Precision while adding the Live Social Video Director.

## Added
- Preserved V43 Custom Mockup Engine and Product Ad Studio.
- AI Live Social Video Director with OpenAI Sora 2, Gemini Veo 3.1, and configurable Runway chain.
- Dynamic per-provider re-analysis using Product Catalog, SEO, Pricing, Inventory, Campaign, Caption, Creative, Social Calendar and Content Performance context.
- Product source image passed to OpenAI as `input_reference` when present, to Gemini as image input, and to Runway as `promptImage` when a public signed media URL is available.
- Manual Director Override persisted per job.
- Current-platform-aware dimensions and Runway image-to-video ratios.
- 3D loader and live polling UI.
- Migration 039 avoids the V43 migration-number collision.

## Verification
- PHP lint all files.
- API duplicate-case scan.
- Secret-pattern scan.
- ZIP integrity.
- Provider calls are not claimed as live-tested without configured production credentials.
