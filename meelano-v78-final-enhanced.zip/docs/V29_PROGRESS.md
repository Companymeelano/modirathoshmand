# MeeLano V29 — Instagram Analytics & Content Performance

- Added Instagram account-level Insights snapshots with raw-response retention.
- Added per-media performance snapshots for recent Instagram media.
- Added graceful handling for metric/API availability differences: unavailable metrics do not fail the whole sync.
- Added RBAC permissions: `social.instagram.analytics`, `social.instagram.analytics.sync`.
- Added API actions: `instagram_analytics`, `instagram_analytics_sync`.
- Added cron: `cron/instagram_analytics_sync.php` (6-hour cadence).
- Added Admin dashboard rendering for Instagram Reach, Views, Interactions, Likes and Comments where returned by the API.
- Kept Instagram publishing and OAuth boundaries unchanged; V29 does not falsely claim Instagram OAuth is implemented.
- Uses configurable `META_GRAPH_VERSION` (default v25.0) and official HTTPS Graph API only.
