# V68 — Backup Manifest, Restore Readiness & Dead Letter Recovery

Adds cryptographic backup artifact manifests (hash + HMAC metadata), restore-readiness checks, a publish Dead Letter Queue, bounded safe replay, incident-safe watchdogs, and admin/API permissions.

Replay never publishes directly: it only moves an eligible quarantined job back to `Retrying`; provider execution remains in the existing publishing pipeline. Automatic replay is intentionally not enabled.

Backup manifests never copy or expose backup contents. APP_KEY is used only as an HMAC key; secrets are not returned by APIs.
