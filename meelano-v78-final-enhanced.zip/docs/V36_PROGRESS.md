# MeeLano V36 — AI Campaign & Content Calendar Autopilot

## Implemented
- AI Campaign Plan grounded in V35 Strategy + Content Briefs.
- Persisted Campaigns and scheduled slots.
- Platform-aware cadence, brief rotation, A/B variant rotation and evidence-based timing when available.
- Conflict avoidance against existing social content workflow times.
- Draft creation from campaign slots; publishing is never automatic.
- RBAC permissions for read/run/draft operations.
- API: `ai_campaigns`, `ai_campaign_calendar`, `ai_campaign_run`, `ai_campaign_drafts`.
- Cron: `cron/ai_campaign_calendar.php`.
- Admin operational section for Campaign generation, refresh and Draft creation.

## Guardrails
- Maximum generated calendar range: 62 days.
- AI output is strict JSON and cannot invent metrics, causal claims or outcome guarantees.
- Missing timing evidence falls back to 12:00 UTC.
- Campaign generation creates planned slots only. Draft creation is a separate explicit action.
- No direct auto-publish is performed by the autopilot.
