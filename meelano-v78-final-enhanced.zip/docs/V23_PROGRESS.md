# MeeLano V23 — Social Webhook Reliability

- Added signed TikTok webhook verification using `TikTok-Signature` timestamp + HMAC-SHA256 with the app client secret.
- Added idempotent `social_webhook_events` inbox with a unique `(platform,event_id)` key.
- Added `/api/?action=social_tiktok_webhook` public HTTPS callback endpoint.
- Added handling for official Content Posting events: complete, failed, inbox delivered, publicly available, and no longer publicly available.
- Webhook endpoint returns HTTP 200 after acceptance and ignores duplicate deliveries safely.
- Publishing jobs are updated from provider events without exposing secrets or raw exceptions.
- V22 polling remains available as a fallback because TikTok supports both status polling and webhooks.

Production prerequisite: configure the TikTok app webhook callback URL and `TIKTOK_CLIENT_SECRET` in the server environment; test against TikTok's developer portal test event before enabling live traffic.
