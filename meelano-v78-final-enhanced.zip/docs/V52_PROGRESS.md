# MeeLano V52 — Autonomous Creative Learning Engine

V52 adds a deterministic, evidence-weighted creative learning layer over the real social performance and A/B experiment data already collected by MeeLano.

## What it learns
- Platform-specific strategy / Variant performance
- Hook style performance
- CTA style performance
- Media format performance
- Published-hour signals
- Recency-weighted evidence

## Guardrails
- Minimum 2 observations before a factor becomes an active recommendation.
- Small samples are shrunk toward a 50-point baseline.
- Recent observations have higher weight.
- Recommendations are explicitly treated as correlations/observations, not causal claims.
- No viral / Explore / FYP guarantee is made.

## Integration
- `AICreativeLearningService` persists snapshots and factor evidence.
- `AIVideoVariantOrchestratorService` consumes learning hints alongside live trend signals.
- API: `social_ai_learning`, `social_ai_learning_list`, `social_ai_learning_run`.
- Cron: `cron/ai_creative_learning.php`.
- Admin: Autonomous Creative Learning Engine panel.

## Data sources
- `social_content_performance`
- `social_content_experiments`
- `social_content_experiment_variants`
- `social_contents.metadata` when available

V52 also corrects the V51 packaging issue: the release archive is rooted at the application files and does not contain an extra `v50/` directory.
