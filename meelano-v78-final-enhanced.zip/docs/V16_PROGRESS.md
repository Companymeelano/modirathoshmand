# MeeLano V16 — AI Provider Engine

## Implemented
- Real server-side AI provider adapter layer; no browser-exposed provider secrets.
- OpenAI Responses API adapter.
- Gemini generateContent REST adapter.
- Anthropic Messages adapter.
- OpenAI-compatible adapter for DeepSeek, GapGPT and compatible gateways.
- Provider/model priority and failover on timeout/429/5xx.
- Token/latency/provider request ID usage logging.
- Encrypted provider secret columns with APP_KEY support; legacy plaintext is only a fallback for migration compatibility and should be rotated into encrypted storage.
- Provider connectivity test endpoint.
- Read-only Business Copilot context layer with explicit limitation against arbitrary SQL execution.
- AI permissions and tool audit table.

## Official API basis
- OpenAI Responses API is the current recommended primitive in OpenAI's official quickstart.
- Gemini supports server-side REST `generateContent` with an API key header.
- DeepSeek documents OpenAI-compatible `/chat/completions` and Responses API compatibility.

## Not claimed complete
- Tool/function execution that mutates orders, prices, inventory or payments is intentionally not enabled yet. Those actions require an approval workflow and will be implemented in the next AI governance phase.
- Provider secret management endpoint writes encrypted values to `api_key_enc` / `api_secret_enc` and clears legacy plaintext columns.
