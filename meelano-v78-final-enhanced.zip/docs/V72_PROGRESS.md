# MeeLano V72 — Performance Engineering

## Added
- `PerformanceMetricsService`: request latency, HTTP status, memory peak, recent samples, p50/p95/p99, error rate.
- Queue throughput snapshot for social publishing jobs.
- Schema-aware index advisor using `information_schema` (recommendations only; no automatic destructive index creation).
- Migration `057_v72_performance_metrics.sql`.
- Performance watchdog cron with admin notifications for degraded latency/error throughput.
- Safe CLI load-test harness using `curl_multi_*`; only runs against an explicitly supplied `LOADTEST_URL`.
- Admin Performance Center.
- Fixed V69 incident timeline query to use `metadata_json`, matching the recovery-event schema.

## Production notes
- Performance metrics are sampled on every request after migration 057 exists; before migration they fail closed.
- No automatic index creation is performed. Validate recommendations with `EXPLAIN` against real production workload before adding indexes.
- Load-test harness is opt-in and must target an environment you own/control.
