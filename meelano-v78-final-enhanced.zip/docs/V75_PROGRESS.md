# MeeLano V75 — Adaptive Query Cache & Queue Optimization

- Refactored cache locking to public, encapsulated `CacheService` APIs; removed Reflection from `IntelligentCacheService`.
- Added generation-aware named `QueryCacheService` with a strict allowlist of read-only query definitions.
- Added `CacheInvalidationService` for product, inventory, shipping, social, categories and dashboard namespaces.
- Added queue health/optimization recommendations; it is recommendation-only and does not mutate production worker settings.
- Fixed API dispatcher so `system_cache*` and `system_queue*` actions reach the system route group.
- Added migration 060 and permissions.
- Added V75 cache/lock regression test.
