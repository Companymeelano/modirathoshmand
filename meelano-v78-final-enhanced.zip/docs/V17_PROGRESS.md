# MeeLano V17 — Social Command Center Foundation

- Added social account vault with encrypted access/refresh token fields.
- Added social content records, OAuth state storage, and analytics snapshot schema.
- Added platform adapter contract and explicit unsupported-adapter behavior; no fake publishing.
- Added official TikTok Content Posting API Direct Post adapter for video/photo URL publishing.
- Added queue processing with atomic job claiming, retry/backoff for retryable provider errors, and failure isolation.
- Added API endpoints for account management, queueing, and worker execution.
- Added social permissions and marketing/admin role mappings.
- TikTok integration follows current official Content Posting API requirements: creator info is queried before direct post; Direct Post uses `video.publish`; photo direct posting uses the content init endpoint. Unverified clients can be restricted to private visibility.
- YouTube/Instagram/Facebook/LinkedIn/X/Pinterest/Telegram/WhatsApp/Threads/Reddit are deliberately not faked here; their adapters remain explicit until their official authorization/publishing contracts are implemented and tested.
