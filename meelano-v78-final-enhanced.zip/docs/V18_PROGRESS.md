# MeeLano V18 — Admin Operations & Integrity

V18 adds a real server-rendered admin operations shell and a database-backed dashboard. It also hardens social token storage and improves AI provider schema compatibility with legacy installations.

## Included
- `/admin/` authenticated admin shell
- `admin_dashboard` API with real order/customer/product/inventory/social/AI KPIs
- PWA manifest + service worker
- Refresh-token encryption for social accounts
- TikTok content validation cleanup
- AI provider/model column compatibility discovery for older schema variants
- Migration `014_v18_admin_social_integrity.sql`
- Public version marker updated to V18

## Explicitly not claimed
- Full OAuth flows for every social provider
- Analytics synchronization for every platform
- Universal social publishing across all networks
- Provider-specific payment signature verification
- Final production QA against a live customer database

TikTok Direct Post currently supports video and photo publishing through its official Content Posting API; the integration in this release remains intentionally limited to the implemented server-side paths and does not pretend to support unimplemented upload modes. TikTok's current documentation requires creator-info querying and the appropriate publishing scope, and unaudited clients are restricted to private visibility. See official docs for current requirements.
