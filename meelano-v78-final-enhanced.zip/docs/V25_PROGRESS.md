# MeeLano V25 — Social Media Library & Approval Calendar

## Delivered
- Persistent social media asset library with SHA-256 deduplication.
- Secure multipart upload for approved video/image MIME types, 500 MB hard application limit, server-controlled storage path and non-executable file permissions.
- Content workflow: Draft → Pending Approval → Approved/Rejected.
- Approval creates a real `social_publish_jobs` record; publishing remains handled by the existing provider worker.
- Calendar listing API with optional date window.
- RBAC permissions for media management, calendar access/write and approval.
- Audit events for upload, draft creation, submission, approval and rejection.

## Important production note
PHP/web-server upload limits (`upload_max_filesize`, `post_max_size`, request timeout) must also permit the configured media size. The application refuses files over 500 MB regardless of server settings.

## V25 APIs
- `social_media_upload`
- `social_media_assets`
- `social_calendar`
- `social_content_draft`
- `social_content_submit`
- `social_content_approve`
- `social_content_reject`

## QA
- PHP syntax linted for all project PHP files.
- Bootstrap include smoke test performed without database credentials.
- Duplicate API case check performed for new endpoints.
- Secret pattern scan performed.
