# MeeLano V21 — Social Analytics & Publishing Status

- Added TikTok profile/video analytics synchronization using official Display API scopes.
- Persists follower/following/video counts plus sampled recent video engagement/views in `social_analytics_snapshots`.
- Added TikTok Content Posting status polling for queued/completed jobs.
- Added `social_analytics_sync.php` cron worker with a six-hour sync window.
- Added permission gates for analytics sync and post-status polling.
- No unsupported social platform is represented as implemented.
