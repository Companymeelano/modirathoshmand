# MeeLano V46 — Resilient Live Video Director

V46 continues V45 and hardens the video generation pipeline.

- Preserves Custom Mockup Precision (V43) and Live Social Video Director.
- Provider chain is configurable: Gemini/Veo, Runway, OpenAI, then local FFmpeg fallback.
- Provider priority can be configured with `extra_config.video_priority`.
- Local fallback is synchronous and produces a deterministic MP4 when all hosted video providers fail/unavailable.
- OpenAI, Gemini and Runway remain real integrations; no fake success is generated for unavailable remote providers.
- Product source image reference remains supported for OpenAI/Gemini/Runway paths.
- Manual Director overrides remain persisted and are merged into the live decision at generation time.
- Live context includes catalog/product, SEO, pricing, inventory, campaign, calendar, performance, caption and creative context.

## Current provider note

OpenAI's current video API documentation states that the Sora API is scheduled to shut down on September 24, 2026. MeeLano therefore does not hard-code OpenAI as the permanent primary provider; priority is configurable and Gemini/Runway can be preferred.
