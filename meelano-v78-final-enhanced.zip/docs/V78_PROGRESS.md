# MeeLano V78 — Unified System Brain

V78 introduces a guarded decision layer over Incident Recovery, Security Hardening, Disaster Recovery, Deployment Safety and V77 Autonomous Performance.

## Guardrails
- Recommendation/guarded-autonomy first.
- No arbitrary SQL.
- No automatic index changes.
- No automatic deployment mutations.
- No automatic social publishing/replay.
- One low-risk reconciliation action is executable with dedicated RBAC.
- Fingerprint + 30-minute cooldown prevents repeated decision loops.
- Every persisted run stores cycle id, risk score, signals and plan JSON.

## APIs
- `system_brain`
- `system_brain_run`
- `system_brain_recent`
- `system_brain_decisions`
- `system_brain_execute`

## Cron
`cron/unified_system_brain.php`

## Database
`063_v78_unified_system_brain.sql`
