# MeeLano V22 — Social Publishing State & Operations

## Implemented
- TikTok publish jobs remain `Processing` after API initialization instead of being falsely marked `Completed`.
- Added provider status persistence (`provider_status`, `provider_checked_at`).
- Added `SocialPublishingStatusService` with TikTok status polling and provider→internal status mapping.
- Added `cron/social_status_sync.php` for scheduled reconciliation of in-flight posts.
- Added `social_post_status` and `social_status_sync` API actions with permissions.
- Removed duplicate `social_accounts` API switch case.
- Cleaned admin CSRF token retrieval so it is fetched once per request.

## Provider behavior
TikTok statuses are mapped as follows:
- `PROCESSING_UPLOAD`, `PROCESSING_DOWNLOAD`, `SEND_TO_USER_INBOX` → `Processing`
- `PUBLISH_COMPLETE` → `Completed`
- `FAILED` → `Failed`

The implementation follows TikTok's current guidance to poll the status endpoint or consume status webhooks so the application does not report completion merely because initialization returned a `publish_id`.

## Not claimed as production-complete
Real provider publishing still requires a configured/approved TikTok developer app, valid OAuth scopes, verified URL properties for `PULL_FROM_URL`, and an actual provider-connected account. These cannot be validated offline with fabricated credentials.
