# MeeLano V24 — TikTok Media Transfer

## Delivered
- Added server-controlled local `FILE_UPLOAD` path for TikTok Direct Post.
- Added MIME detection and path traversal protection.
- Added 10 MiB chunked PUT upload using TikTok's returned `upload_url`.
- Kept `PULL_FROM_URL` as the default when `media_path` is absent.
- Added `social_media_uploads` audit/telemetry table and `social.media.upload` permission.
- Existing provider-status polling and webhook flow remain the source of final publication state.

## Operational note
TikTok's current Direct Post documentation requires `creator_info/query` before initialization, supports `FILE_UPLOAD` and `PULL_FROM_URL`, and says the returned upload URL is valid for one hour. Final publication remains asynchronous and must be tracked by publish status/webhooks.

## API
- `social_status_sync` and `social_status_one` are available to authorized operators.
- `social_publish_jobs` remains `Processing` until TikTok reports a terminal provider status.
