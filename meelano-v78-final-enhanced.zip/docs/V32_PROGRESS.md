# MeeLano V32 — Unified Content Performance

Adds a normalized cross-platform content performance layer for available Instagram and LinkedIn per-content insights. Computes engagement rate, a bounded performance score, platform summaries, top content, best publishing hours, and rule-based recommendations. TikTok account snapshots remain available but are not falsely converted to per-content records because current stored TikTok data is aggregate. YouTube analytics is not synthesized until real channel analytics data is available.

New migration: 027_v32_content_performance.sql
New service: SocialContentPerformanceService.php
New API: social_performance, social_performance_sync
New cron: cron/social_performance_sync.php
