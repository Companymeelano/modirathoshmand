# Architecture

The legacy single-file dashboard remains a presentation layer. New production logic belongs in `app/` and is exposed through `api/`.

Flow: HTTP -> Request/CSRF -> Auth/RBAC -> Controller/API -> Service -> Repository/DB -> Response.

Business-critical inventory and order mutations use database transactions and row locks. Optional integrations are isolated from core commerce.

## V58 additions
- `app/Core/Container.php`: lazy reflection-based dependency container.
- `app/Services/SocialPublishingRollbackService.php`: explicit publish rollback state machine.
- `cron/social_publish_rollback.php`: queued rollback worker.
