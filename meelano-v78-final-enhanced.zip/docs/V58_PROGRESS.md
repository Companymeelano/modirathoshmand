# MeeLano V58 — DI Core + Publishing Rollback

- Added reflection-based lazy `Container` with singleton/bind support.
- Wired PDO/Audit into the container and migrated rollback routes to container resolution.
- Added `SocialPublishingRollbackService` with explicit state machine:
  `Queued/Retrying -> Cancelled`, `Processing/Completed/RollbackFailed -> RollbackRequested -> RollingBack -> RolledBack|RollbackFailed`.
- Official rollback implementations: YouTube `videos.delete`; LinkedIn UGC post delete. Other platforms fail closed with manual-review guidance.
- Added rollback event audit table and permissions.
- Added rollback API endpoints and cron worker.
- No external deletion is claimed for platforms whose official delete capability is not implemented.
