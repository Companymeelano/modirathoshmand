# MeeLano V14 — Commerce Integrity & Pricing Governance

## Implemented
- Fixed real product price column mismatch: `products.sale_price_retail`.
- Reservation ledger is now item-aware; order item IDs are persisted and commit/release transitions are scoped to the matching reservation.
- Added return inventory action ledger with idempotency protection.
- Returning an approved/received item to `restocked` now atomically increases warehouse stock and creates an `inventory_movements` IN record.
- Return requests require an explicit order item and prevent cumulative return quantity from exceeding the purchased quantity.
- Added pricing approval workflow: propose → review approve/reject → apply.
- Applied prices are written to `product_price_history` and `product_price_approvals`.
- Added `pricing.approve` and `returns.manage` permissions.
- Added centralized request IDs and safer JSON response request tracing.
- API now maps validation/domain errors to 422 and database failures to a generic 500 response without exposing SQL details.

## Important boundary
Payment gateway adapters and social/AI network publishing are intentionally not faked. They remain adapter-driven until official provider contracts are implemented and tested.

## Next major version
V15 should focus on real payment orchestration/idempotent webhook verification, richer customer RFM/CLV intelligence, shipping-rule evaluation, and the production admin UI/API consumption layer.
