# MeeLano V27 — YouTube OAuth & Publishing

- Added official Google OAuth 2.0 server-side flow for YouTube.
- Added encrypted access/refresh token storage using existing SocialTokenCipher.
- Added YouTube channel discovery through channels.list (mine=true).
- Added refresh worker for expiring YouTube access tokens.
- Added resumable video upload through YouTube Data API videos.insert.
- Added YouTube adapter and unified SocialAdapterFactory integration.
- Added YouTube capabilities to SocialPublishingOrchestrator.
- Added permissions and cron worker.
- YouTube privacy defaults to private unless explicitly configured; production/public availability depends on Google project/API quota and authorization state.
