# MeeLano v8 Progress

## Completed
- Removed nested PDO transaction failure between OrderService and InventoryService.
- Inventory reservation/release now support outer-transaction participation.
- Corrected inventory movement compatibility with the existing enum (`adjust`) and stores operation semantics in `reference_type`/`note`.
- Added real login endpoint using `password_verify()` and session regeneration.
- Added login history and DB-backed IP/username rate limiting.
- Added CSRF token endpoint for authenticated frontend clients.
- Added middleware entry points for authentication and permissions.
- Order creation now records `user_id` and audit event.

## Safety
All new SQL is additive/idempotent. No DROP/TRUNCATE/DELETE migration operations are introduced.

## Still not final production
Payment adapters, refund/return state machine, complete RBAC tables, CRM, full AI provider adapters/failover, official social adapters, notifications, analytics, installer and comprehensive automated QA remain to be implemented.
