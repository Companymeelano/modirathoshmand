# MeeLano V35 — AI Content Strategy & Brief Engine

## Implemented
- AIContentStrategyService grounded in V32 performance + V33 intelligence + V34 experiments.
- Strict JSON AI contract and validation; no fabricated metrics/causal claims/virality guarantees.
- Persisted strategy snapshots in `social_ai_content_strategies`.
- Persisted executable briefs in `social_content_briefs` with A/B variants, KPI, hypothesis, timing, risks and visual direction.
- API: `ai_content_strategy`, `ai_content_strategy_run`, `social_content_brief`, `social_content_brief_draft`.
- Draft creation feeds the existing SocialContentWorkflowService and stays in Draft/Approval workflow; it does not auto-approve or publish.
- Cron: `cron/ai_content_strategy.php`.
- RBAC: `social.ai_strategy`, `social.ai_strategy.run`, `social.ai_strategy.draft`.
- Admin dashboard section for strategy generation and brief-to-draft conversion.

## Workflow
Performance → AI Intelligence → Experiments → AI Strategy → Content Brief → A/B Variants → Draft → Approval → Publish → Analytics → Experiment Learning.

## Guardrails
- AI has no unrestricted SQL/tool access.
- Audience recommendations remain generic unless evidence is present.
- No claims of Explore/FYP/viral placement.
- Platform publishing remains behind existing official API adapters and approval controls.
