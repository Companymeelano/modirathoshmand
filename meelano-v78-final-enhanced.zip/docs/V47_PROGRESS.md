# MeeLano V47 — Video Quality Gate

V47 continues V46 and adds a deterministic server-side quality gate after every successful hosted/local video render.

## Quality checks
- MP4 container
- supported video codec
- minimum 720px on the smaller dimension
- platform aspect ratio: 9:16 Instagram/TikTok, 16:9 YouTube, 1:1 LinkedIn
- duration sanity window and proximity to the requested duration
- frame-rate sanity check (23–61 fps)

## Failover behavior
A provider that returns a video which fails the quality gate is treated as failed for that attempt. The Director can continue to the next configured provider. Quality results are persisted on the job.

## Persistence
`social_ai_video_director_jobs` now stores:
- `quality_status`
- `quality_score`
- `quality_json`

Migration: `040_v47_video_quality_gate.sql`.

This gate validates technical output. It does not claim to predict Explore/FYP/reach, and it does not replace platform policy/compliance review.
