# MeeLano V64 — Production Hardening & Integration Contract Suite

V64 shifts the project from feature accumulation toward production reliability.

## Added
- Production integration-contract test suite in `tests/v64_integration.php`.
- Architecture/route/DI/security contract checks.
- Social publishing idempotency/recovery contract checks.
- Provider capability contract checks.
- Required module and migration contract checks.
- Optional live MySQL smoke test gated by `MEELANO_TEST_DB_NAME`.
- Live smoke test uses a transaction and rolls back fixtures; it does not publish to external providers.

## Safety
- No production DB is touched unless explicit `MEELANO_TEST_DB_*` variables are supplied.
- No real social API publish is performed by the test suite.
- Failures never expose SQL credentials or stack traces in the test assertions.

## QA target
- PHP lint across the complete source tree.
- Deterministic integration-contract suite.
- Optional live MySQL schema/idempotency verification.
