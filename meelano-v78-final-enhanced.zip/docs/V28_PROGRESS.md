# MeeLano V28 — Instagram Publishing

- Added official Instagram Professional Account publisher adapter.
- Supports single image posts and Reels through the container -> publish flow.
- Requires `instagram_business_content_publish` and a valid Instagram Professional Account ID.
- Added signed, expiring public media endpoint so Meta can fetch server-hosted assets without exposing `/uploads` directly.
- Added `social.instagram.oauth` and `social.instagram.publish` permissions.
- Added Instagram to Unified Publishing capability registry.
- `APP_BASE_URL` and `META_GRAPH_VERSION` are configurable; default Graph version is v25.0.
- Carousel remains intentionally disabled until its multi-container orchestration is implemented and tested.
