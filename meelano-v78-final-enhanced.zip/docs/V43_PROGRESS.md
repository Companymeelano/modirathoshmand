# MeeLano V43 — Custom Mockup Precision Engine

## Added
- Product Ad Studio now has two explicit modes: `catalog` and `custom_mockup`.
- Custom Mockup accepts a user-owned mockup image and a real product source image.
- AI Vision analyzes the mockup to detect the exact product placement quadrilateral, canvas geometry, confidence, rotation/perspective hints, occlusion hints and protected regions.
- Low-confidence placement (<0.75) is rejected instead of guessed.
- ImageMagick/Convert performs deterministic perspective compositing of the real product image into the detected surface, preserving the user's mockup branding/logo/background rather than regenerating the mockup.
- Mockup output is fit to target platform canvas without stretching the original mockup.
- Product image and mockup image are never stored as base64 in project JSON.
- Added mockup upload + automatic attachment endpoint and admin controls.
- Added permissions for custom mockup use/upload.
- Product catalog/SEO/pricing/inventory/campaign/performance context remains available in catalog mode and is also supplied to AI art direction in custom-mockup mode for copy/strategy decisions.

## Safety / correctness
- No promise of pixel-perfect AI generation; precision is achieved by AI geometry analysis + deterministic compositing.
- Existing logo/text/branding in the user's mockup is treated as authoritative and protected.
- No fallback to a guessed placement when AI confidence is insufficient.
- SVG output remains flagged as not platform-safe.
