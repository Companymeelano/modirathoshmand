# MeeLano V26 — Unified Social Publishing Orchestrator

## Delivered
- Introduced `SocialPublishingOrchestrator` as a single fan-out layer between approved content and platform/account targets.
- Added `social_publish_targets` for per-account status, external post ID and error tracking.
- Added idempotent target queueing: active Queued/Processing/Retrying jobs are not duplicated for the same content/account pair.
- Added capability registry so unsupported platform/media combinations fail explicitly instead of producing fake publishes.
- Added batch approval/publish endpoint and target inspection endpoint.
- Kept TikTok as the only real publisher adapter currently enabled.
- Existing TikTok FILE_UPLOAD/PULL_FROM_URL/photo/status/webhook flows remain intact.

## API
- `social_content_approve_batch`
- `social_content_targets`
- `social_capabilities`

## Migration
- `021_v26_social_targets.sql`

## Important
- Other platforms are intentionally not marked as supported until their official OAuth/API publishing flows are implemented and tested.
- Real provider credentials, app approval and production HTTPS callbacks remain deployment prerequisites.
