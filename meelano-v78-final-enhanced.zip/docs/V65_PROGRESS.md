# MeeLano V65 — Full E2E Test Harness & Production Audit

V65 builds on V64 and moves the verification layer from isolated contracts toward an executable end-to-end simulation of the critical business lifecycle.

## Added
- `tests/v65_e2e.php`: deterministic end-to-end lifecycle simulation without touching a production database or external social providers.
- `scripts/production_audit.php`: deployment-time environment and security readiness audit; reports PASS/WARN/FAIL without printing secrets.
- Admin API query-string parsing fix: existing calls such as `ai_social_video_jobs&limit=20` now preserve query parameters instead of encoding the `&` into the `action` value.
- Admin version label updated to V65.

## E2E coverage
- Order state machine: valid progression and invalid transitions.
- Publishing idempotency normalization.
- Publishing stale-job recovery decision.
- Social capability gating and rollback capability.
- Video quality fail-closed behavior for missing artifacts.
- Provider lifecycle service presence.
- API route-group and DI invariants.

## Safety
- No production database is accessed by the deterministic E2E suite.
- No real social API publish is executed.
- Production audit never prints environment secrets.
- Live database tests remain explicitly gated by `MEELANO_TEST_DB_*` in the V64 suite.

## Deployment note
PHP 8.3.33 is the current PHP 8.3 security release as of this build date; deploy on a supported, patched PHP 8.3 build rather than an older 8.3 patch release.
