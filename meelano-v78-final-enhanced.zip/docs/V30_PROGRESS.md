# MeeLano V30 — LinkedIn Publishing

## Implemented
- LinkedIn OAuth 2.0 authorization-code flow with state persistence and encrypted tokens.
- OIDC `/v2/userinfo` identity lookup and member URN persistence.
- Official LinkedIn Posts API adapter using `/rest/posts` and configurable `LINKEDIN_VERSION`.
- Text and link publishing through the unified social queue.
- LinkedIn token refresh worker.
- RBAC permissions for OAuth, publishing, and analytics placeholder.
- Unified capability registry and adapter factory integration.
- Admin connect button.
- Idempotent existing queue architecture reused; no scraping or browser automation.

## Deliberate scope
Image/video LinkedIn publishing and LinkedIn analytics are not claimed complete in V30. They require additional official API permissions/products and media APIs; they remain explicit future capabilities rather than fake UI.

## Official API basis
LinkedIn documents OAuth 2.0 member authorization and the Posts API. The Posts API replaces the legacy `ugcPosts` endpoint and requires the `Linkedin-Version` and `X-Restli-Protocol-Version` headers. Member publishing uses `w_member_social`.
