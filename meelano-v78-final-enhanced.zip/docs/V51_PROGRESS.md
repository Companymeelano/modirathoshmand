# MeeLano V51 — Real-Time Trend Intelligence

Adds an evidence-first trend intelligence layer for Instagram, TikTok, YouTube and LinkedIn.

- Configurable HTTPS JSON trend feed via `TREND_SIGNAL_URL` and optional `TREND_SIGNAL_TOKEN`.
- No scraping, fake engagement, ranking manipulation or algorithm guarantees.
- 72-hour signal window with momentum/evidence/confidence/source.
- AI normalization and recommendation with strict JSON validation.
- Performance + experiments + future calendar are included in the live snapshot.
- Fresh trend context is injected into multi-variant video generation.
- Cron: `cron/ai_trend_intelligence.php`.
- New permissions: `social.ai_trends`, `social.ai_trends.run`.
