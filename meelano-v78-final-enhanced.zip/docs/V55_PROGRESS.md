# MeeLano V55 — Adaptive Variant Intelligence

## Implemented
- `VariantWeightCalibrationService`: harvests only genuinely linked video-variant performance observations and calibrates technical/identity/platform-fit weights with OLS after at least 30 observations.
- `ai_scoring_weights`: persisted platform/category weights, sample count, R², correlation and rationale.
- `StrategyBanditService`: Thompson Sampling with Beta posteriors over six strategy arms, category/platform aware, with 15% exploration.
- `ai_strategy_arms`: persisted alpha/beta, pulls, wins/losses and last reward.
- Variant batches now select strategies through the bandit while retaining trend + creative-learning hints.
- Batch completion records winner/loser outcomes per platform without inventing outcomes for unplayed arms.
- APIs: `ai_scoring_weights_report`, `ai_scoring_weights_run`, `strategy_performance`, `strategy_bandit_run`.
- Cron: `variant_weight_calibration.php`, `strategy_bandit_maintenance.php`.
- Deterministic/Monte-Carlo sanity tests for Beta sampling and OLS.

## Data integrity rule
Performance rows are eligible for calibration only when a real linkage to a variant job is present (currently via `metadata.job_id` and existing variant batch/job records). Unlinked performance is skipped rather than guessed.

## Model behavior
- No calibration occurs below 30 linked observations.
- OLS coefficients are normalized to positive weights summing to 1.
- Until enough evidence exists, V54 defaults remain 35% technical / 45% identity / 20% platform fit.
- Bandit exploration is explicit and bounded; it does not claim causal or viral outcomes.
