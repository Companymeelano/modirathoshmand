<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$pdo=Database::pdo();
$svc=$container->make(AICampaignCalendarService::class);
$admin=$pdo->query("SELECT id FROM users WHERE status='active' AND role IN ('admin','manager') ORDER BY id LIMIT 1")->fetch(PDO::FETCH_ASSOC);
if(!$admin){echo "No active operator.\n";exit(0);}
$start=date('Y-m-d',strtotime('+1 day'));$end=date('Y-m-d',strtotime('+30 day'));
$check=$pdo->prepare("SELECT id FROM social_ai_campaigns WHERE status IN ('planned','active') AND start_date<=? AND end_date>=? ORDER BY id DESC LIMIT 1");$check->execute([$end,$start]);if($check->fetchColumn()){echo "Existing planned/active campaign overlaps the automation window; no duplicate generated.\n";exit(0);}
try{$r=$svc->generate(null,$start,$end,null,(int)$admin['id']);echo json_encode($r,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";}catch(Throwable $e){fwrite(STDERR,$e->getMessage()."\n");exit(1);}
