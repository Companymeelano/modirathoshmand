<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/bootstrap.php';
$pdo=$container->make(PDO::class);$svc=$container->make(PublishDeadLetterService::class);
try{$q=$pdo->query("SELECT j.id,j.platform,j.attempts,j.recovery_count,j.last_error FROM social_publish_jobs j LEFT JOIN social_publish_dead_letters d ON d.job_id=j.id WHERE j.status='RecoveryRequired' AND d.id IS NULL ORDER BY j.id LIMIT 50");$n=0;foreach($q->fetchAll(PDO::FETCH_ASSOC) as $j){$svc->quarantine((int)$j['id'],'recovery required after repeated/unsafe publish state',$j,0);$n++;}echo json_encode(['ok'=>true,'quarantined'=>$n],JSON_UNESCAPED_UNICODE).PHP_EOL;}catch(Throwable $e){error_log('[MeeLano] dead letter watchdog failed: '.$e->getMessage());http_response_code(1);echo json_encode(['ok'=>false,'error'=>'watchdog failed']).PHP_EOL;}
