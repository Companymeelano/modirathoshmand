<?php
declare(strict_types=1);
require_once __DIR__.'/../config/bootstrap.php';
$pdo=Database::pdo();
$svc=$container->make(AIContentStrategyService::class);
try{$r=$svc->generate(null,null,null);echo json_encode($r,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;}catch(Throwable $e){http_response_code(1);echo json_encode(['ok'=>false,'error'=>$e->getMessage()],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;exit(1);}
