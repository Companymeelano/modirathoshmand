<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
$pdo=Database::pdo();$audit=new Audit($pdo);$svc=$container->make(AIMediaUnderstandingService::class);
$limit=max(1,min(10,(int)($argv[1]??3)));$q=$pdo->query("SELECT id FROM social_media_assets WHERE status='ready' AND mime_type LIKE 'video/%' AND id NOT IN (SELECT asset_id FROM social_media_understanding) ORDER BY id ASC LIMIT {$limit}");$out=[];foreach($q->fetchAll(PDO::FETCH_COLUMN) as $id){try{$out[]=$svc->analyze((int)$id,0,[]);}catch(Throwable $e){$out[]=['asset_id'=>(int)$id,'status'=>'failed','error'=>mb_substr($e->getMessage(),0,200)];}}echo json_encode(['ok'=>true,'processed'=>$out],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
