<?php
declare(strict_types=1);
require_once __DIR__.'/../config/bootstrap.php';
try{$svc=$container->make(SocialContentPerformanceService::class);$r=$svc->sync(0);echo json_encode(['status'=>'ok','data'=>$r],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;}catch(Throwable $e){http_response_code(1);echo json_encode(['status'=>'error','message'=>'content performance sync failed'],JSON_UNESCAPED_UNICODE).PHP_EOL;exit(1);}
