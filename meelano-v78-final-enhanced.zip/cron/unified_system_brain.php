<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
try {
    $result=$container->make(UnifiedSystemBrainService::class)->analyze(true);
    echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
} catch(Throwable $e) { fwrite(STDERR,"MeeLano V78 Brain failed: ".$e->getMessage().PHP_EOL); exit(1); }
