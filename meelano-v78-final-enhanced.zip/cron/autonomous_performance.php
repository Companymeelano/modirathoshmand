<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
try {
    $svc=$container->make(AutonomousPerformanceService::class);
    $plan=$svc->plan();
    $id=$svc->persist($plan);
    fwrite(STDOUT,json_encode(['ok'=>true,'id'=>$id,'status'=>$plan['status']??'unknown','priority'=>$plan['priority']??'normal','actions'=>count($plan['actions']??[])],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL);
} catch(Throwable $e) {
    fwrite(STDERR,'autonomous_performance failed: '.$e->getMessage().PHP_EOL);
    exit(1);
}
