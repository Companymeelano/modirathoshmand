<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$pdo=Database::pdo();
$svc=$container->make(SocialPublishingStatusService::class);
$r=$svc->syncDue((int)($argv[1]??25));
echo 'checked='.count($r).PHP_EOL;
foreach($r as $x)echo json_encode($x,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
