<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$pdo=Database::pdo();
try{echo json_encode(($container->make(LinkedInOAuthService::class))->refreshDue(50),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;}catch(Throwable $e){fwrite(STDERR,$e->getMessage().PHP_EOL);exit(1);}
