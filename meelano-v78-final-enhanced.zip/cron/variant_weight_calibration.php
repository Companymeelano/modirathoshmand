<?php
declare(strict_types=1);$root=dirname(__DIR__);require $root.'/config/bootstrap.php';$svc=$container->make(VariantWeightCalibrationService::class);echo json_encode(['harvest'=>$svc->harvest(),'calibration'=>$svc->calibrate()],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
