<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$svc=$container->make(AISocialVideoDirectorService::class);
header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>true,'results'=>$svc->worker(4)],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
