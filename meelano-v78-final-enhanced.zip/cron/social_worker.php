<?php
declare(strict_types=1);require __DIR__.'/../config/bootstrap.php';$pdo=Database::pdo();$svc=$container->make(SocialCommandService::class);$r=$svc->processDue(25);echo 'processed='.count($r).PHP_EOL;
