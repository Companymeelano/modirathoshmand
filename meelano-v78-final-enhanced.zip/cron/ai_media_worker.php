<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
$svc=$container->make(AIMediaProductionService::class);
$limit=max(1,min(5,(int)($argv[1]??3)));
try{ $result=$svc->worker($limit); echo json_encode(['ok'=>true,'processed'=>$result],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL; }catch(Throwable $e){fwrite(STDERR,'ai_media_worker failed: '.get_class($e).' '.substr($e->getMessage(),0,300).PHP_EOL);exit(1);}
