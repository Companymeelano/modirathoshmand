<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$pdo=Database::pdo();
$svc=$container->make(AITrendIntelligenceService::class);
foreach(['instagram','tiktok','youtube','linkedin'] as $platform){try{$r=$svc->refresh($platform,null,null);echo $platform.' '.(($r['ok']??false)?'ok':'skipped').PHP_EOL;}catch(Throwable $e){error_log('trend '.$platform.' failed: '.$e->getMessage());}}
