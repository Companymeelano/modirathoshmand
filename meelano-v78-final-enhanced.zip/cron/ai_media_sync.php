<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
$pdo=Database::pdo();$svc=$container->make(AIMediaProductionService::class);$q=$pdo->query("SELECT id FROM social_ai_media_jobs WHERE media_type='video' AND status='processing' AND provider_job_id IS NOT NULL ORDER BY updated_at ASC LIMIT 5");$out=[];foreach($q->fetchAll(PDO::FETCH_COLUMN) as $id){try{$out[]=$svc->syncVideo((int)$id,0);}catch(Throwable $e){$out[]=['id'=>(int)$id,'status'=>'sync_failed'];}}echo json_encode(['ok'=>true,'processed'=>$out],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
