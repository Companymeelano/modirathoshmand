<?php
declare(strict_types=1);
require dirname(__DIR__).'/config/bootstrap.php';
$svc=$container->make(PerformanceMetricsService::class);
$r=$svc->report((int)(getenv('PERF_WINDOW_MINUTES')?:60));
$q=$svc->queueThroughput();
$alerts=[];
if(($r['status']??'')==='ok' && (float)($r['p95_ms']??0)>1000)$alerts[]='p95 latency exceeds 1000ms';
if(($r['status']??'')==='ok' && (float)($r['error_rate']??0)>5)$alerts[]='5xx error rate exceeds 5%';
if(($q['available']??false) && (int)($q['processing']??0)>0 && (int)($q['completed_last_hour']??0)===0)$alerts[]='no completed publishing jobs in the last hour while processing exists';
if($alerts){try{$container->make(AdminNotificationService::class)->notify('system_performance_degraded','MeeLano performance alert',implode('; ',$alerts),null,null,'warning',['report'=>$r,'queue'=>$q]);}catch(Throwable){}}
echo json_encode(['ok'=>true,'report'=>$r,'queue'=>$q,'alerts'=>$alerts],JSON_UNESCAPED_UNICODE).PHP_EOL;
