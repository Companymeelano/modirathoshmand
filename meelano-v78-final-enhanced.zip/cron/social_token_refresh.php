<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
if(PHP_SAPI!=='cli'){http_response_code(403);exit('CLI only');}
try{$pdo=Database::pdo();$r=$container->make(SocialOAuthService::class);$out=$r->refreshDue(50);echo json_encode($out,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;}catch(Throwable $e){fwrite(STDERR,'MeeLano social token refresh failed: '. $e->getMessage().PHP_EOL);exit(1);}
