<?php
declare(strict_types=1);
require_once __DIR__.'/../config/bootstrap.php';
try {
 $svc=$container->make(PublishRecoveryService::class);
 $result=$svc->processRecovery((int)($_GET['limit']??25),0);
 header('Content-Type: application/json; charset=utf-8');
 echo json_encode(['ok'=>true,'result'=>$result],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch(Throwable $e) {
 http_response_code(500);header('Content-Type: application/json; charset=utf-8');
 echo json_encode(['ok'=>false,'error'=>'recovery_failed'],JSON_UNESCAPED_UNICODE);
 error_log('[MeeLano] publish recovery cron failed: '.$e->getMessage());
}
