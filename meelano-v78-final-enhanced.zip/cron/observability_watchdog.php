<?php
declare(strict_types=1);
require dirname(__DIR__).'/config/bootstrap.php';
$svc=$container->make(ProductionObservabilityService::class);$snap=$svc->snapshot();$id=$svc->persist($snap);
if(!$snap['healthy']){try{$container->make(AdminNotificationService::class)->notify('system_observability_degraded','MeeLano observability degraded','Production observability detected a degraded state.',null,null,'critical',['snapshot_id'=>$id,'queue'=>$snap['queue']]);}catch(Throwable $e){}}
echo json_encode(['ok'=>true,'snapshot_id'=>$id,'healthy'=>$snap['healthy']],JSON_UNESCAPED_UNICODE).PHP_EOL;
