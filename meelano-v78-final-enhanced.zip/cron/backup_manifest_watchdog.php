<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/bootstrap.php';
$svc=$container->make(BackupManifestService::class);try{$r=$svc->build();echo json_encode(['ok'=>in_array($r['status'],['pass','warn'],true),'result'=>$r],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;}catch(Throwable $e){error_log('[MeeLano] backup manifest watchdog failed: '.$e->getMessage());echo json_encode(['ok'=>false,'error'=>'watchdog failed']).PHP_EOL;exit(1);}
