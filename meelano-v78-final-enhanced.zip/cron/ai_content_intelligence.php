<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$pdo=Database::pdo();
$svc=$container->make(AIContentIntelligenceService::class);
foreach([null,'instagram','linkedin','tiktok','youtube'] as $platform){try{$r=$svc->analyze($platform,null);echo json_encode(['platform'=>$platform,'result'=>$r['status']??($r['ok']??false)],JSON_UNESCAPED_UNICODE).PHP_EOL;}catch(Throwable $e){echo json_encode(['platform'=>$platform,'error'=>mb_substr($e->getMessage(),0,300)],JSON_UNESCAPED_UNICODE).PHP_EOL;}}
