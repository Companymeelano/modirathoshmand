<?php
declare(strict_types=1);
require dirname(__DIR__).'/config/bootstrap.php';
$svc=$container->make(DisasterRecoveryService::class);$report=$svc->audit();$id=$svc->persist($report);
if($report['status']==='fail'){try{$container->make(AdminNotificationService::class)->notify('system_recovery_failure','MeeLano recovery audit failed','Disaster recovery audit detected a critical failure.',null,null,'critical',['report_id'=>$id]);}catch(Throwable $e){}}
echo json_encode(['ok'=>true,'report_id'=>$id,'status'=>$report['status']],JSON_UNESCAPED_UNICODE).PHP_EOL;
