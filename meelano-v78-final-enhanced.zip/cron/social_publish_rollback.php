<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$svc=$container->make(SocialPublishingRollbackService::class);
try { $result=$svc->processDue((int)(getenv('MEELANO_ROLLBACK_BATCH')?:10),0); echo json_encode(['ok'=>true,'processed'=>$result],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL; }
catch(Throwable $e){ error_log('[MeeLano] rollback cron: '.$e->getMessage()); echo json_encode(['ok'=>false,'error'=>'rollback worker failed'],JSON_UNESCAPED_UNICODE).PHP_EOL; exit(1); }
