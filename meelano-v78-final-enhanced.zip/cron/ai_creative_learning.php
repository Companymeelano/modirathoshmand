<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$pdo=Database::pdo();
$svc=$container->make(AICreativeLearningService::class);
$platforms=['instagram','tiktok','youtube','linkedin'];
$out=[];
foreach($platforms as $platform){try{$out[$platform]=$svc->run($platform,null,0,90);}catch(Throwable $e){$out[$platform]=['status'=>'failed','error'=>$e->getMessage()];}}
header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>true,'results'=>array_map(fn($x)=>is_array($x)&&isset($x['id'])?['snapshot_id'=>$x['id'],'confidence'=>$x['confidence'],'sample_count'=>$x['sample_count']]:$x,$out)],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
