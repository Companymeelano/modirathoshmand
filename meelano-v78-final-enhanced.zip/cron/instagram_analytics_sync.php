<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$pdo=Database::pdo();$svc=$container->make(InstagramAnalyticsService::class);
$q=$pdo->query("SELECT id FROM social_accounts WHERE platform='instagram' AND status='active' AND (last_sync_at IS NULL OR last_sync_at<=DATE_SUB(NOW(),INTERVAL 6 HOUR)) ORDER BY last_sync_at IS NULL DESC,last_sync_at ASC LIMIT 10");
foreach($q->fetchAll(PDO::FETCH_COLUMN) as $id){try{$svc->sync((int)$id,0);echo "synced:$id\n";}catch(Throwable $e){$pdo->prepare('UPDATE social_accounts SET last_error=?,updated_at=NOW() WHERE id=?')->execute([mb_substr($e->getMessage(),0,500),(int)$id]);echo "error:$id\n";}}
