<?php
declare(strict_types=1);
require dirname(__DIR__).'/config/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['app'=>'MeeLano Commerce OS','version'=>'v18','status'=>'ready','request_id'=>$_SERVER['HTTP_X_REQUEST_ID']??bin2hex(random_bytes(8))],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
