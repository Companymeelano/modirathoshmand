<?php
declare(strict_types=1);
$root=dirname(__DIR__);$pass=0;$warn=0;$fail=0;
function out(string $level,string $name,string $detail=''):void{global $pass,$warn,$fail;if($level==='PASS')$pass++;elseif($level==='WARN')$warn++;else $fail++;echo "{$level} {$name}".($detail!==''?": {$detail}":'')."\n";}

$php=PHP_VERSION;
out(version_compare($php,'8.3.0','>=' )?'PASS':'FAIL','PHP version',$php);
out(extension_loaded('pdo')?'PASS':'FAIL','PDO extension');
out(extension_loaded('openssl')?'PASS':'FAIL','OpenSSL extension');
out(extension_loaded('curl')?'PASS':'WARN','cURL extension',extension_loaded('curl')?'available':'required for external HTTP providers; enable on production host');
out(extension_loaded('mbstring')?'PASS':'WARN','mbstring extension',extension_loaded('mbstring')?'available':'required by several text/HTTP paths');
out(extension_loaded('fileinfo')?'PASS':'FAIL','fileinfo extension');
out(extension_loaded('gd')?'PASS':'WARN','GD extension','optional for pHash identity evidence');

foreach(['config','storage','uploads','database/migrations','cron'] as $d){$p=$root.'/'.$d;out(is_dir($p)?'PASS':'FAIL',"directory {$d}",is_dir($p)&&is_writable($p)?'exists+writable':(is_dir($p)?'exists':'missing'));}
$env=$root.'/.env';out(is_file($env)?'PASS':'WARN','.env file',is_file($env)?'present':'not present in package; configure environment at deployment');
$ht=$root.'/uploads/.htaccess';out(is_file($ht)?'PASS':'WARN','uploads protection',is_file($ht)?'htaccess present':'verify web-server upload execution blocking');

$secrets=[];
foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS)) as $f){if(!$f->isFile()||$f->getExtension()!=='php')continue;$txt=@file_get_contents($f->getPathname());if($txt===false)continue;if(preg_match('/AKIA[0-9A-Z]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/',$txt))$secrets[]=$f->getPathname();}
out(count($secrets)===0?'PASS':'FAIL','secret pattern scan',count($secrets).' suspicious PHP files');

$routes=glob($root.'/api/routes/*.php')?:[];$api='';foreach($routes as $f)$api.=file_get_contents($f);
preg_match_all("/case\s+['\"]([^'\"]+)['\"]\s*:/",$api,$m);$actions=array_values(array_unique($m[1]??[]));out(count($actions)>0?'PASS':'FAIL','route action discovery',count($actions).' actions discovered');

$ver=glob($root.'/database/migrations/*.sql')?:[];out(count($ver)>0?'PASS':'FAIL','migration inventory',count($ver).' SQL migrations');

$autoload=$root.'/app/Core/Autoloader.php';out(is_file($autoload)&&str_contains((string)file_get_contents($autoload),'spl_autoload_register')?'PASS':'FAIL','autoload contract');

$docs=$root.'/docs/V65_PROGRESS.md';out(is_file($docs)?'PASS':'FAIL','V65 documentation');

echo "RESULT pass={$pass} warn={$warn} fail={$fail}\n";exit($fail?1:0);
