<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
$report=$container->make(SecurityHardeningService::class)->audit();
echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
exit((int)$report['fail']>0?2:0);
