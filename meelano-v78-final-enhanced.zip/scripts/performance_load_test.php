<?php
declare(strict_types=1);
$url=getenv('LOADTEST_URL') ?: '';
$concurrency=max(1,min(50,(int)(getenv('LOADTEST_CONCURRENCY')?:5)));
$total=max($concurrency,min(500,(int)(getenv('LOADTEST_REQUESTS')?:50)));
if($url===''){fwrite(STDERR,"Set LOADTEST_URL to a safe test endpoint (e.g. health).\n");exit(2);}
if(!extension_loaded('curl')){fwrite(STDERR,"curl extension is required.\n");exit(2);}
$times=[];$codes=[];$done=0;
while($done<$total){$mh=curl_multi_init();$handles=[];$batch=min($concurrency,$total-$done);for($i=0;$i<$batch;$i++){$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>15,CURLOPT_FOLLOWLOCATION=>false]);curl_multi_add_handle($mh,$ch);$handles[]=$ch;}
$running=null;do{$m=curl_multi_exec($mh,$running);if($running)curl_multi_select($mh,0.2);}while($running&&$m===CURLM_OK);
foreach($handles as $ch){$times[]=(float)curl_getinfo($ch,CURLINFO_TOTAL_TIME)*1000;$codes[]=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_multi_remove_handle($mh,$ch);curl_close($ch);}$done+=$batch;curl_multi_close($mh);}
sort($times,SORT_NUMERIC);$n=count($times);$pct=fn($p)=>round($times[max(0,min($n-1,(int)ceil($p*$n)-1))],2);$ok=count(array_filter($codes,fn($c)=>$c>=200&&$c<400));
echo json_encode(['url'=>$url,'requests'=>$n,'concurrency'=>$concurrency,'success_rate'=>round($ok/max(1,$n)*100,2),'p50_ms'=>$pct(.5),'p95_ms'=>$pct(.95),'p99_ms'=>$pct(.99),'max_ms'=>round(max($times),2)],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES).PHP_EOL;
