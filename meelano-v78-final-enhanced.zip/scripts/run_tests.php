<?php
declare(strict_types=1);
$root=dirname(__DIR__); require $root.'/config/bootstrap.php';
$passed=0;$failed=0;function check(string $name,bool $ok):void{global $passed,$failed;if($ok){$passed++;echo "PASS $name\n";}else{$failed++;echo "FAIL $name\n";}}
$svc=new VideoQualityGateService(); $r=$svc->inspect('/definitely/missing.mp4','instagram'); check('quality missing file fails',$r['status']==='fail'&&$r['error_code']==='FILE_MISSING');
$rc=new ReflectionClass(AIProductIdentityService::class); $obj=$rc->newInstanceWithoutConstructor(); $m=$rc->getMethod('hamming'); $m->setAccessible(true); check('identity hamming 64',$m->invoke($obj,'0'.str_repeat('1',63),str_repeat('1',64))===1); check('identity score method exists',$rc->getMethod('scoreVariant')!==null);
echo "RESULT passed=$passed failed=$failed\n"; exit($failed?1:0);
