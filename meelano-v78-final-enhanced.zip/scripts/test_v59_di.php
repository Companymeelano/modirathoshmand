<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/Core/Container.php';
final class V59Leaf { public function __construct() {} }
final class V59Service { public function __construct(public V59Leaf $leaf) {} }
final class V59Singleton { public function __construct() {} }
final class V59CycleA { public function __construct(V59CycleB $b) {} }
final class V59CycleB { public function __construct(V59CycleA $a) {} }
$c=new Container();
$pass=0;$fail=0;
try { $a=$c->make(V59Service::class); echo $a->leaf instanceof V59Leaf ? "PASS reflection resolution\n" : "FAIL reflection resolution\n"; if($a->leaf instanceof V59Leaf)$pass++;else$fail++; } catch(Throwable $e){echo "FAIL reflection resolution: {$e->getMessage()}\n";$fail++;}
$c->singleton(V59Singleton::class, static fn()=>new V59Singleton());
try {$a=$c->make(V59Singleton::class);$b=$c->make(V59Singleton::class);$ok=$a===$b;echo ($ok?'PASS':'FAIL')." singleton\n";$pass+=$ok?1:0;$fail+=$ok?0:1;}catch(Throwable $e){echo "FAIL singleton: {$e->getMessage()}\n";$fail++;}
$c->instance('value',123);try{$ok=$c->make('value')===123;echo ($ok?'PASS':'FAIL')." instance binding\n";$pass+=$ok?1:0;$fail+=$ok?0:1;}catch(Throwable $e){echo "FAIL instance binding\n";$fail++;}
try{$c->make(V59CycleA::class);echo "FAIL circular dependency guard\n";$fail++;}catch(Throwable $e){$ok=str_contains($e->getMessage(),'Circular dependency detected');echo ($ok?'PASS':'FAIL')." circular dependency guard\n";$pass+=$ok?1:0;$fail+=$ok?0:1;}
echo "RESULT passed={$pass} failed={$fail}\n";exit($fail?1:0);
