<?php
declare(strict_types=1);
require dirname(__DIR__).'/config/bootstrap.php';
function t(string $n,bool $ok):void{echo ($ok?'PASS ':'FAIL ').$n."\n";if(!$ok)exit(1);}
$r=new ReflectionClass(StrategyBanditService::class);$o=$r->newInstanceWithoutConstructor();$m=$r->getMethod('beta');$m->setAccessible(true);$x=[];for($i=0;$i<200;$i++)$x[]=$m->invoke($o,8,2);$avg=array_sum($x)/count($x);t('beta sampler range',min($x)>=0&&max($x)<=1);t('beta sampler mean',abs($avg-.8)<.08);
$w=new ReflectionClass(VariantWeightCalibrationService::class);$o2=$w->newInstanceWithoutConstructor();$m2=$w->getMethod('ols');$m2->setAccessible(true);$X=[];$y=[];for($i=1;$i<=40;$i++){$a=($i*7%41)/40;$b=($i*13%37)/36;$c=($i*17%31)/30;$X[]=[1,$a,$b,$c];$y[]=2+3*$a-2*$b+.5*$c;} $coef=$m2->invoke($o2,$X,$y);t('OLS solves coefficients',is_array($coef)&&count($coef)===4&&abs($coef[1]-3)<.02&&abs($coef[2]+2)<.02);
echo "RESULT passed=3 failed=0\n";
