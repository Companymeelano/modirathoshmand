<?php
declare(strict_types=1);
$root=dirname(__DIR__);$pass=0;$fail=0;
function ok(bool $x,string $m):void{global $pass,$fail;if($x){$pass++;echo "PASS $m\n";}else{$fail++;echo "FAIL $m\n";}}
$svc=$root.'/app/Services/IncidentRecoveryCenterService.php';$mig=$root.'/database/migrations/054_v69_incident_recovery_center.sql';$route=$root.'/api/routes/system.php';$idx=$root.'/api/index.php';$admin=$root.'/admin/index.php';
ok(is_file($svc),'incident service exists');
ok(is_file($mig),'V69 migration exists');
$src=file_get_contents($svc);$ms=file_get_contents($mig);$rs=file_get_contents($route);$is=file_get_contents($idx);$as=file_get_contents($admin);
ok(str_contains($src,'function reconcile')&&str_contains($src,'function acknowledge')&&str_contains($src,'function resolve'),'incident lifecycle methods exist');
ok(str_contains($src,'fingerprint=hash(\'sha256\''),'deterministic incident fingerprinting exists');
ok(str_contains($src,'critical')&&str_contains($src,'system_incident_critical'),'critical incident notification path exists');
ok(str_contains($ms,'CREATE TABLE IF NOT EXISTS system_incidents'),'incident table migration exists');
ok(str_contains($ms,"system.incidents.run")&&str_contains($ms,"system.incidents.manage"),'incident permissions exist');
foreach(['system_incidents','system_incidents_run','system_incident_ack','system_incident_resolve'] as $a) ok(str_contains($rs,"case '$a'"),"route $a exists");
ok(str_contains($is,"str_starts_with(\$action,'system_incident')"),'dispatcher maps incident actions');
ok(str_contains($as,'Incident & Recovery Center')&&str_contains($as,'v69IncidentRun'),'admin incident center exists');
if(in_array('sqlite',PDO::getAvailableDrivers(),true)){try{$db=new PDO('sqlite::memory:');$db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$x=new IncidentRecoveryCenterService($db);$o=$x->overview(5);ok(isset($o['summary'],$o['timeline'],$o['incidents']),'service degrades safely without MySQL schema');}catch(Throwable $e){ok(false,'service smoke test: '.$e->getMessage());}}else{echo "SKIP service smoke test: sqlite PDO driver unavailable\n";}
echo "RESULT passed=$pass failed=$fail\n";exit($fail?1:0);
