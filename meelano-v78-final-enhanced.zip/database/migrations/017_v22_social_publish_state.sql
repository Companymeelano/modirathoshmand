ALTER TABLE social_publish_jobs ADD COLUMN IF NOT EXISTS provider_status VARCHAR(80) NULL AFTER external_post_id;
ALTER TABLE social_publish_jobs ADD COLUMN IF NOT EXISTS provider_checked_at DATETIME NULL AFTER provider_status;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.status.sync','همگام‌سازی وضعیت انتشار اجتماعی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key='social.status.sync';
