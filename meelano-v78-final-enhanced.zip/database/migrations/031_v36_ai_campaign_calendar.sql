CREATE TABLE IF NOT EXISTS social_ai_campaigns (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 strategy_id BIGINT UNSIGNED NOT NULL,
 name VARCHAR(220) NOT NULL,
 objective VARCHAR(500) NOT NULL,
 theme TEXT NULL,
 content_pillars JSON NOT NULL,
 cadence JSON NOT NULL,
 platforms JSON NOT NULL,
 start_date DATE NOT NULL,
 end_date DATE NOT NULL,
 status ENUM('planned','active','completed','cancelled') NOT NULL DEFAULT 'planned',
 slot_count INT UNSIGNED NOT NULL DEFAULT 0,
 model_code VARCHAR(160) NULL,
 latency_ms INT UNSIGNED NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_saic_dates(start_date,end_date), INDEX idx_saic_status(status), INDEX idx_saic_strategy(strategy_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_ai_campaign_slots (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 campaign_id BIGINT UNSIGNED NOT NULL,
 brief_id BIGINT UNSIGNED NOT NULL,
 content_id BIGINT UNSIGNED NULL,
 platform VARCHAR(40) NOT NULL,
 scheduled_at DATETIME NOT NULL,
 timezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
 status ENUM('planned','draft_created','cancelled') NOT NULL DEFAULT 'planned',
 variant_key VARCHAR(40) NULL,
 metadata JSON NOT NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_saics_campaign_time(campaign_id,platform,scheduled_at),
 INDEX idx_saics_calendar(platform,scheduled_at,status), INDEX idx_saics_campaign(campaign_id), INDEX idx_saics_content(content_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.ai_campaign','مشاهده Campaign و تقویم AI','social'),
('social.ai_campaign.run','تولید Campaign و تقویم AI','social'),
('social.ai_campaign.draft','ساخت Draft از تقویم AI','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.ai_campaign','social.ai_campaign.run','social.ai_campaign.draft');
