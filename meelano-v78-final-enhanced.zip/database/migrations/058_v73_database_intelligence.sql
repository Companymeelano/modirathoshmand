CREATE TABLE IF NOT EXISTS system_cache_events (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 cache_key_hash CHAR(64) NOT NULL,
 event_type VARCHAR(20) NOT NULL,
 ttl_seconds INT UNSIGNED NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(id), KEY idx_cache_events_created(created_at), KEY idx_cache_events_key(cache_key_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.database_intelligence','تحلیل هوشمند پایگاه داده','system'),
('system.database_intelligence.run','اجرای تحلیل پایگاه داده','system');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_key IN ('system.database_intelligence','system.database_intelligence.run') WHERE r.name IN ('super_admin','admin');
