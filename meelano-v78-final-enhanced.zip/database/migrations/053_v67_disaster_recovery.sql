CREATE TABLE IF NOT EXISTS system_recovery_reports (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 status VARCHAR(20) NOT NULL,
 report_json JSON NOT NULL,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(id), KEY idx_recovery_status_created(status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.recovery','System Recovery Audit','system'),
('system.recovery.run','Run Recovery Audit','system');
