-- V54 brand safety, manual review and AI cost foundation
CREATE TABLE IF NOT EXISTS ai_provider_pricing (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 provider_code VARCHAR(80) NOT NULL, model_code VARCHAR(160) NOT NULL, unit_type VARCHAR(40) NOT NULL,
 price_per_unit DECIMAL(18,8) NOT NULL DEFAULT 0, currency VARCHAR(12) NOT NULL DEFAULT 'USD',
 is_active TINYINT(1) NOT NULL DEFAULT 1, updated_at DATETIME NOT NULL, created_at DATETIME NOT NULL,
 UNIQUE KEY uq_ai_provider_pricing(provider_code,model_code,unit_type), KEY idx_ai_provider_pricing_active(provider_code,is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS admin_notifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_code VARCHAR(100) NOT NULL, entity_type VARCHAR(100) NULL, entity_id BIGINT UNSIGNED NULL, severity VARCHAR(20) NOT NULL DEFAULT 'warning', title VARCHAR(255) NOT NULL, message TEXT NOT NULL, payload_json JSON NULL, delivered_at DATETIME NULL, created_at DATETIME NOT NULL, KEY idx_admin_notifications_created(created_at), KEY idx_admin_notifications_event(event_code,entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='social_ai_video_director_jobs' AND COLUMN_NAME='quality_status');
SET @s=IF(@c=0,'ALTER TABLE social_ai_video_director_jobs ADD COLUMN quality_status VARCHAR(32) NULL, ADD COLUMN quality_score INT NULL, ADD COLUMN quality_json LONGTEXT NULL','SELECT 1'); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='social_ai_video_director_jobs' AND COLUMN_NAME='estimated_cost_usd');
SET @s=IF(@c=0,'ALTER TABLE social_ai_video_director_jobs ADD COLUMN estimated_cost_usd DECIMAL(18,8) NULL, ADD COLUMN actual_cost_usd DECIMAL(18,8) NULL','SELECT 1'); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='social_ai_media_jobs' AND COLUMN_NAME='estimated_cost_usd');
SET @s=IF(@c=0,'ALTER TABLE social_ai_media_jobs ADD COLUMN estimated_cost_usd DECIMAL(18,8) NULL, ADD COLUMN actual_cost_usd DECIMAL(18,8) NULL','SELECT 1'); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='social_ai_video_identity_checks' AND COLUMN_NAME='reviewed_by');
SET @s=IF(@c=0,'ALTER TABLE social_ai_video_identity_checks ADD COLUMN reviewed_by BIGINT UNSIGNED NULL, ADD COLUMN reviewed_at DATETIME NULL','SELECT 1'); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @t=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='product_categories');
SET @s=IF(@t=1,(SELECT IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='product_categories' AND COLUMN_NAME='identity_confidence_threshold')=0,'ALTER TABLE product_categories ADD COLUMN identity_confidence_threshold DECIMAL(5,4) NOT NULL DEFAULT 0.7500','SELECT 1')),'SELECT 1'); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES ('social.ai_media.identity.review','بررسی دستی هویت محصول','social'),('social.ai_cost','گزارش هزینه AI','analytics');
INSERT IGNORE INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin') AND p.permission_key IN ('social.ai_media.identity.review','social.ai_cost');
