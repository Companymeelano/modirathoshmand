CREATE TABLE IF NOT EXISTS social_ai_video_variant_batches (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, product_id BIGINT UNSIGNED NOT NULL, campaign_id BIGINT UNSIGNED NULL, variant_count TINYINT UNSIGNED NOT NULL DEFAULT 2, status VARCHAR(20) NOT NULL DEFAULT 'queued', winner_json JSON NULL, created_by BIGINT UNSIGNED NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, KEY idx_vbatch_product(product_id), KEY idx_vbatch_status(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_ai_video_variant_batch_items (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, batch_id BIGINT UNSIGNED NOT NULL, job_id BIGINT UNSIGNED NOT NULL, platform VARCHAR(30) NOT NULL, variant_index TINYINT UNSIGNED NOT NULL, strategy_json JSON NULL, created_at DATETIME NOT NULL, UNIQUE KEY uq_vbatch_job(job_id), KEY idx_vbatch_platform(batch_id,platform), KEY idx_vbatch_variant(batch_id,variant_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
