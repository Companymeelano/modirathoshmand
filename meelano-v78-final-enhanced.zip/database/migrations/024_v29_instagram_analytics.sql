CREATE TABLE IF NOT EXISTS social_instagram_insights (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 account_id BIGINT UNSIGNED NOT NULL,
 captured_at DATETIME NOT NULL,
 period VARCHAR(20) NOT NULL DEFAULT 'lifetime',
 metrics JSON NOT NULL,
 raw_response JSON NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_ig_insights_account_time(account_id,captured_at),
 INDEX idx_ig_insights_period(period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_instagram_media_insights (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 account_id BIGINT UNSIGNED NOT NULL,
 external_media_id VARCHAR(255) NOT NULL,
 captured_at DATETIME NOT NULL,
 media_type VARCHAR(40) NULL,
 media_product_type VARCHAR(40) NULL,
 permalink TEXT NULL,
 caption TEXT NULL,
 published_at DATETIME NULL,
 metrics JSON NOT NULL,
 raw_response JSON NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_ig_media_snapshot(account_id,external_media_id,captured_at),
 INDEX idx_ig_media_account_time(account_id,captured_at),
 INDEX idx_ig_media_external(external_media_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.instagram.analytics','مشاهده Analytics اینستاگرام','social'),
('social.instagram.analytics.sync','همگام‌سازی Analytics اینستاگرام','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.instagram.analytics','social.instagram.analytics.sync');
