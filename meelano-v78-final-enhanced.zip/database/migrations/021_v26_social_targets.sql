CREATE TABLE IF NOT EXISTS social_publish_targets (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 content_id BIGINT UNSIGNED NOT NULL,
 account_id BIGINT UNSIGNED NOT NULL,
 job_id BIGINT UNSIGNED NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'Queued',
 external_post_id VARCHAR(255) NULL,
 last_error VARCHAR(500) NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(id),
 UNIQUE KEY uq_spt_content_account(content_id,account_id),
 UNIQUE KEY uq_spt_job(job_id),
 KEY idx_spt_status(status),
 KEY idx_spt_account(account_id),
 KEY idx_spt_content(content_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.publish.batch','انتشار چندحسابی شبکه‌های اجتماعی','social'),
('social.targets.read','مشاهده مقصدهای انتشار اجتماعی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.publish.batch','social.targets.read');
