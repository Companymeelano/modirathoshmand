-- V60: publishing idempotency, leases, attempt ledger and fail-safe recovery
ALTER TABLE social_publish_jobs
 ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(128) NULL AFTER content_id,
 ADD COLUMN IF NOT EXISTS claim_token CHAR(32) NULL AFTER attempts,
 ADD COLUMN IF NOT EXISTS claim_expires_at DATETIME NULL AFTER claim_token,
 ADD COLUMN IF NOT EXISTS last_attempt_at DATETIME NULL AFTER claim_expires_at,
 ADD COLUMN IF NOT EXISTS recovery_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER last_attempt_at;

ALTER TABLE social_publish_jobs
 ADD UNIQUE KEY uq_spj_account_idempotency(account_id,idempotency_key),
 ADD KEY idx_spj_recovery(status,claim_expires_at),
 ADD KEY idx_spj_attempts(account_id,last_attempt_at);

CREATE TABLE IF NOT EXISTS social_publish_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 attempt_no INT UNSIGNED NOT NULL,
 status VARCHAR(40) NOT NULL,
 idempotency_key VARCHAR(128) NULL,
 started_at DATETIME NOT NULL,
 finished_at DATETIME NULL,
 provider_status VARCHAR(80) NULL,
 external_post_id VARCHAR(255) NULL,
 error_code VARCHAR(80) NULL,
 error_message VARCHAR(500) NULL,
 response_json JSON NULL,
 created_at DATETIME NOT NULL,
 UNIQUE KEY uq_spa_job_attempt(job_id,attempt_no),
 KEY idx_spa_job(job_id),
 KEY idx_spa_status(status),
 KEY idx_spa_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_publish_recovery_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 event_type VARCHAR(60) NOT NULL,
 from_status VARCHAR(40) NULL,
 to_status VARCHAR(40) NULL,
 reason VARCHAR(500) NULL,
 metadata_json JSON NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 KEY idx_spre_job(job_id),
 KEY idx_spre_type(event_type),
 KEY idx_spre_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.publish.recovery','مشاهده و بازیابی صف انتشار اجتماعی','social'),
('social.publish.recovery.run','اجرای بازیابی صف انتشار اجتماعی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.publish.recovery','social.publish.recovery.run');
