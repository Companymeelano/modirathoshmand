ALTER TABLE ai_providers ADD COLUMN IF NOT EXISTS api_key_enc MEDIUMTEXT NULL AFTER api_key;
ALTER TABLE ai_providers ADD COLUMN IF NOT EXISTS api_secret_enc MEDIUMTEXT NULL AFTER api_secret;
CREATE TABLE IF NOT EXISTS ai_provider_health (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 ai_provider_id BIGINT UNSIGNED NOT NULL,
 window_started_at DATETIME NOT NULL,
 requests INT UNSIGNED NOT NULL DEFAULT 0,
 successes INT UNSIGNED NOT NULL DEFAULT 0,
 failures INT UNSIGNED NOT NULL DEFAULT 0,
 rate_limited INT UNSIGNED NOT NULL DEFAULT 0,
 avg_latency_ms INT UNSIGNED NOT NULL DEFAULT 0,
 last_error VARCHAR(500) NULL,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_ai_health_provider_window(ai_provider_id,window_started_at),
 INDEX idx_ai_health_provider(ai_provider_id),
 CONSTRAINT fk_ai_health_provider FOREIGN KEY(ai_provider_id) REFERENCES ai_providers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS ai_tool_audit (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 tool_name VARCHAR(100) NOT NULL,
 mode ENUM('read','suggest','approval_required','execute') NOT NULL DEFAULT 'read',
 input_payload JSON NULL,
 output_payload JSON NULL,
 approval_required TINYINT(1) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_ai_tool_user(user_id),INDEX idx_ai_tool_name(tool_name),INDEX idx_ai_tool_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('ai.use','استفاده از موتور هوش مصنوعی','ai'),
('ai.providers.test','تست Providerهای هوش مصنوعی','ai'),
('ai.providers.manage','مدیریت کلیدهای Providerهای هوش مصنوعی','ai'),
('ai.copilot','دستیار کسب‌وکار هوشمند','ai');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin','manager','marketing','support') AND p.permission_key IN ('ai.use','ai.copilot');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin') AND p.permission_key IN ('ai.providers.test','ai.providers.manage');
