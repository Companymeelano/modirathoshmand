CREATE TABLE IF NOT EXISTS social_media_uploads (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 platform VARCHAR(40) NOT NULL,
 account_id BIGINT UNSIGNED NULL,
 job_id BIGINT UNSIGNED NULL,
 publish_id VARCHAR(255) NULL,
 upload_mode VARCHAR(30) NOT NULL,
 media_type VARCHAR(30) NOT NULL,
 file_size BIGINT UNSIGNED NOT NULL,
 chunk_size INT UNSIGNED NULL,
 total_chunks INT UNSIGNED NULL,
 uploaded_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
 status VARCHAR(30) NOT NULL DEFAULT 'completed',
 error_message VARCHAR(500) NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 PRIMARY KEY(id), KEY idx_smu_job(job_id), KEY idx_smu_account(account_id), KEY idx_smu_publish(publish_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES ('social.media.upload','آپلود رسانه شبکه‌های اجتماعی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key='social.media.upload';
