CREATE TABLE IF NOT EXISTS social_ai_video_identity_checks (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 status VARCHAR(20) NOT NULL,
 score INT NOT NULL DEFAULT 0,
 result_json JSON NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 KEY idx_identity_job (job_id),
 KEY idx_identity_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_ai_video_variant_scores (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 score INT NOT NULL DEFAULT 0,
 status VARCHAR(20) NOT NULL,
 score_json JSON NULL,
 created_at DATETIME NOT NULL,
 UNIQUE KEY uq_variant_job (job_id),
 KEY idx_variant_score (score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET @c:= (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='social_ai_video_director_jobs' AND COLUMN_NAME='identity_status');
SET @s:=IF(@c=0,'ALTER TABLE social_ai_video_director_jobs ADD COLUMN identity_status VARCHAR(20) NULL, ADD COLUMN identity_score INT NULL, ADD COLUMN identity_json JSON NULL, ADD COLUMN variant_score INT NULL, ADD COLUMN variant_status VARCHAR(20) NULL, ADD COLUMN variant_json JSON NULL','SELECT 1'); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
