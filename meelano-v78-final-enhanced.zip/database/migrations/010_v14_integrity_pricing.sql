CREATE TABLE IF NOT EXISTS return_inventory_actions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 return_id BIGINT UNSIGNED NOT NULL,
 order_item_id BIGINT UNSIGNED NOT NULL,
 product_id BIGINT UNSIGNED NOT NULL,
 variant_id BIGINT UNSIGNED NULL,
 warehouse_id BIGINT UNSIGNED NOT NULL,
 quantity DECIMAL(15,3) NOT NULL,
 status ENUM('pending','applied','failed') NOT NULL DEFAULT 'pending',
 applied_by BIGINT UNSIGNED NULL,
 applied_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_return_item(return_id,order_item_id),
 INDEX idx_ria_status(status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('pricing.approve','تایید و اعمال قیمت','pricing'),
('returns.manage','مدیریت مرجوعی','orders');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin') AND p.permission_key IN ('pricing.approve','returns.manage');
