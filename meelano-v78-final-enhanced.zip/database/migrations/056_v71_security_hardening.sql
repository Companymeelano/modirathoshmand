CREATE TABLE IF NOT EXISTS security_audit_runs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  status VARCHAR(20) NOT NULL,
  score DECIMAL(5,2) NOT NULL DEFAULT 0,
  pass_count INT NOT NULL DEFAULT 0,
  warn_count INT NOT NULL DEFAULT 0,
  fail_count INT NOT NULL DEFAULT 0,
  report_json JSON NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY(id), KEY idx_security_audit_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.security','مشاهده ممیزی امنیت','system'),('system.security.run','اجرای ممیزی امنیت','system');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_key IN ('system.security','system.security.run') WHERE r.name IN ('super_admin','admin');
