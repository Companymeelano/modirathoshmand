CREATE TABLE IF NOT EXISTS social_linkedin_post_insights (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 account_id BIGINT UNSIGNED NOT NULL,
 external_post_id VARCHAR(255) NOT NULL,
 captured_at DATETIME NOT NULL,
 impressions BIGINT UNSIGNED NULL,
 reactions BIGINT UNSIGNED NULL,
 comments BIGINT UNSIGNED NULL,
 shares BIGINT UNSIGNED NULL,
 clicks BIGINT UNSIGNED NULL,
 metadata JSON NULL,
 UNIQUE KEY uq_linkedin_post_snapshot(account_id,external_post_id,captured_at),
 INDEX idx_linkedin_post_account(account_id,captured_at),
 INDEX idx_linkedin_post_external(external_post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.linkedin.oauth','اتصال LinkedIn','social'),
('social.linkedin.publish','انتشار در LinkedIn','social'),
('social.linkedin.analytics','تحلیل LinkedIn','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.linkedin.oauth','social.linkedin.publish','social.linkedin.analytics');
