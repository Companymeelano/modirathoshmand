-- V55: outcome learning, adaptive scoring weights and Thompson Sampling strategy bandit
CREATE TABLE IF NOT EXISTS social_ai_video_variant_outcomes (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 batch_id BIGINT UNSIGNED NULL, batch_item_id BIGINT UNSIGNED NULL, job_id BIGINT UNSIGNED NULL,
 platform VARCHAR(40) NOT NULL, category_id BIGINT UNSIGNED NULL, strategy_key VARCHAR(80) NULL,
 technical_score DECIMAL(8,4) NOT NULL DEFAULT 0, identity_score DECIMAL(8,4) NOT NULL DEFAULT 0,
 platform_fit_score DECIMAL(8,4) NOT NULL DEFAULT 0, risk_penalty DECIMAL(8,4) NOT NULL DEFAULT 0,
 engagement_rate DECIMAL(12,6) NOT NULL DEFAULT 0, reach DECIMAL(20,4) NULL, views DECIMAL(20,4) NULL,
 engagement DECIMAL(20,4) NULL, external_content_id VARCHAR(255) NULL, source_performance_id BIGINT UNSIGNED NULL,
 linked TINYINT(1) NOT NULL DEFAULT 0, metadata_json JSON NULL, observed_at DATETIME NULL, created_at DATETIME NOT NULL,
 UNIQUE KEY uq_variant_outcome_source(source_performance_id), KEY idx_vvo_calibration(platform,category_id,linked,created_at), KEY idx_vvo_job(job_id), KEY idx_vvo_batch(batch_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS ai_scoring_weights (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NOT NULL, category_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
 weight_technical DECIMAL(10,8) NOT NULL DEFAULT 0.35, weight_identity DECIMAL(10,8) NOT NULL DEFAULT 0.45,
 weight_platform_fit DECIMAL(10,8) NOT NULL DEFAULT 0.20, sample_count INT UNSIGNED NOT NULL DEFAULT 0,
 r2 DECIMAL(10,6) NULL, correlation DECIMAL(10,6) NULL, method VARCHAR(80) NOT NULL DEFAULT 'default',
 rationale_json JSON NULL, updated_at DATETIME NOT NULL, created_at DATETIME NOT NULL,
 UNIQUE KEY uq_ai_scoring_weights(platform,category_id), KEY idx_ai_scoring_weights_platform(platform)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS ai_strategy_arms (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NOT NULL, category_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
 strategy_key VARCHAR(80) NOT NULL, alpha DECIMAL(18,8) NOT NULL DEFAULT 1, beta DECIMAL(18,8) NOT NULL DEFAULT 1,
 pulls INT UNSIGNED NOT NULL DEFAULT 0, wins INT UNSIGNED NOT NULL DEFAULT 0, losses INT UNSIGNED NOT NULL DEFAULT 0,
 last_reward DECIMAL(12,6) NULL, last_selected_at DATETIME NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_strategy_arm(platform,category_id,strategy_key), KEY idx_strategy_arm(platform,category_id), KEY idx_strategy_arm_strategy(strategy_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.ai_scoring_weights','مشاهده وزن‌های تطبیقی AI','social'),('social.ai_scoring_weights.run','اجرای کالیبراسیون وزن‌های AI','social'),
('social.ai_strategy_bandit','مشاهده یادگیری استراتژی‌های AI','social'),('social.ai_strategy_bandit.run','اجرای Bandit استراتژی AI','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.ai_scoring_weights','social.ai_scoring_weights.run','social.ai_strategy_bandit','social.ai_strategy_bandit.run');
