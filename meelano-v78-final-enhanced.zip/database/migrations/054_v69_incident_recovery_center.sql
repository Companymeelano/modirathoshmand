-- V69: Incident & Recovery Center
CREATE TABLE IF NOT EXISTS system_incidents (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 fingerprint CHAR(64) NOT NULL,
 severity VARCHAR(20) NOT NULL,
 status VARCHAR(20) NOT NULL DEFAULT 'open',
 component VARCHAR(80) NOT NULL,
 title VARCHAR(180) NOT NULL,
 message VARCHAR(500) NOT NULL,
 occurrences INT UNSIGNED NOT NULL DEFAULT 1,
 acknowledged_by BIGINT UNSIGNED NULL,
 acknowledged_at DATETIME NULL,
 resolved_by BIGINT UNSIGNED NULL,
 resolved_at DATETIME NULL,
 first_seen_at DATETIME NOT NULL,
 last_seen_at DATETIME NOT NULL,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(id), UNIQUE KEY uq_system_incident_fp(fingerprint), KEY idx_si_status_seen(status,last_seen_at), KEY idx_si_severity_seen(severity,last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.incidents','مشاهده مرکز Incident و Recovery','system'),
('system.incidents.run','اجرای Reconcile و تشخیص Incident','system'),
('system.incidents.manage','مدیریت وضعیت Incident','system');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','manager')
AND p.permission_key IN ('system.incidents','system.incidents.run','system.incidents.manage');
