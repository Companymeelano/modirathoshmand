CREATE TABLE IF NOT EXISTS social_ai_content_insights (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NULL,
 generated_at DATETIME NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'success',
 content_count INT UNSIGNED NOT NULL DEFAULT 0,
 analysis JSON NOT NULL,
 recommendations JSON NULL,
 model_code VARCHAR(160) NULL,
 latency_ms INT UNSIGNED NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 INDEX idx_saici_platform_time(platform,generated_at),
 INDEX idx_saici_status_time(status,generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES ('social.ai_intelligence','مشاهده هوش محتوای AI','social'),('social.ai_intelligence.run','اجرای تحلیل هوشمند محتوا','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.ai_intelligence','social.ai_intelligence.run');
