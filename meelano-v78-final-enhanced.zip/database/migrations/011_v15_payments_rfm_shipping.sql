CREATE TABLE IF NOT EXISTS customer_intelligence_metrics (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_id BIGINT UNSIGNED NOT NULL,
 recency_days INT NOT NULL DEFAULT 9999,
 frequency INT NOT NULL DEFAULT 0,
 monetary DECIMAL(18,2) NOT NULL DEFAULT 0,
 aov DECIMAL(18,2) NOT NULL DEFAULT 0,
 r_score TINYINT UNSIGNED NOT NULL DEFAULT 1,
 f_score TINYINT UNSIGNED NOT NULL DEFAULT 1,
 m_score TINYINT UNSIGNED NOT NULL DEFAULT 1,
 clv_estimate DECIMAL(18,2) NOT NULL DEFAULT 0,
 risk_score DECIMAL(8,4) NOT NULL DEFAULT 0,
 segment VARCHAR(40) NOT NULL DEFAULT 'new',
 calculated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_cim_customer(customer_id), INDEX idx_cim_segment(segment), INDEX idx_cim_risk(risk_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payment_webhook_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 event_id BIGINT UNSIGNED NOT NULL,
 attempt_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
 status ENUM('processing','succeeded','failed') NOT NULL DEFAULT 'processing',
 error_code VARCHAR(80) NULL,
 error_message VARCHAR(500) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_pwa_event(event_id),
 UNIQUE KEY uq_pwa_event_attempt(event_id,attempt_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('payments.webhook','پردازش وبهوک پرداخت','payments'),
('crm.intelligence','هوش مشتری و RFM/CLV','crm'),
('shipping.quote','استعلام هزینه ارسال','shipping');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','accountant') AND p.permission_key IN ('payments.webhook');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','manager','marketing') AND p.permission_key IN ('crm.intelligence');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','manager','seller') AND p.permission_key IN ('shipping.quote');
