CREATE TABLE IF NOT EXISTS system_brain_runs (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 cycle_id CHAR(16) NOT NULL,
 status VARCHAR(24) NOT NULL,
 risk_score TINYINT UNSIGNED NOT NULL,
 signal_count INT UNSIGNED NOT NULL,
 plan_json LONGTEXT NOT NULL,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(id), KEY idx_brain_cycle(cycle_id), KEY idx_brain_status(status,risk_score,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_brain_decisions (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 fingerprint CHAR(64) NOT NULL,
 signal_type VARCHAR(80) NOT NULL,
 severity VARCHAR(16) NOT NULL,
 risk_score TINYINT UNSIGNED NOT NULL,
 status VARCHAR(24) NOT NULL,
 occurrences INT UNSIGNED NOT NULL DEFAULT 1,
 cooldown_until DATETIME NULL,
 last_run_id BIGINT UNSIGNED NULL,
 context_json LONGTEXT NULL,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(id), UNIQUE KEY uq_brain_fingerprint(fingerprint), KEY idx_brain_decision_status(status,severity,created_at), KEY idx_brain_cooldown(cooldown_until)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.brain','مشاهده Unified System Brain','system'),
('system.brain.run','اجرای تحلیل Unified System Brain','system'),
('system.brain.execute','اجرای Actionهای Guarded Brain','system');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_key IN ('system.brain','system.brain.run','system.brain.execute') WHERE r.name IN ('super_admin','admin');
