CREATE TABLE IF NOT EXISTS system_performance_metrics (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id VARCHAR(64) NOT NULL,
  action VARCHAR(120) NOT NULL,
  http_method VARCHAR(10) NOT NULL,
  http_status SMALLINT NOT NULL DEFAULT 200,
  duration_ms DECIMAL(12,3) NOT NULL DEFAULT 0,
  memory_peak_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
  source VARCHAR(20) NOT NULL DEFAULT 'http',
  created_at DATETIME NOT NULL,
  PRIMARY KEY(id),
  KEY idx_perf_created(created_at),
  KEY idx_perf_action_created(action,created_at),
  KEY idx_perf_status_created(http_status,created_at),
  KEY idx_perf_duration(duration_ms)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.performance','مشاهده عملکرد سیستم','system'),
('system.performance.run','اجرای تحلیل عملکرد','system');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_key IN ('system.performance','system.performance.run') WHERE r.name IN ('super_admin','admin');
