-- V58: publishing rollback state machine and operational audit trail
ALTER TABLE social_publish_jobs MODIFY COLUMN status VARCHAR(40) NOT NULL DEFAULT 'Queued';
CREATE TABLE IF NOT EXISTS social_publish_rollback_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 from_status VARCHAR(40) NULL,
 to_status VARCHAR(40) NOT NULL,
 platform VARCHAR(40) NULL,
 external_post_id VARCHAR(255) NULL,
 reason VARCHAR(500) NULL,
 response_json JSON NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 KEY idx_spr_job(job_id), KEY idx_spr_status(to_status), KEY idx_spr_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.publish.rollback','درخواست Rollback انتشار اجتماعی','social'),
('social.publish.rollback.run','اجرای Rollback انتشار اجتماعی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.publish.rollback','social.publish.rollback.run');
