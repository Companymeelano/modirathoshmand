CREATE TABLE IF NOT EXISTS social_ai_trend_signals (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(30) NOT NULL,
 topic VARCHAR(255) NOT NULL,
 format VARCHAR(80) NULL,
 momentum DECIMAL(5,2) NOT NULL DEFAULT 0,
 evidence_count INT UNSIGNED NOT NULL DEFAULT 0,
 confidence DECIMAL(4,3) NOT NULL DEFAULT 0,
 observed_at DATETIME NOT NULL,
 source VARCHAR(120) NOT NULL,
 metadata_json JSON NULL,
 created_at DATETIME NOT NULL,
 KEY idx_trend_platform_time(platform,observed_at),
 KEY idx_trend_topic(topic),
 KEY idx_trend_momentum(momentum)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_ai_trend_snapshots (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(30) NULL,
 product_id BIGINT UNSIGNED NULL,
 captured_at DATETIME NOT NULL,
 snapshot JSON NOT NULL,
 analysis JSON NOT NULL,
 signal_count INT UNSIGNED NOT NULL DEFAULT 0,
 confidence DECIMAL(4,3) NOT NULL DEFAULT 0,
 model_code VARCHAR(120) NULL,
 latency_ms INT UNSIGNED NOT NULL DEFAULT 0,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 KEY idx_trend_snapshot(platform,captured_at),
 KEY idx_trend_product(product_id,captured_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.ai_trends','مشاهده هوش ترند','social'),('social.ai_trends.run','اجرای هوش ترند','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.ai_trends','social.ai_trends.run');
