CREATE TABLE IF NOT EXISTS social_ai_media_jobs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 creative_id BIGINT UNSIGNED NULL,
 platform VARCHAR(40) NOT NULL,
 media_type ENUM('image','video') NOT NULL,
 provider_code VARCHAR(80) NOT NULL,
 model_code VARCHAR(160) NULL,
 prompt TEXT NOT NULL,
 input_asset_id BIGINT UNSIGNED NULL,
 provider_job_id VARCHAR(220) NULL,
 status ENUM('queued','processing','completed','failed','cancelled') NOT NULL DEFAULT 'queued',
 progress TINYINT UNSIGNED NOT NULL DEFAULT 0,
 request_json JSON NULL,
 response_json JSON NULL,
 error_code VARCHAR(80) NULL,
 error_message VARCHAR(500) NULL,
 cost_amount DECIMAL(18,8) NULL,
 currency VARCHAR(12) NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_saimj_status(status,updated_at), INDEX idx_saimj_creative(creative_id), INDEX idx_saimj_provider(provider_code,provider_job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_ai_media_outputs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 asset_id BIGINT UNSIGNED NULL,
 version_no INT UNSIGNED NOT NULL DEFAULT 1,
 role VARCHAR(50) NOT NULL DEFAULT 'generated',
 quality_status ENUM('unchecked','passed','warning','failed') NOT NULL DEFAULT 'unchecked',
 quality_report JSON NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_saimo_job_version(job_id,version_no),
 INDEX idx_saimo_asset(asset_id), INDEX idx_saimo_quality(quality_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_ai_asset_links (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 creative_id BIGINT UNSIGNED NOT NULL,
 asset_id BIGINT UNSIGNED NOT NULL,
 role VARCHAR(60) NOT NULL,
 variant_key VARCHAR(10) NULL,
 platform VARCHAR(40) NULL,
 is_primary TINYINT(1) NOT NULL DEFAULT 0,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 UNIQUE KEY uq_saial_creative_asset_role(creative_id,asset_id,role,variant_key),
 INDEX idx_saial_creative(creative_id), INDEX idx_saial_asset(asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.ai_media','مشاهده AI Media و Asset Intelligence','social'),
('social.ai_media.generate','تولید تصویر/ویدئو با AI','social'),
('social.ai_media.worker','اجرای Jobهای تولید رسانه','social'),
('social.ai_media.link','اتصال Asset به Creative','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.ai_media','social.ai_media.generate','social.ai_media.worker','social.ai_media.link');
