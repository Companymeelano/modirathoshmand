CREATE TABLE IF NOT EXISTS fulfillment_status_history (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 shipment_id BIGINT UNSIGNED NOT NULL,
 from_status VARCHAR(30) NULL,
 to_status VARCHAR(30) NOT NULL,
 changed_by BIGINT UNSIGNED NULL,
 note VARCHAR(500) NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_fsh_shipment(shipment_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customer_segment_history (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_id BIGINT UNSIGNED NOT NULL,
 old_segment VARCHAR(30) NULL,
 new_segment VARCHAR(30) NOT NULL,
 score DECIMAL(12,4) NOT NULL DEFAULT 0,
 reason VARCHAR(500) NULL,
 calculated_at DATETIME NOT NULL,
 INDEX idx_csh_customer(customer_id,calculated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS price_policy_rules (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 rule_set_id BIGINT UNSIGNED NOT NULL,
 name VARCHAR(160) NOT NULL,
 priority INT NOT NULL DEFAULT 100,
 min_margin DECIMAL(8,3) NULL,
 target_margin DECIMAL(8,3) NULL,
 max_margin DECIMAL(8,3) NULL,
 min_price DECIMAL(15,2) NULL,
 max_price DECIMAL(15,2) NULL,
 demand_weight DECIMAL(8,3) NOT NULL DEFAULT 0,
 stock_weight DECIMAL(8,3) NOT NULL DEFAULT 0,
 market_weight DECIMAL(8,3) NOT NULL DEFAULT 0,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_ppr_ruleset(rule_set_id,priority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS product_price_approvals (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 product_id BIGINT UNSIGNED NOT NULL,
 variant_id BIGINT UNSIGNED NULL,
 rule_set_id BIGINT UNSIGNED NULL,
 old_price DECIMAL(15,2) NULL,
 proposed_price DECIMAL(15,2) NOT NULL,
 status ENUM('pending','approved','rejected','applied') NOT NULL DEFAULT 'pending',
 requested_by BIGINT UNSIGNED NULL,
 reviewed_by BIGINT UNSIGNED NULL,
 review_note VARCHAR(500) NULL,
 created_at DATETIME NOT NULL,
 reviewed_at DATETIME NULL,
 applied_at DATETIME NULL,
 INDEX idx_ppa_product(product_id,status),
 INDEX idx_ppa_status(status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
