CREATE TABLE IF NOT EXISTS social_ai_content_strategies (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NULL,
 experiment_id BIGINT UNSIGNED NULL,
 generated_at DATETIME NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'success',
 source_snapshot JSON NOT NULL,
 strategy JSON NOT NULL,
 brief_count INT UNSIGNED NOT NULL DEFAULT 0,
 model_code VARCHAR(160) NULL,
 latency_ms INT UNSIGNED NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 INDEX idx_saics_platform_time(platform,generated_at), INDEX idx_saics_experiment(experiment_id), INDEX idx_saics_status_time(status,generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_content_briefs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 strategy_id BIGINT UNSIGNED NOT NULL,
 experiment_id BIGINT UNSIGNED NULL,
 content_id BIGINT UNSIGNED NULL,
 platform VARCHAR(40) NOT NULL,
 objective VARCHAR(180) NOT NULL,
 primary_kpi VARCHAR(80) NOT NULL,
 hook TEXT NOT NULL,
 caption_angle TEXT NOT NULL,
 cta TEXT NULL,
 format VARCHAR(80) NOT NULL,
 visual_direction TEXT NULL,
 timing JSON NULL,
 hypothesis TEXT NULL,
 evidence_notes TEXT NULL,
 risk_flags JSON NULL,
 variants JSON NOT NULL,
 status ENUM('ready','draft_created','archived') NOT NULL DEFAULT 'ready',
 position INT UNSIGNED NOT NULL DEFAULT 1,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_scb_strategy(strategy_id,position), INDEX idx_scb_platform_status(platform,status), INDEX idx_scb_content(content_id), INDEX idx_scb_experiment(experiment_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.ai_strategy','مشاهده استراتژی محتوای AI','social'),
('social.ai_strategy.run','تولید استراتژی محتوای AI','social'),
('social.ai_strategy.draft','ساخت Draft از Content Brief','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.ai_strategy','social.ai_strategy.run','social.ai_strategy.draft');
