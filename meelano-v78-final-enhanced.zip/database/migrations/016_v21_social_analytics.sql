ALTER TABLE social_analytics_snapshots ADD COLUMN IF NOT EXISTS impressions BIGINT UNSIGNED NULL AFTER engagement;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.analytics.sync','همگام‌سازی Analytics شبکه‌های اجتماعی','social'),
('social.status','بررسی وضعیت انتشار اجتماعی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.analytics.sync','social.status');
