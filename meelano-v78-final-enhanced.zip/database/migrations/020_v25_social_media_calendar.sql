CREATE TABLE IF NOT EXISTS social_media_assets (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 platform VARCHAR(40) NULL,
 original_name VARCHAR(255) NOT NULL,
 stored_name VARCHAR(255) NOT NULL,
 relative_path VARCHAR(500) NOT NULL,
 mime_type VARCHAR(120) NOT NULL,
 file_size BIGINT UNSIGNED NOT NULL,
 sha256 CHAR(64) NOT NULL,
 uploaded_by BIGINT UNSIGNED NULL,
 status ENUM('ready','deleted','quarantined') NOT NULL DEFAULT 'ready',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(id), UNIQUE KEY uq_sma_sha256(sha256), KEY idx_sma_status(status), KEY idx_sma_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_content_workflows (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 content_id BIGINT UNSIGNED NOT NULL,
 platform VARCHAR(40) NOT NULL,
 approval_status ENUM('draft','pending','approved','rejected') NOT NULL DEFAULT 'draft',
 scheduled_at DATETIME NULL,
 timezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
 notes VARCHAR(1000) NULL,
 approved_by BIGINT UNSIGNED NULL,
 approved_at DATETIME NULL,
 rejected_by BIGINT UNSIGNED NULL,
 rejected_at DATETIME NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(id), UNIQUE KEY uq_scw_content(content_id), KEY idx_scw_calendar(approval_status,scheduled_at), KEY idx_scw_platform(platform)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.calendar.read','مشاهده تقویم محتوا','social'),
('social.calendar.write','مدیریت تقویم محتوا','social'),
('social.approval','تأیید محتوای اجتماعی','social'),
('social.media.manage','مدیریت رسانه اجتماعی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.calendar.read','social.calendar.write','social.approval','social.media.manage');
