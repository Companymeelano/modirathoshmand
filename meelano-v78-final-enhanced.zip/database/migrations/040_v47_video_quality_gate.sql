ALTER TABLE social_ai_video_director_jobs
  ADD COLUMN quality_status VARCHAR(16) NULL AFTER output_asset_id,
  ADD COLUMN quality_score INT NULL AFTER quality_status,
  ADD COLUMN quality_json LONGTEXT NULL AFTER quality_score;
