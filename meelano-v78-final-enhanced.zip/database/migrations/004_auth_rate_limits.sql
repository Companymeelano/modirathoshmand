CREATE TABLE IF NOT EXISTS rate_limit_buckets (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 bucket_key VARCHAR(191) NOT NULL,
 attempts INT UNSIGNED NOT NULL DEFAULT 0,
 window_started BIGINT UNSIGNED NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_rate_bucket(bucket_key),
 INDEX idx_rate_updated(updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_history (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NULL,
 username VARCHAR(150) NOT NULL,
 ip_address VARCHAR(45) NULL,
 user_agent VARCHAR(512) NULL,
 success TINYINT(1) NOT NULL DEFAULT 0,
 failure_reason VARCHAR(100) NULL,
 created_at DATETIME NOT NULL,
 INDEX idx_login_user(user_id,created_at),
 INDEX idx_login_ip(ip_address,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
