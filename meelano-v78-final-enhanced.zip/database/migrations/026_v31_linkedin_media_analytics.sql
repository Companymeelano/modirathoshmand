ALTER TABLE social_linkedin_post_insights
 ADD COLUMN followers_gained BIGINT UNSIGNED NULL AFTER clicks,
 ADD COLUMN members_reached BIGINT UNSIGNED NULL AFTER followers_gained,
 ADD COLUMN post_saves BIGINT UNSIGNED NULL AFTER members_reached,
 ADD COLUMN post_sends BIGINT UNSIGNED NULL AFTER post_saves,
 ADD COLUMN premium_cta_clicks BIGINT UNSIGNED NULL AFTER post_sends,
 ADD COLUMN profile_views_from_content BIGINT UNSIGNED NULL AFTER premium_cta_clicks,
 ADD COLUMN video_plays BIGINT UNSIGNED NULL AFTER profile_views_from_content,
 ADD COLUMN video_watch_time BIGINT UNSIGNED NULL AFTER video_plays,
 ADD COLUMN video_viewers BIGINT UNSIGNED NULL AFTER video_watch_time;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES ('social.linkedin.analytics.sync','همگام‌سازی تحلیل LinkedIn','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key='social.linkedin.analytics.sync';
