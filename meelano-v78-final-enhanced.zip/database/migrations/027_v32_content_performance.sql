CREATE TABLE IF NOT EXISTS social_content_performance (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 account_id BIGINT UNSIGNED NOT NULL, platform VARCHAR(40) NOT NULL, external_content_id VARCHAR(255) NOT NULL,
 published_at DATETIME NULL, captured_at DATETIME NOT NULL, media_type VARCHAR(40) NULL,
 reach DECIMAL(20,4) NULL, views DECIMAL(20,4) NULL, engagement DECIMAL(20,4) NULL, engagement_rate DECIMAL(12,6) NULL, performance_score DECIMAL(8,2) NULL, metadata JSON NULL,
 INDEX idx_scp_platform_score(platform,performance_score), INDEX idx_scp_account_time(account_id,captured_at), INDEX idx_scp_pub(platform,published_at), INDEX idx_scp_external(platform,external_content_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES ('social.performance','مشاهده عملکرد یکپارچه محتوا','social'),('social.performance.sync','همگام‌سازی عملکرد محتوا','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id) SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.performance','social.performance.sync');
