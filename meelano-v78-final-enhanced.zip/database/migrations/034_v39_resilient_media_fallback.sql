ALTER TABLE social_ai_media_jobs
  ADD COLUMN retry_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER progress,
  ADD COLUMN next_attempt_at DATETIME NULL AFTER retry_count,
  ADD COLUMN fallback_chain_json JSON NULL AFTER next_attempt_at,
  ADD COLUMN execution_mode VARCHAR(40) NULL AFTER fallback_chain_json,
  ADD COLUMN source_analysis_json JSON NULL AFTER execution_mode,
  ADD INDEX idx_saimj_retry(status,next_attempt_at);

CREATE TABLE IF NOT EXISTS social_ai_media_analysis (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NULL,
 creative_id BIGINT UNSIGNED NULL,
 asset_id BIGINT UNSIGNED NULL,
 analysis_type VARCHAR(60) NOT NULL,
 provider_code VARCHAR(80) NULL,
 model_code VARCHAR(160) NULL,
 analysis_json JSON NULL,
 status ENUM('completed','failed','skipped') NOT NULL DEFAULT 'completed',
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 INDEX idx_saima_job(job_id), INDEX idx_saima_creative(creative_id), INDEX idx_saima_asset(asset_id), INDEX idx_saima_type(analysis_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.ai_media.analyze','تحلیل هوشمند متن/رسانه','social'),
('social.ai_media.fallback','اجرای Fallback تولید رسانه','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.ai_media.analyze','social.ai_media.fallback');
