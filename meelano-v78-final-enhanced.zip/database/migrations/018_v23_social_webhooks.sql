CREATE TABLE IF NOT EXISTS social_webhook_events (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 platform VARCHAR(40) NOT NULL,
 event_id VARCHAR(191) NOT NULL,
 event_name VARCHAR(120) NOT NULL,
 publish_id VARCHAR(255) NULL,
 post_id VARCHAR(255) NULL,
 payload JSON NOT NULL,
 received_at DATETIME NOT NULL,
 PRIMARY KEY(id),
 UNIQUE KEY uq_social_webhook_event(platform,event_id),
 KEY idx_social_webhook_publish(platform,publish_id),
 KEY idx_social_webhook_received(received_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO permissions(permission_key,display_name) VALUES
('social.webhook','دریافت Webhook شبکه‌های اجتماعی')
ON DUPLICATE KEY UPDATE display_name=VALUES(display_name);
