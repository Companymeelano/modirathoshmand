-- V68: backup manifests, restore readiness and safe dead-letter recovery
CREATE TABLE IF NOT EXISTS system_backup_manifests (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 backup_path VARCHAR(1024) NOT NULL,
 artifact_name VARCHAR(255) NOT NULL,
 size_bytes BIGINT UNSIGNED NOT NULL,
 modified_at DATETIME NULL,
 sha256 CHAR(64) NOT NULL,
 signature CHAR(64) NULL,
 verified TINYINT(1) NOT NULL DEFAULT 0,
 verification_message VARCHAR(500) NULL,
 created_at DATETIME NOT NULL,
 verified_at DATETIME NULL,
 PRIMARY KEY(id), KEY idx_sbm_path_created(backup_path(191),created_at), KEY idx_sbm_verified(verified,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_publish_dead_letters (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 job_id BIGINT UNSIGNED NOT NULL,
 reason VARCHAR(500) NOT NULL,
 payload_json JSON NULL,
 replay_count INT UNSIGNED NOT NULL DEFAULT 0,
 status VARCHAR(30) NOT NULL DEFAULT 'open',
 last_error VARCHAR(500) NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 PRIMARY KEY(id), UNIQUE KEY uq_spdl_job(job_id), KEY idx_spdl_status_created(status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS system_incident_events (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 severity VARCHAR(20) NOT NULL,
 component VARCHAR(80) NOT NULL,
 event_type VARCHAR(80) NOT NULL,
 message VARCHAR(500) NOT NULL,
 metadata_json JSON NULL,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(id), KEY idx_sie_component_created(component,created_at), KEY idx_sie_severity_created(severity,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.recovery.manifest','مدیریت Manifest پشتیبان و آمادگی Restore','system'),
('social.publish.dlq','مشاهده صف Dead Letter انتشار','social'),
('social.publish.dlq.replay','Replay ایمن Dead Letter انتشار','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('system.recovery.manifest','social.publish.dlq','social.publish.dlq.replay');
