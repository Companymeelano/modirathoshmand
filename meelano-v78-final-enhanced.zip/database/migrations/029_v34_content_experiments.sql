CREATE TABLE IF NOT EXISTS social_content_experiments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(180) NOT NULL,
 platform VARCHAR(40) NOT NULL,
 hypothesis TEXT NOT NULL,
 primary_metric VARCHAR(80) NOT NULL,
 status ENUM('draft','running','completed','cancelled') NOT NULL DEFAULT 'draft',
 planned_start DATETIME NULL,
 planned_end DATETIME NULL,
 winner_variant_id BIGINT UNSIGNED NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 completed_at DATETIME NULL,
 INDEX idx_sce_platform_status(platform,status), INDEX idx_sce_dates(planned_start,planned_end)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_content_experiment_variants (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 experiment_id BIGINT UNSIGNED NOT NULL,
 variant_key VARCHAR(20) NOT NULL,
 label VARCHAR(120) NOT NULL,
 content_id BIGINT UNSIGNED NULL,
 hypothesis_detail TEXT NULL,
 sample_size INT UNSIGNED NOT NULL DEFAULT 0,
 impressions DECIMAL(20,4) NOT NULL DEFAULT 0,
 reach DECIMAL(20,4) NOT NULL DEFAULT 0,
 views DECIMAL(20,4) NOT NULL DEFAULT 0,
 engagement DECIMAL(20,4) NOT NULL DEFAULT 0,
 primary_value DECIMAL(20,6) NOT NULL DEFAULT 0,
 primary_rate DECIMAL(12,6) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_scev_experiment_variant(experiment_id,variant_key),
 INDEX idx_scev_experiment(experiment_id), INDEX idx_scev_content(content_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.experiments','مشاهده آزمایش‌های محتوا','social'),
('social.experiments.manage','مدیریت آزمایش‌های محتوا','social'),
('social.experiments.run','اجرای تحلیل آزمایش‌های محتوا','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.experiments','social.experiments.manage','social.experiments.run');
