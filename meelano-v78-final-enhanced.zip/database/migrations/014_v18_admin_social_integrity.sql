CREATE TABLE IF NOT EXISTS admin_saved_views (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 view_key VARCHAR(100) NOT NULL,
 settings JSON NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_admin_view(user_id,view_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('dashboard.read','مشاهده داشبورد مدیریتی','admin'),
('system.read','مشاهده وضعیت سامانه','admin');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','manager') AND p.permission_key IN ('dashboard.read','system.read');
