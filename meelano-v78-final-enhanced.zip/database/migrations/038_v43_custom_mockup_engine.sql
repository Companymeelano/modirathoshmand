ALTER TABLE product_ad_projects
  ADD COLUMN mode VARCHAR(30) NOT NULL DEFAULT 'catalog' AFTER objective,
  ADD COLUMN mockup_asset_id BIGINT UNSIGNED NULL AFTER source_asset_id,
  ADD COLUMN mockup_analysis_json JSON NULL AFTER context_json;

UPDATE product_ad_projects SET mode='catalog' WHERE mode IS NULL OR mode='';

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('products.ad_studio.mockup','استفاده از موکاپ اختصاصی کاربر','products'),
('products.ad_studio.mockup.upload','آپلود موکاپ اختصاصی','products');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('products.ad_studio.mockup','products.ad_studio.mockup.upload');
