CREATE TABLE IF NOT EXISTS product_ad_projects (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 product_id BIGINT UNSIGNED NOT NULL,
 source_asset_id BIGINT UNSIGNED NULL,
 platform VARCHAR(40) NULL,
 objective VARCHAR(80) NOT NULL DEFAULT 'product_sale',
 profession VARCHAR(160) NULL,
 brief_json JSON NOT NULL,
 design_json JSON NULL,
 status ENUM('draft','analyzing','ready','rendering','completed','failed') NOT NULL DEFAULT 'draft',
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_pap_product(product_id), INDEX idx_pap_status(status), INDEX idx_pap_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS product_ad_outputs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 project_id BIGINT UNSIGNED NOT NULL,
 asset_id BIGINT UNSIGNED NULL,
 platform VARCHAR(40) NOT NULL,
 variant_key VARCHAR(30) NOT NULL,
 width INT UNSIGNED NULL,
 height INT UNSIGNED NULL,
 format VARCHAR(20) NULL,
 copy_json JSON NULL,
 quality_json JSON NULL,
 status ENUM('ready','warning','failed') NOT NULL DEFAULT 'ready',
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_paout_project_platform_variant(project_id,platform,variant_key),
 INDEX idx_paout_asset(asset_id), INDEX idx_paout_platform(platform)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS product_ad_source_assets (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 product_id BIGINT UNSIGNED NOT NULL,
 asset_id BIGINT UNSIGNED NOT NULL,
 role VARCHAR(40) NOT NULL DEFAULT 'product_photo',
 is_primary TINYINT(1) NOT NULL DEFAULT 0,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 UNIQUE KEY uq_pasa(product_id,asset_id,role),
 INDEX idx_pasa_product(product_id), INDEX idx_pasa_asset(asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('products.ad_studio','مشاهده استودیو تبلیغات محصول','products'),
('products.ad_studio.generate','تحلیل و تولید تبلیغ محصول با AI','products'),
('products.ad_studio.upload','مدیریت تصاویر محصول برای تبلیغات','products');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('products.ad_studio','products.ad_studio.generate','products.ad_studio.upload');
