CREATE TABLE IF NOT EXISTS social_media_understanding (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 asset_id BIGINT UNSIGNED NOT NULL,
 analysis_version VARCHAR(30) NOT NULL,
 technical_json JSON NULL,
 transcript_json JSON NULL,
 vision_json JSON NULL,
 strategy_json JSON NULL,
 status ENUM('queued','processing','completed','failed') NOT NULL DEFAULT 'completed',
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_smu_asset(asset_id), INDEX idx_smu_status(status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_media_adaptations (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 understanding_id BIGINT UNSIGNED NOT NULL,
 platform VARCHAR(40) NOT NULL,
 adaptation_json JSON NOT NULL,
 status ENUM('draft','ready','approved','failed') NOT NULL DEFAULT 'ready',
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_sma_understanding_platform(understanding_id,platform),
 INDEX idx_sma_platform(platform)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_trend_signals (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NOT NULL,
 topic VARCHAR(255) NOT NULL,
 format VARCHAR(120) NULL,
 hook VARCHAR(500) NULL,
 notes VARCHAR(2000) NULL,
 source_type VARCHAR(30) NOT NULL DEFAULT 'manual',
 source_url VARCHAR(1000) NULL,
 confidence DECIMAL(5,2) NULL,
 status ENUM('active','archived') NOT NULL DEFAULT 'active',
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_sts_platform_status(platform,status), INDEX idx_sts_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.media.intelligence','هوشمندی ویدئو و تحلیل رسانه','social'),
('social.media.intelligence.run','اجرای تحلیل ویدئو','social'),
('social.media.adaptation','سازگارسازی رسانه برای پلتفرم','social'),
('social.trends.manage','مدیریت سیگنال‌های ترند','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.media.intelligence','social.media.intelligence.run','social.media.adaptation','social.trends.manage');
