CREATE TABLE IF NOT EXISTS deployment_runs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 run_type VARCHAR(40) NOT NULL,
 status VARCHAR(30) NOT NULL,
 release_version VARCHAR(40) NULL,
 applied_count INT UNSIGNED NOT NULL DEFAULT 0,
 report_json JSON NULL,
 started_at DATETIME NOT NULL,
 finished_at DATETIME NULL,
 created_by BIGINT UNSIGNED NULL,
 INDEX idx_deployment_runs_started (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO permissions(permission_key,display_name,module) SELECT 'system.deployment','Deployment Safety','system' WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE permission_key='system.deployment');
INSERT INTO permissions(permission_key,display_name,module) SELECT 'system.deployment.run','Run Safe Upgrade','system' WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE permission_key='system.deployment.run');
