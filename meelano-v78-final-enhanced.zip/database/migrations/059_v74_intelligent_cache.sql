CREATE TABLE IF NOT EXISTS system_cache_metrics (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  namespace VARCHAR(80) NOT NULL,
  event_type VARCHAR(40) NOT NULL,
  duration_ms DECIMAL(12,3) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY(id),
  KEY idx_cache_created(created_at),
  KEY idx_cache_namespace_event(namespace,event_type,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.cache','مشاهده Cache هوشمند','system'),
('system.cache.run','اجرای عملیات Cache','system');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_key IN ('system.cache','system.cache.run') WHERE r.name IN ('super_admin','admin');
