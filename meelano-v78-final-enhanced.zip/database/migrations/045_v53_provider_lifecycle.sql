CREATE TABLE IF NOT EXISTS ai_video_provider_lifecycle (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 provider_code VARCHAR(60) NOT NULL,
 model_code VARCHAR(120) NOT NULL,
 status ENUM('available','retired','blocked') NOT NULL DEFAULT 'available',
 retirement_date DATE NULL,
 reason VARCHAR(255) NULL,
 metadata_json JSON NULL,
 checked_at DATETIME NOT NULL,
 UNIQUE KEY uq_video_provider_model(provider_code,model_code),
 KEY idx_video_provider_status(status,checked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO ai_video_provider_lifecycle(provider_code,model_code,status,retirement_date,reason,metadata_json,checked_at)
VALUES('openai','sora-2','available','2026-09-24','OpenAI Videos API/Sora 2 shutdown',JSON_OBJECT('replacement_priority','gemini_veo'),NOW())
ON DUPLICATE KEY UPDATE status=VALUES(status),retirement_date=VALUES(retirement_date),reason=VALUES(reason),metadata_json=VALUES(metadata_json),checked_at=VALUES(checked_at);
INSERT INTO permissions(permission_key,display_name,module) VALUES
('social.video_provider_lifecycle','مشاهده وضعیت چرخه عمر Video Provider','social')
ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),module=VALUES(module);
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key='social.video_provider_lifecycle';
