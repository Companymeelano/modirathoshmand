CREATE TABLE IF NOT EXISTS social_ai_learning_snapshots (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NULL,
 product_id BIGINT UNSIGNED NULL,
 window_days SMALLINT UNSIGNED NOT NULL DEFAULT 90,
 sample_count INT UNSIGNED NOT NULL DEFAULT 0,
 confidence DECIMAL(5,3) NOT NULL DEFAULT 0,
 observations_json JSON NOT NULL,
 recommendations_json JSON NOT NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 KEY idx_learning_snapshot(platform,created_at),
 KEY idx_learning_product(product_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_ai_learning_factors (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 snapshot_id BIGINT UNSIGNED NOT NULL,
 platform VARCHAR(40) NOT NULL,
 factor_type VARCHAR(40) NOT NULL,
 factor_key VARCHAR(180) NOT NULL,
 sample_count INT UNSIGNED NOT NULL DEFAULT 0,
 weighted_score DECIMAL(10,6) NOT NULL DEFAULT 0,
 confidence DECIMAL(5,3) NOT NULL DEFAULT 0,
 evidence_json JSON NULL,
 created_at DATETIME NOT NULL,
 KEY idx_learning_factor(snapshot_id,factor_type),
 KEY idx_learning_factor_lookup(platform,factor_type,factor_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.ai_learning','مشاهده یادگیری خلاقه AI','social'),
('social.ai_learning.run','اجرای یادگیری خلاقه AI','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.ai_learning','social.ai_learning.run');
