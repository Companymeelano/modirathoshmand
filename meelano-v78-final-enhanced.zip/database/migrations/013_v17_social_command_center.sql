CREATE TABLE IF NOT EXISTS social_accounts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NOT NULL,
 account_name VARCHAR(180) NOT NULL,
 external_account_id VARCHAR(255) NULL,
 status ENUM('active','disabled','reauthorize','error') NOT NULL DEFAULT 'active',
 scopes JSON NULL,
 access_token_enc MEDIUMTEXT NULL,
 refresh_token_enc MEDIUMTEXT NULL,
 token_expires_at DATETIME NULL,
 metadata JSON NULL,
 last_sync_at DATETIME NULL,
 last_error VARCHAR(500) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_social_accounts_platform(platform),INDEX idx_social_accounts_status(status),INDEX idx_social_accounts_external(platform,external_account_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_contents (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NOT NULL,
 caption TEXT NULL,
 media_type VARCHAR(30) NULL,
 media_url TEXT NULL,
 media_urls JSON NULL,
 metadata JSON NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_social_contents_platform(platform),INDEX idx_social_contents_created(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_oauth_states (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NOT NULL,
 state_hash CHAR(64) NOT NULL UNIQUE,
 user_id BIGINT UNSIGNED NULL,
 redirect_uri TEXT NULL,
 expires_at DATETIME NOT NULL,
 consumed_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_social_oauth_expiry(expires_at),INDEX idx_social_oauth_platform(platform)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_analytics_snapshots (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 account_id BIGINT UNSIGNED NOT NULL,
 captured_at DATETIME NOT NULL,
 followers BIGINT UNSIGNED NULL,
 following BIGINT UNSIGNED NULL,
 posts BIGINT UNSIGNED NULL,
 reach BIGINT UNSIGNED NULL,
 impressions BIGINT UNSIGNED NULL,
 engagement BIGINT UNSIGNED NULL,
 clicks BIGINT UNSIGNED NULL,
 conversions BIGINT UNSIGNED NULL,
 metadata JSON NULL,
 UNIQUE KEY uq_social_snapshot(account_id,captured_at),INDEX idx_social_snapshot_account(account_id,captured_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.accounts','مدیریت حساب‌های شبکه اجتماعی','social'),
('social.content','مدیریت محتوای شبکه اجتماعی','social'),
('social.publish','انتشار محتوای شبکه اجتماعی','social'),
('social.analytics','تحلیل شبکه‌های اجتماعی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.accounts','social.content','social.publish','social.analytics');
