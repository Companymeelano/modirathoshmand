CREATE TABLE IF NOT EXISTS system_cache_invalidation_events (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 namespace VARCHAR(100) NOT NULL,
 reason VARCHAR(100) NOT NULL,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(id), KEY idx_cache_inv_created(created_at), KEY idx_cache_inv_ns(namespace,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.cache.query','مشاهده Query Cache','system'),
('system.queue.optimization','مشاهده بهینه‌سازی صف','system');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_key IN ('system.cache.query','system.queue.optimization') WHERE r.name IN ('super_admin','admin');
