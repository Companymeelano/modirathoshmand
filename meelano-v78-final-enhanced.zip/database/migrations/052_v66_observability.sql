CREATE TABLE IF NOT EXISTS system_observability_snapshots (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 status VARCHAR(20) NOT NULL,
 checks_json JSON NOT NULL,
 metrics_json JSON NULL,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(id), KEY idx_obs_status_created(status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.observability','System Observability','system'),
('system.observability.run','Run Observability Check','system');
