ALTER TABLE product_ad_projects
  ADD COLUMN context_json JSON NULL AFTER design_json,
  ADD COLUMN source_asset_ids_json JSON NULL AFTER source_asset_id,
  ADD COLUMN social_drafts_json JSON NULL AFTER context_json;

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('products.ad_studio.drafts','ساخت Draft اجتماعی از تبلیغ محصول','products');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key='products.ad_studio.drafts';
