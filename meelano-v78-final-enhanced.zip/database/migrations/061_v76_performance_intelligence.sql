INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.cache.observability','مشاهده Observability کش','system'),
('system.performance.planner','اجرای Adaptive Query Planner','system'),
('system.queue.recovery.preview','مشاهده برنامه بازیابی صف','system');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_key IN ('system.cache.observability','system.performance.planner','system.queue.recovery.preview') WHERE r.name IN ('super_admin','admin');
