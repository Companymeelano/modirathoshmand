CREATE TABLE IF NOT EXISTS social_ai_creative_projects (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 campaign_id BIGINT UNSIGNED NULL,
 campaign_slot_id BIGINT UNSIGNED NULL,
 brief_id BIGINT UNSIGNED NULL,
 platform VARCHAR(40) NOT NULL,
 format VARCHAR(80) NULL,
 title VARCHAR(220) NOT NULL,
 objective VARCHAR(500) NULL,
 creative JSON NOT NULL,
 primary_kpi VARCHAR(80) NULL,
 hypothesis TEXT NULL,
 content_id BIGINT UNSIGNED NULL,
 status ENUM('ready','in_production','review','draft_created','archived') NOT NULL DEFAULT 'ready',
 model_code VARCHAR(160) NULL,
 latency_ms INT UNSIGNED NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_saicp_campaign(campaign_id), INDEX idx_saicp_slot(campaign_slot_id), INDEX idx_saicp_platform(platform,status), INDEX idx_saicp_content(content_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_ai_production_tasks (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 creative_id BIGINT UNSIGNED NOT NULL,
 task_type VARCHAR(40) NOT NULL,
 title VARCHAR(600) NOT NULL,
 status ENUM('queued','in_progress','done','blocked','cancelled') NOT NULL DEFAULT 'queued',
 assigned_to BIGINT UNSIGNED NULL,
 due_at DATETIME NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_saipt_creative(creative_id,status), INDEX idx_saipt_due(due_at,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.ai_creative','مشاهده Creative و Production Queue','social'),
('social.ai_creative.run','تولید Creative با AI','social'),
('social.ai_creative.draft','ساخت Draft از Creative','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.ai_creative','social.ai_creative.run','social.ai_creative.draft');
