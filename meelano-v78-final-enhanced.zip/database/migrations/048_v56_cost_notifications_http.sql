-- V56 cost intelligence, notification wiring and centralized multipart HTTP
CREATE TABLE IF NOT EXISTS ai_cost_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 entity_type VARCHAR(80) NOT NULL, entity_id BIGINT UNSIGNED NOT NULL, provider_code VARCHAR(80) NOT NULL, model_code VARCHAR(160) NOT NULL,
 unit_type VARCHAR(40) NOT NULL, units DECIMAL(18,8) NOT NULL DEFAULT 1, estimated_cost_usd DECIMAL(18,8) NULL, actual_cost_usd DECIMAL(18,8) NULL,
 metadata_json JSON NULL, created_at DATETIME NOT NULL, KEY idx_ai_cost_events_entity(entity_type,entity_id), KEY idx_ai_cost_events_created(created_at), KEY idx_ai_cost_events_provider(provider_code,model_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
