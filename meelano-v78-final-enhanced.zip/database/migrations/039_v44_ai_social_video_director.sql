CREATE TABLE IF NOT EXISTS social_ai_video_director_jobs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 product_id BIGINT UNSIGNED NOT NULL,
 campaign_id BIGINT UNSIGNED NULL,
 platform VARCHAR(40) NOT NULL,
 source_asset_id BIGINT UNSIGNED NULL,
 context_json JSON NOT NULL,
 master_directive_json JSON NULL,
 provider_chain_json JSON NOT NULL,
 current_provider_index INT UNSIGNED NOT NULL DEFAULT 0,
 current_provider_code VARCHAR(80) NULL,
 provider_job_id VARCHAR(255) NULL,
 status ENUM('queued','analyzing','processing','completed','failed','cancelled') NOT NULL DEFAULT 'queued',
 progress TINYINT UNSIGNED NOT NULL DEFAULT 0,
 response_json JSON NULL,
 output_asset_id BIGINT UNSIGNED NULL,
 last_error_code VARCHAR(100) NULL,
 last_error_message VARCHAR(500) NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_savdj_status(status,updated_at), INDEX idx_savdj_product(product_id), INDEX idx_savdj_provider(current_provider_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_ai_video_provider_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 attempt_no INT UNSIGNED NOT NULL,
 provider_code VARCHAR(80) NOT NULL,
 model_code VARCHAR(160) NULL,
 provider_job_id VARCHAR(255) NULL,
 status VARCHAR(40) NOT NULL,
 error_message VARCHAR(500) NULL,
 started_at DATETIME NOT NULL,
 finished_at DATETIME NULL,
 UNIQUE KEY uq_savpa(job_id,attempt_no), INDEX idx_savpa_job(job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_ai_video_analyses (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 provider_code VARCHAR(80) NULL,
 model_code VARCHAR(160) NULL,
 analysis_json JSON NOT NULL,
 created_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 INDEX idx_savia_job(job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.ai_video_director','مشاهده کارگردان ویدئوی AI','social'),
('social.ai_video_director.generate','تولید ویدئوی تبلیغاتی چندهوشی','social'),
('social.ai_video_director.worker','اجرای صف ویدئوی چندهوشی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing') AND p.permission_key IN ('social.ai_video_director','social.ai_video_director.generate','social.ai_video_director.worker');
ALTER TABLE social_ai_video_director_jobs ADD COLUMN IF NOT EXISTS manual_override_json JSON NULL AFTER master_directive_json;
