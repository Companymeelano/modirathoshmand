CREATE TABLE IF NOT EXISTS system_autonomy_runs (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 status VARCHAR(24) NOT NULL,
 priority VARCHAR(16) NOT NULL,
 plan_json LONGTEXT NOT NULL,
 created_at DATETIME NOT NULL,
 PRIMARY KEY(id),
 KEY idx_autonomy_created(created_at),
 KEY idx_autonomy_status_priority(status,priority,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('system.autonomy','مشاهده Autonomous Performance Engine','system'),
('system.autonomy.run','اجرای تحلیل Autonomous Performance','system'),
('system.autonomy.execute','اجرای Actionهای کم‌خطر Autonomous','system');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r JOIN permissions p ON p.permission_key IN ('system.autonomy','system.autonomy.run','system.autonomy.execute') WHERE r.name IN ('super_admin','admin');
