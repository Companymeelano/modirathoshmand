INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.instagram.oauth','اتصال حساب Instagram','social'),
('social.instagram.publish','انتشار در Instagram','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing')
AND p.permission_key IN ('social.instagram.oauth','social.instagram.publish');
