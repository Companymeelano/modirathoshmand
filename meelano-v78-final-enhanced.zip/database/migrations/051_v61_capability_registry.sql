-- V61: centralized social provider capability registry metadata
CREATE TABLE IF NOT EXISTS social_capability_overrides (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 platform VARCHAR(40) NOT NULL,
 capability_key VARCHAR(80) NOT NULL,
 capability_value TINYINT(1) NOT NULL DEFAULT 0,
 config_json JSON NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_sco_platform_capability(platform,capability_key),
 KEY idx_sco_platform_active(platform,is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.capabilities','مشاهده ماتریس قابلیت‌های شبکه‌های اجتماعی','social');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin','marketing','manager') AND p.permission_key='social.capabilities';
