ALTER TABLE social_accounts ADD COLUMN IF NOT EXISTS token_refreshed_at DATETIME NULL AFTER token_expires_at;
INSERT IGNORE INTO permissions(permission_key,display_name,module) VALUES
('social.oauth','اتصال OAuth شبکه‌های اجتماعی','social'),
('system.manage','مدیریت سیستم','admin');
INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('super_admin','admin') AND p.permission_key IN ('social.oauth','system.manage');
