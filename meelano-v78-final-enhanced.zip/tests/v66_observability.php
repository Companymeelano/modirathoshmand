<?php
declare(strict_types=1);
$root=dirname(__DIR__);$checks=0;$fails=0;
function ck(bool $ok,string $name):void{global $checks,$fails;$checks++;echo ($ok?'PASS ':'FAIL ').$name.PHP_EOL;if(!$ok)$fails++;}
$svc=$root.'/app/Services/ProductionObservabilityService.php';ck(is_file($svc),'observability service exists');$txt=file_get_contents($svc);ck(str_contains($txt,'system_observability_snapshots'),'snapshot persistence contract');ck(str_contains($txt,'stale_processing'),'stale queue metric');
$m=glob($root.'/database/migrations/052_v66_observability.sql');ck(count($m)===1,'V66 migration exists');$r=file_get_contents($root.'/api/routes/system.php');ck(str_contains($r,"case 'system_observability'"),'observability API route');ck(str_contains($r,"case 'system_observability_run'"),'observability run route');ck(str_contains($r,"case 'system_observability_recent'"),'observability recent route');
$c=file_get_contents($root.'/cron/observability_watchdog.php');ck(str_contains($c,'ProductionObservabilityService'),'watchdog uses service');ck(str_contains($c,'AdminNotificationService'),'watchdog alert hook');
$permissions=$root.'/database/migrations/052_v66_observability.sql';ck(str_contains(file_get_contents($permissions),'system.observability.run'),'permission migration');
echo "RESULT passed=".($checks-$fails)." failed={$fails}\n";exit($fails?1:0);
