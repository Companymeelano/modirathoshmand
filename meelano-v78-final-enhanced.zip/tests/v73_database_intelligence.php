<?php
declare(strict_types=1);
$root=dirname(__DIR__); require_once $root.'/app/Core/Autoloader.php'; Autoloader::register($root.'/app');
$cache=new CacheService($root.'/storage/cache-test');$key='v73-test-'.bin2hex(random_bytes(3));
assert($cache->put($key,['ok'=>1],30)); assert(($cache->get($key)['ok']??0)===1); assert($cache->remember($key,30,fn()=>['ok'=>2])['ok']===1); $cache->forget($key); assert($cache->get($key)===null);
$asset=new AssetPerformanceService($root);$r=$asset->audit();assert(($r['status']??'')==='ok');
$files=glob($root.'/app/Services/*.php');foreach($files as $f){$out=[];$code=0;exec('php -l '.escapeshellarg($f).' 2>&1',$out,$code);if($code!==0){fwrite(STDERR,implode("\n",$out)."\n");exit(1);}}
echo "V73 PASS\n";
