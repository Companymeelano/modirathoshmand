<?php
declare(strict_types=1);
$root=dirname(__DIR__);$passed=0;$failed=0;
function ok(bool $c,string $m):void{global $passed,$failed;if($c){$passed++;echo "PASS $m\n";}else{$failed++;echo "FAIL $m\n";}}
$svc=$root.'/app/Services/AutonomousPerformanceService.php';$mig=$root.'/database/migrations/062_v77_autonomous_performance.sql';$boot=file_get_contents($root.'/config/bootstrap.php');$idx=file_get_contents($root.'/api/index.php');$routes=file_get_contents($root.'/api/routes/system.php');$cron=$root.'/cron/autonomous_performance.php';$admin=file_get_contents($root.'/admin/index.php');
ok(is_file($svc),'autonomous service exists');
ok(is_file($mig),'autonomous migration exists');
ok(str_contains($boot,'AutonomousPerformanceService::class'),'autonomous DI binding exists');
ok(str_contains($idx,"str_starts_with(\$action,'system_autonomy')"),'autonomous route dispatch exists');
foreach(['system_autonomy','system_autonomy_run','system_autonomy_recent','system_autonomy_execute'] as $a) ok(str_contains($routes,"case '$a'"),"route $a exists");
ok(is_file($cron),'autonomous cron exists');
ok(str_contains($admin,'Performance · V77'),'admin V77 center exists');
ok(str_contains(file_get_contents($svc),'recommendation_first'),'recommendation-first guardrail exists');
ok(str_contains(file_get_contents($svc),'production_sql_write'), 'SQL write guardrail exists');
ok(str_contains(file_get_contents($svc),'publishing_replay'), 'publishing replay guardrail exists');
$cases=preg_match_all("/case '([^']+)'/",$routes,$m)?$m[1]:[];$dups=array_diff_assoc($cases,array_unique($cases));ok(count($dups)===0,'system API cases unique');
ok(str_contains(file_get_contents($mig),'system.autonomy.execute'),'RBAC execute permission exists');
echo "RESULT passed=$passed failed=$failed\n";exit($failed?1:0);
