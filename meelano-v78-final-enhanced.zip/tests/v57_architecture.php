<?php
declare(strict_types=1);
$root=dirname(__DIR__);
require $root.'/config/bootstrap.php';
function ok(bool $c,string $m): void { echo ($c?'PASS ':'FAIL ').$m.PHP_EOL; if(!$c) exit(1); }
$routes=glob($root.'/api/routes/*.php')?:[];
$cases=[];
foreach($routes as $f){$s=file_get_contents($f);preg_match_all("/case '([^']+)'/",$s,$m);foreach($m[1] as $c)$cases[$c]=true;}
ok(count($routes)===6,'six API route groups');
ok(count($cases)>=125,'all baseline API cases preserved in route groups');
$boot=file_get_contents($root.'/config/bootstrap.php');
ok(substr_count($boot,"require_once __DIR__.'/../app/")===1,'bootstrap uses autoloader instead of manual class requires');
ok(class_exists('Database'),'autoload Database');
ok(class_exists('AISocialVideoDirectorService'),'autoload video director');
ok(interface_exists('AIProviderInterface'),'autoload AI interface');
echo "RESULT passed=6 failed=0".PHP_EOL;
