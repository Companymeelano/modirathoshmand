<?php
declare(strict_types=1);
require_once __DIR__.'/../app/Core/Autoloader.php'; Autoloader::register(__DIR__.'/../app');
$dir=__DIR__.'/../storage/v76-test-cache'; @mkdir($dir,0750,true); $c=new CacheService($dir);
if(!$c->put('v76',['ok'=>1],10))throw new RuntimeException('cache put failed');
if(($c->get('v76')['ok']??0)!==1)throw new RuntimeException('cache read failed');
if(!$c->lock('v76-lock',10))throw new RuntimeException('lock failed');
if($c->lock('v76-lock',10))throw new RuntimeException('lock contention failed');
$c->unlock('v76-lock');
if(!$c->lock('v76-lock',10))throw new RuntimeException('unlock failed');$c->unlock('v76-lock');
$q=new ReflectionClass(QueryCacheService::class); if(!$q->hasMethod('specs'))throw new RuntimeException('query specs API missing');
$specs=$q->getMethod('specs'); if(!$specs->isPublic())throw new RuntimeException('query specs must be public');
@unlink($c->pathFor('v76')); echo "V76 performance intelligence core: PASS\n";
