<?php
declare(strict_types=1);
$root=dirname(__DIR__);$fails=0;$pass=0;
function ok(bool $c,string $m):void{global $fails,$pass;if($c){$pass++;echo "PASS $m\n";}else{$fails++;echo "FAIL $m\n";}}
ok(is_file($root.'/app/Services/PerformanceMetricsService.php'),'performance service exists');
ok(is_file($root.'/database/migrations/057_v72_performance_metrics.sql'),'performance migration exists');
ok(str_contains(file_get_contents($root.'/config/bootstrap.php'),'PerformanceMetricsService::class'),'performance DI binding exists');
$idx=file_get_contents($root.'/database/migrations/057_v72_performance_metrics.sql');ok(str_contains($idx,'idx_perf_action_created'),'performance action index exists');
$sys=file_get_contents($root.'/api/routes/system.php');ok(str_contains($sys,"case 'system_performance':"),'performance route exists');ok(str_contains($sys,"case 'system_performance_run':"),'performance run route exists');ok(str_contains($sys,"case 'system_performance_recent':"),'performance recent route exists');
$disp=file_get_contents($root.'/api/index.php');ok(str_contains($disp,"str_starts_with(\$action,'system_performance')"),'performance route group dispatch exists');
$cron=file_get_contents($root.'/cron/performance_metrics_watchdog.php');ok(str_contains($cron,'p95_ms'),'watchdog p95 check exists');
$load=file_get_contents($root.'/scripts/performance_load_test.php');ok(str_contains($load,'curl_multi_init'),'load test uses curl multi');ok(str_contains($load,'LOADTEST_URL'),'load test is explicitly opt-in');
$inc=file_get_contents($root.'/app/Services/IncidentRecoveryCenterService.php');ok(str_contains($inc,'metadata_json'),'incident recovery schema mismatch fixed');
$admin=file_get_contents($root.'/admin/index.php');ok(str_contains($admin,'Performance Center'),'admin performance center exists');
$all=glob($root.'/api/**/*.php',GLOB_BRACE);$cases=[];foreach($all as $f){preg_match_all("/case\\s+'([^']+)'\\s*:/",file_get_contents($f),$m);$cases=array_merge($cases,$m[1]);}ok(count($cases)===count(array_unique($cases)),'API cases remain unique');
echo "RESULT passed=$pass failed=$fails\n";exit($fails?1:0);
