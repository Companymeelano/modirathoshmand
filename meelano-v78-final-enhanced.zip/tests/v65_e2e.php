<?php
declare(strict_types=1);
require_once __DIR__.'/../app/Core/Autoloader.php';
Autoloader::register(__DIR__.'/../app');

$passed=0;$failed=0;
function e2e(string $name,bool $ok):void{global $passed,$failed;if($ok){$passed++;echo "PASS {$name}\n";}else{$failed++;echo "FAIL {$name}\n";}}
function expectTransition(string $from,string $to):bool{try{OrderStateMachine::assert($from,$to);return true;}catch(Throwable){return false;}}

// Commerce lifecycle: order moves only through an allowed state path.
$flow=['pending','processing','packed','shipped','completed'];
for($i=0;$i<count($flow)-1;$i++) e2e("order transition {$flow[$i]}->{$flow[$i+1]}",expectTransition($flow[$i],$flow[$i+1]));
e2e('order rejects skipped state',!expectTransition('pending','shipped'));
e2e('order rejects resurrection',!expectTransition('completed','processing'));

// Publishing lifecycle: deterministic identity + stale-job decision + rollback eligibility.
$k1=PublishRecoveryService::idempotencyKey(7,9,['caption'=>' Demo ','meta'=>['z'=>2,'a'=>1]]);
$k2=PublishRecoveryService::idempotencyKey(7,9,['meta'=>['a'=>1,'z'=>2],'caption'=>'Demo']);
e2e('publish idempotency survives normalization',$k1===$k2);
e2e('publish stale job with external id reconciles',PublishRecoveryService::staleDecision('Processing',true,true)==='reconcile');
e2e('publish stale job without external id blocks duplicate risk',PublishRecoveryService::staleDecision('Processing',false,true)==='manual_review');
e2e('queued job is not recovered',PublishRecoveryService::staleDecision('Queued',false,true)==='ignore');

// Platform capability gate.
$r=new SocialCapabilityRegistry();
e2e('youtube supports resumable video',$r->supportsMedia('youtube','video','resumable_upload'));
e2e('youtube rollback is supported',$r->supports('youtube','rollback'));
e2e('linkedin rollback is supported',$r->supports('linkedin','rollback'));
e2e('instagram file upload is rejected by capability matrix',!$r->supportsMedia('instagram','reels','file_upload'));
e2e('unknown platform is unavailable',$r->platform('unknown')===null);

// AI production gates: missing artifacts must fail closed / require manual review.
$q=(new VideoQualityGateService())->inspect('/definitely/missing-v65.mp4','instagram');
e2e('quality gate rejects missing artifact',$q['status']==='fail'&&$q['error_code']==='FILE_MISSING');

// Provider continuity: Sora retirement guard is represented in lifecycle service source/config path.
$life=new ReflectionClass(VideoProviderLifecycleService::class);
e2e('provider lifecycle service has retirement guard',$life->hasMethod('isSoraModel')&&$life->hasMethod('soraApiAllowed')&&$life->hasMethod('assertAllowed'));
e2e('sora model detection is deterministic',VideoProviderLifecycleService::isSoraModel('sora-2'));
e2e('non-sora model is not treated as retired',!VideoProviderLifecycleService::isSoraModel('veo-3.1'));

// Route/DI production invariants.
$root=dirname(__DIR__);
$index=(string)file_get_contents($root.'/api/index.php');
e2e('API dispatcher has route groups',str_contains($index,'routes/commerce.php')&&str_contains($index,'routes/social.php')&&str_contains($index,'routes/ai_video.php'));
$bootstrap=(string)file_get_contents($root.'/config/bootstrap.php');
e2e('bootstrap uses container',str_contains($bootstrap,'new Container()')&&str_contains($bootstrap,'singleton(PDO::class'));
$admin=(string)file_get_contents($root.'/admin/index.php');
e2e('admin preserves query parameters',str_contains($admin,"const q=raw.indexOf('&')")&&str_contains($admin,"url+="));

echo "RESULT passed={$passed} failed={$failed}\n";
exit($failed?1:0);
