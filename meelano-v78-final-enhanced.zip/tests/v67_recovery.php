<?php
declare(strict_types=1);
$root=dirname(__DIR__);$ok=0;$fail=0;function ck($c,$m){global $ok,$fail;if($c){$ok++;echo "PASS $m\n";}else{$fail++;echo "FAIL $m\n";}}
ck(is_file($root.'/app/Services/DisasterRecoveryService.php'),'recovery service');
$t=file_get_contents($root.'/app/Services/DisasterRecoveryService.php');
ck(str_contains($t,'migration checksum mismatch'),'migration integrity');ck(str_contains($t,'MEELANO_BACKUP_DIR'),'backup audit');ck(str_contains($t,'stale_processing'),'queue audit');
ck(is_file($root.'/database/migrations/053_v67_disaster_recovery.sql'),'migration');ck(is_file($root.'/cron/disaster_recovery_watchdog.php'),'watchdog');
$r=file_get_contents($root.'/api/routes/system.php');ck(str_contains($r,"case 'system_recovery'"),'recovery route');ck(str_contains($r,"case 'system_recovery_run'"),'recovery run route');
$api=file_get_contents($root.'/api/index.php');ck(str_contains($api,"'system_status'")&&str_contains($api,"'ai_cost_report'"),'system route dispatcher preserved');
echo "RESULT passed=$ok failed=$fail\n";exit($fail?1:0);
