<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$fail=[];$pass=0;
function ok(bool $v,string $name):void{global $pass,$fail;if($v){$pass++;echo "PASS $name\n";}else{$fail[]=$name;echo "FAIL $name\n";}}
ok(is_file($root.'/app/Security/SecurityHardeningService.php'),'security service exists');
ok(is_file($root.'/database/migrations/056_v71_security_hardening.sql'),'security migration exists');
$boot=file_get_contents($root.'/config/bootstrap.php');
ok(str_contains($boot,"X-Content-Type-Options: nosniff"),'nosniff header');
ok(str_contains($boot,"X-Frame-Options: DENY"),'frame deny header');
ok(str_contains($boot,"session.use_strict_mode"),'strict session mode');
ok(str_contains($boot,"session.cookie_httponly"),'httponly cookie');
$api=file_get_contents($root.'/api/index.php');
ok(str_contains($api, 'RateLimiter::class') && str_contains($api, '60,60'), 'per-action rate limit');
ok(str_contains($api, "str_starts_with(\$action,'system_security')"), 'security route dispatch');
$sys=file_get_contents($root.'/api/routes/system.php');
ok(substr_count($sys,"case 'system_security'")===1,'security route unique');
ok(substr_count($sys,"case 'system_security_run'")===1,'security run route unique');
ok(substr_count($sys,"case 'system_security_recent'")===1,'security recent route unique');
foreach(['app','config','database','storage','uploads'] as $d)ok(is_file($root.'/'.$d.'/.htaccess'),$d.' web deny');
$routes=[];$dupes=[];foreach(glob($root.'/api/routes/*.php')?:[] as $f){$t=file_get_contents($f);if(preg_match_all("/case\\s+'([^']+)'\\s*:/",$t,$m))foreach($m[1] as $a){if(isset($routes[$a]))$dupes[]=$a;$routes[$a]=$f;}}
ok(count($dupes)===0,'API duplicate cases');
ok(count($routes)>=148,'API action count preserved');
$files=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/app',FilesystemIterator::SKIP_DOTS));$secret=0;foreach($files as $f)if($f->isFile()&&$f->getExtension()==='php'){ $t=file_get_contents($f->getPathname()); if(preg_match('/sk-[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/',$t))$secret++; }
ok($secret===0,'source secret scan');
echo "RESULT passed=$pass failed=".count($fail)."\n";exit($fail?1:0);
