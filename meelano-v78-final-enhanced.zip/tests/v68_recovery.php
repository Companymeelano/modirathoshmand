<?php
declare(strict_types=1);
$pass=0;$fail=0;$t=function(string $n,bool $ok)use(&$pass,&$fail){echo ($ok?'PASS ':'FAIL ').$n.PHP_EOL;$ok?$pass++:$fail++;};
$t('dead-letter migration exists',is_file(__DIR__.'/../database/migrations/053_v68_backup_manifest_dlq.sql'));
$t('backup manifest service exists',class_exists('BackupManifestService')||is_file(__DIR__.'/../app/Services/BackupManifestService.php'));
$t('dead-letter service exists',class_exists('PublishDeadLetterService')||is_file(__DIR__.'/../app/Services/PublishDeadLetterService.php'));
$s=file_get_contents(__DIR__.'/../api/routes/system.php');$t('backup manifest route',str_contains($s,"system_backup_manifest"));$t('restore readiness route',str_contains($s,"system_restore_readiness"));$t('dlq route',str_contains($s,"social_publish_dlq"));$t('dlq replay route',str_contains($s,"social_publish_dlq_replay"));
$svc=file_get_contents(__DIR__.'/../app/Services/PublishDeadLetterService.php');$t('replay bounded',str_contains($svc,"replay_count"));$t('replay fail-safe statuses',str_contains($svc,"['DeadLetter','RecoveryRequired','Failed']"));
$bm=file_get_contents(__DIR__.'/../app/Services/BackupManifestService.php');$t('backup HMAC signature',str_contains($bm,'hash_hmac'));
echo "RESULT passed={$pass} failed={$fail}".PHP_EOL;exit($fail?1:0);
