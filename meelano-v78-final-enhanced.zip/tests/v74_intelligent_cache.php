<?php
declare(strict_types=1);
$root=dirname(__DIR__);require_once $root.'/app/Services/CacheService.php';
$cache=new CacheService($root.'/storage/cache-v74-test');$key='v74-test-'.bin2hex(random_bytes(4));
if($cache->get($key,null)!==null)throw new RuntimeException('initial cache state failed');
if(!$cache->put($key,['value'=>42],60))throw new RuntimeException('cache put failed');
$v=$cache->get($key,null);if(($v['value']??null)!==42)throw new RuntimeException('cache get failed');
if($cache->remember($key,60,fn()=>['value'=>99])['value']!==42)throw new RuntimeException('cache remember hit failed');
if(!$cache->forget($key)||$cache->get($key,null)!==null)throw new RuntimeException('cache forget failed');
foreach(glob($root.'/storage/cache-v74-test/*')?:[] as $f)@unlink($f);@rmdir($root.'/storage/cache-v74-test');
if(!class_exists('IntelligentCacheService'))require_once $root.'/app/Services/IntelligentCacheService.php';
echo "V74 intelligent cache core PASS\n";
if(!extension_loaded('pdo_sqlite')){echo "V74 DB metrics integration SKIP (pdo_sqlite unavailable)\n";exit(0);} 
$pdo=new PDO('sqlite::memory:');
$pdo->exec("CREATE TABLE system_cache_metrics(id INTEGER PRIMARY KEY AUTOINCREMENT,namespace TEXT,event_type TEXT,duration_ms REAL,created_at TEXT)");
$svc=new IntelligentCacheService($cache,$pdo);$n=0;
$v=$svc->remember('test','key',60,function()use(&$n){$n++;return ['value'=>42];});
$v2=$svc->remember('test','key',60,function()use(&$n){$n++;return ['value'=>99];});
if($v['value']!==42||$v2['value']!==42||$n!==1)throw new RuntimeException('intelligent cache hit failed');
$svc->flushNamespace('test');$v3=$svc->remember('test','key',60,function()use(&$n){$n++;return ['value'=>77];});
if($v3['value']!==77||$n!==2)throw new RuntimeException('generation invalidation failed');
$st=$svc->stats();if(($st['status']??'')!=='ok'||($st['hit_rate']??0)<=0)throw new RuntimeException('stats failed');
echo "V74 DB metrics integration PASS\n";
