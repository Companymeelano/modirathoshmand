<?php
declare(strict_types=1);

require_once __DIR__.'/../app/Core/Autoloader.php';
Autoloader::register(__DIR__.'/../app');

$passed = 0;
$failed = 0;
$skipped = 0;

function v64_check(string $name, bool $ok): void {
    global $passed, $failed;
    if ($ok) { $passed++; echo "PASS {$name}\n"; }
    else { $failed++; echo "FAIL {$name}\n"; }
}
function v64_skip(string $name): void { global $skipped; $skipped++; echo "SKIP {$name}\n"; }
function v64_contains(string $file, string $needle): bool {
    return is_file($file) && str_contains((string)file_get_contents($file), $needle);
}

$root = dirname(__DIR__);

// Architecture / route contracts.
$routes = ['commerce.php','social.php','ai_video.php','ai_image.php','ai_content.php','system.php'];
foreach ($routes as $route) v64_check("route group {$route}", is_file($root.'/api/routes/'.$route));
v64_check('dispatcher selects route groups', v64_contains($root.'/api/index.php', "routes/commerce.php") && v64_contains($root.'/api/index.php', "routes/social.php") && v64_contains($root.'/api/index.php', "routes/ai_video.php"));
v64_check('autoloader registered', v64_contains($root.'/config/bootstrap.php', 'Autoloader::register'));
v64_check('container singleton PDO', v64_contains($root.'/config/bootstrap.php', 'singleton(PDO::class'));
v64_check('direct service construction absent from routes', !preg_match('/\bnew\s+(?:[A-Z][A-Za-z0-9_]*Service|SocialCommandService|SocialPublishingOrchestrator)\s*\(/', implode("\n", array_map(static fn($f)=>(string)file_get_contents($f), glob($root.'/api/routes/*.php') ?: []))));

// Security / error contract checks.
v64_check('request id bootstrap', v64_contains($root.'/config/bootstrap.php', 'REQUEST_ID'));
v64_check('PDO emulated prepares disabled', v64_contains($root.'/app/Core/Database.php', 'PDO::ATTR_EMULATE_PREPARES=>false'));
v64_check('session httponly', v64_contains($root.'/config/bootstrap.php', "'httponly'=>true"));
v64_check('social token encryption path', v64_contains($root.'/app/Services/SocialCommandService.php', 'SocialTokenCipher::encrypt'));

// Recovery / idempotency contracts.
$keyA = PublishRecoveryService::idempotencyKey(11, 77, ['caption'=>' hello ', 'meta'=>['b'=>2,'a'=>1]]);
$keyB = PublishRecoveryService::idempotencyKey(11, 77, ['meta'=>['a'=>1,'b'=>2], 'caption'=>'hello']);
v64_check('idempotency normalization deterministic', $keyA === $keyB);
v64_check('idempotency key bounded', strlen($keyA) <= 128 && str_starts_with($keyA, 'spj_11_77_'));
v64_check('stale processing with external id reconciles', PublishRecoveryService::staleDecision('Processing', true, true) === 'reconcile');
v64_check('stale processing without external id requires review', PublishRecoveryService::staleDecision('Processing', false, true) === 'manual_review');
v64_check('non-processing stale job ignored', PublishRecoveryService::staleDecision('Queued', false, true) === 'ignore');

// Provider capability contracts.
$registry = new SocialCapabilityRegistry();
v64_check('youtube video publish capability', $registry->supportsMedia('youtube','video','resumable_upload'));
v64_check('youtube rollback capability', $registry->supports('youtube','rollback'));
v64_check('linkedin rollback capability', $registry->supports('linkedin','rollback'));
v64_check('instagram local upload is gated', !$registry->supportsMedia('instagram','reels','file_upload'));
v64_check('unknown platform is rejected', $registry->platform('not-a-platform') === null);

// Required production modules exist.
$required = [
    'app/Services/OrderService.php',
    'app/Services/PaymentService.php',
    'app/Services/InventoryService.php',
    'app/Services/PublishRecoveryService.php',
    'app/Services/SocialPublishingRollbackService.php',
    'app/Services/AICostService.php',
    'app/Services/AIProductIdentityService.php',
    'app/Services/AIVideoVariantOrchestratorService.php',
    'app/Services/StrategyBanditService.php',
    'app/Services/VariantWeightCalibrationService.php',
    'app/Services/VideoQualityGateService.php',
];
foreach ($required as $file) v64_check('module '.basename($file), is_file($root.'/'.$file));

// Migration contract checks.
$migrations = [
    '050_v60_publish_idempotency_recovery.sql' => ['idempotency_key','claim_token','claim_expires_at','social_publish_attempts','social_publish_recovery_events'],
    '051_v61_capability_registry.sql' => ['social_capability_overrides','social.capabilities'],
];
foreach ($migrations as $file => $needles) {
    $path = $root.'/database/migrations/'.$file;
    foreach ($needles as $needle) v64_check("migration {$file} contains {$needle}", v64_contains($path, $needle));
}

// Optional live DB smoke test. It never runs against production unless the operator explicitly
// supplies MEELANO_TEST_DB_* variables; it uses a transaction and rolls everything back.
$testDb = trim((string)(getenv('MEELANO_TEST_DB_NAME') ?: ''));
if ($testDb === '') {
    v64_skip('live MySQL integration (set MEELANO_TEST_DB_NAME to run)');
} else {
    try {
        $host = getenv('MEELANO_TEST_DB_HOST') ?: '127.0.0.1';
        $user = getenv('MEELANO_TEST_DB_USER') ?: (getenv('DB_USER') ?: '');
        $pass = getenv('MEELANO_TEST_DB_PASS') ?: (getenv('DB_PASS') ?: '');
        $port = (int)(getenv('MEELANO_TEST_DB_PORT') ?: 3306);
        $pdo = new PDO("mysql:host={$host};port={$port};dbname={$testDb};charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $requiredTables = ['social_accounts','social_contents','social_publish_jobs','social_publish_attempts','social_publish_recovery_events','social_capability_overrides'];
        foreach ($requiredTables as $table) {
            $q = $pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=? AND table_name=?');
            $q->execute([$testDb, $table]);
            v64_check("live table {$table}", (int)$q->fetchColumn() === 1);
        }
        $pdo->beginTransaction();
        try {
            $suffix = bin2hex(random_bytes(5));
            $pdo->prepare("INSERT INTO social_accounts(platform,account_name,status,created_at,updated_at) VALUES('youtube',?, 'active', NOW(), NOW())")->execute(['V64_TEST_'.$suffix]);
            $accountId = (int)$pdo->lastInsertId();
            $pdo->prepare("INSERT INTO social_contents(platform,caption,media_type,metadata,created_at,updated_at) VALUES('youtube','V64 integration','video','{}',NOW(),NOW())")->execute();
            $contentId = (int)$pdo->lastInsertId();
            $key = PublishRecoveryService::idempotencyKey($accountId, $contentId, ['caption'=>'V64 integration','media_type'=>'video']);
            $pdo->prepare("INSERT INTO social_publish_jobs(account_id,platform,content_id,idempotency_key,status,scheduled_at,attempts,payload,created_at,updated_at) VALUES(?,?,?,?, 'Queued', NOW(), 0, ?, NOW(), NOW())")
                ->execute([$accountId,'youtube',$contentId,$key,json_encode(['caption'=>'V64 integration','media_type'=>'video'], JSON_UNESCAPED_SLASHES)]);
            v64_check('live job insert with idempotency key', (int)$pdo->lastInsertId() > 0);
            $duplicateRejected = false;
            try {
                $pdo->prepare("INSERT INTO social_publish_jobs(account_id,platform,content_id,idempotency_key,status,scheduled_at,attempts,payload,created_at,updated_at) VALUES(?,?,?,?, 'Queued', NOW(), 0, ?, NOW(), NOW())")
                    ->execute([$accountId,'youtube',$contentId,$key,'{}']);
            } catch (PDOException) { $duplicateRejected = true; }
            v64_check('live idempotency unique constraint rejects duplicate', $duplicateRejected);
            $pdo->rollBack();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    } catch (Throwable $e) {
        v64_check('live MySQL integration completed', false);
        echo 'INFO live integration error: '.mb_substr($e->getMessage(),0,300)."\n";
    }
}

echo "RESULT passed={$passed} failed={$failed} skipped={$skipped}\n";
exit($failed > 0 ? 1 : 0);
