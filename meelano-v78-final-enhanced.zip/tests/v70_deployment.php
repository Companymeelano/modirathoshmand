<?php
declare(strict_types=1);
$root=dirname(__DIR__); $fails=0; $passes=0;
function ok(bool $v,string $name):void{global $fails,$passes;if($v){$passes++;echo "PASS $name\n";}else{$fails++;echo "FAIL $name\n";}}
$svc=file_get_contents($root.'/app/System/DeploymentSafetyService.php');
ok(str_contains($svc,'GET_LOCK'),'deployment uses mysql advisory lock');
ok(str_contains($svc,'MIGRATION_INTEGRITY_FAILED'),'upgrade blocks modified migrations');
ok(str_contains($svc,"INSERT INTO deployment_runs"),'deployment audit persistence exists');
ok(str_contains(file_get_contents($root.'/install/index.php'),'installer_nonce'),'installer nonce protection exists');
ok(str_contains(file_get_contents($root.'/api/routes/system.php'),"system_deployment_preflight"),'preflight route exists');
ok(str_contains(file_get_contents($root.'/api/routes/system.php'),"system_deployment_upgrade"),'upgrade route exists');
ok(str_contains(file_get_contents($root.'/config/bootstrap.php'),'DeploymentSafetyService'),'DI binding exists');
echo "RESULT passed=$passes failed=$fails\n"; exit($fails?1:0);
