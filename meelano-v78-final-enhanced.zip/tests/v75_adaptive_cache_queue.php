<?php
declare(strict_types=1);
require_once __DIR__.'/../app/Core/Autoloader.php'; Autoloader::register(__DIR__.'/../app');
$dir=__DIR__.'/../storage/v75-test-cache'; @mkdir($dir,0750,true); $c=new CacheService($dir); $c->put('x',['ok'=>1],10); if(($c->get('x')['ok']??0)!==1)throw new RuntimeException('cache get/put failed'); if(!$c->lock('lock-a',10))throw new RuntimeException('lock failed'); if($c->lock('lock-a',10))throw new RuntimeException('lock contention failed'); $c->unlock('lock-a'); if(!$c->lock('lock-a',10))throw new RuntimeException('lock release failed'); $c->unlock('lock-a'); @unlink($c->pathFor('x')); echo "V75 adaptive cache core: PASS\n";
