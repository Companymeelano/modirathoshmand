<?php
declare(strict_types=1);
require_once __DIR__.'/../app/Core/Autoloader.php';
Autoloader::register(__DIR__.'/../app');
$passed=0;$failed=0;
function checkv60(bool $ok,string $name):void{global $passed,$failed;if($ok){$passed++;echo "PASS {$name}\n";}else{$failed++;echo "FAIL {$name}\n";}}
$a=PublishRecoveryService::idempotencyKey(7,42,['caption'=>' hello ','b'=>['z'=>2,'a'=>1]]);
$b=PublishRecoveryService::idempotencyKey(7,42,['b'=>['a'=>1,'z'=>2],'caption'=>'hello']);
checkv60($a===$b,'idempotency key normalization');
checkv60(strlen($a)<=128 && str_starts_with($a,'spj_7_42_'),'idempotency key bounded');
checkv60(PublishRecoveryService::staleDecision('Processing',true,true)==='reconcile','stale processing with external id reconciles');
checkv60(PublishRecoveryService::staleDecision('Processing',false,true)==='manual_review','stale processing without external id is manual review');
checkv60(PublishRecoveryService::staleDecision('Queued',false,true)==='ignore','non-processing job ignored');
echo "RESULT passed={$passed} failed={$failed}\n";
exit($failed?1:0);
