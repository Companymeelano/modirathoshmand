# MeeLano Ultra Commerce OS — V72

Production-hardened commerce, AI, social publishing, observability, disaster recovery, deployment safety, security hardening, and performance engineering stack.

# MeeLano V61 — Provider Capability Registry 2.0

V61 centralizes official social-platform capabilities in `SocialCapabilityRegistry` and makes publishing validation consume that registry instead of a hard-coded matrix inside the publishing orchestrator.

Highlights:
- Central capability matrix for Instagram, YouTube, LinkedIn and TikTok.
- Global operations: OAuth, publish, analytics, status and rollback.
- Media-level operations: direct post, resumable upload, file upload, pull-from-URL and multipart upload.
- Capability explanation API: `social_capability_explain`.
- Existing `social_capabilities` API preserved.
- Publishing idempotency INSERT path from V60 corrected so the persisted idempotency key is actually written.
- Legacy direct enqueue path now also persists deterministic idempotency keys.
- No scraping, fake login, CAPTCHA bypass or rate-limit bypass.

Provider capabilities are declarative and should only be enabled when the corresponding official API adapter is implemented and verified.

## V64 — Production Hardening
See `docs/V64_PROGRESS.md` and run `php tests/v64_integration.php`. Live MySQL integration is opt-in via `MEELANO_TEST_DB_NAME` and uses rollback-only fixtures.

## V70 Deployment Safety
V70 adds production preflight checks, migration checksum verification, MySQL advisory locking for upgrades, deployment audit records, and installer nonce protection. Use `system_deployment_preflight` before an upgrade and `system_deployment_upgrade` for a permissioned safe migration run.
