<?php
declare(strict_types=1);
interface SocialAdapterInterface { public function platform():string; public function publish(array $account,array $content):array; public function validate(array $account,array $content):void; }
