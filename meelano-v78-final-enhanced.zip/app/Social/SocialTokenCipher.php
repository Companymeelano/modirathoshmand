<?php
declare(strict_types=1);
final class SocialTokenCipher { public static function encrypt(string $value):string{return SecretCipher::encrypt($value);} public static function decrypt(?string $value):string{return SecretCipher::decrypt((string)$value);} }
