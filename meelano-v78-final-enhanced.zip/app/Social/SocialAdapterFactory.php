<?php
declare(strict_types=1);
final class SocialAdapterFactory { public static function make(string $platform):SocialAdapterInterface{$p=strtolower(trim($platform));return match($p){'tiktok'=>new TikTokAdapter(),'youtube'=>new YouTubeAdapter(),'instagram'=>new InstagramAdapter(),'linkedin'=>new LinkedInAdapter(),default=>new UnsupportedAdapter($p)};}}
