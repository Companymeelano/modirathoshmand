<?php
declare(strict_types=1);
final class SocialException extends RuntimeException { public function __construct(string $message, public readonly int $httpStatus=0, public readonly bool $retryable=false){parent::__construct($message);} }
