<?php
declare(strict_types=1);
final class SocialCapabilityRegistry {
 public function all():array {
  return [
   'instagram'=>[
    'oauth'=>true,'publish'=>true,'analytics'=>false,'status'=>false,'rollback'=>false,
    'media'=>[
     'image'=>['direct_post'=>true,'file_upload'=>false,'pull_from_url'=>true],
     'reels'=>['direct_post'=>true,'file_upload'=>false,'pull_from_url'=>true],
     'video'=>['direct_post'=>true,'file_upload'=>false,'pull_from_url'=>true],
    ],
   ],
   'youtube'=>[
    'oauth'=>true,'publish'=>true,'analytics'=>false,'status'=>true,'rollback'=>true,
    'media'=>[
     'video'=>['direct_post'=>false,'resumable_upload'=>true,'file_upload'=>true,'pull_from_url'=>false],
    ],
   ],
   'linkedin'=>[
    'oauth'=>true,'publish'=>true,'analytics'=>true,'status'=>false,'rollback'=>true,
    'media'=>[
     'text'=>['direct_post'=>true],
     'link'=>['direct_post'=>true],
     'image'=>['direct_post'=>true,'multipart_upload'=>true,'file_upload'=>true],
     'video'=>['direct_post'=>true,'multipart_upload'=>true,'file_upload'=>true],
    ],
   ],
   'tiktok'=>[
    'oauth'=>true,'publish'=>true,'analytics'=>true,'status'=>true,'rollback'=>false,
    'media'=>[
     'video'=>['direct_post'=>true,'file_upload'=>true,'pull_from_url'=>true],
     'photo'=>['direct_post'=>true,'file_upload'=>false,'pull_from_url'=>true],
    ],
   ],
  ];
 }
 public function platform(string $platform):?array { return $this->all()[strtolower(trim($platform))]??null; }
 public function supports(string $platform,string $capability):bool { $c=$this->platform($platform); return $c!==null && !empty($c[$capability]); }
 public function media(string $platform,string $type):?array { $c=$this->platform($platform); return $c['media'][strtolower(trim($type))]??null; }
 public function supportsMedia(string $platform,string $type,string $operation):bool { $m=$this->media($platform,$type); return $m!==null && !empty($m[$operation]); }
 public function adapter(string $platform):SocialAdapterInterface { return SocialAdapterFactory::make($platform); }
 public function assertPublishable(string $platform,string $type,array $payload=[]):void {
  $p=strtolower(trim($platform)); $t=strtolower(trim($type));
  if(!$this->supports($p,'publish')) throw new SocialException('No official publisher adapter is configured for '.$p.'.',501,false);
  $media=$this->media($p,$t);
  if($media===null) throw new DomainException('نوع رسانه برای این پلتفرم پشتیبانی نمی‌شود.');
  if(!empty($payload['media_path']) && empty($media['file_upload'])) throw new DomainException('آپلود فایل محلی برای این پلتفرم فعال نیست.');
 }
 public function explain(string $platform,string $type='video'):array {
  $p=strtolower(trim($platform)); $t=strtolower(trim($type)); $caps=$this->platform($p);
  if($caps===null)return ['platform'=>$p,'supported'=>false,'reason'=>'unknown_platform'];
  $media=$caps['media'][$t]??null;
  return ['platform'=>$p,'supported'=>$media!==null,'global'=>['oauth'=>(bool)$caps['oauth'],'publish'=>(bool)$caps['publish'],'analytics'=>(bool)$caps['analytics'],'status'=>(bool)$caps['status'],'rollback'=>(bool)$caps['rollback']],'media'=>$media??[]];
 }
}
