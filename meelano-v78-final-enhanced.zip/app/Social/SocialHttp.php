<?php
declare(strict_types=1);
final class SocialHttp {
 public static function request(string $method,string $url,array $headers=[],?array $json=null,mixed $body=null,int $timeout=60):array{
  $ch=curl_init($url);if($ch===false)throw new SocialException('HTTP client unavailable',0,true);
  $opts=[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HEADER=>true,CURLOPT_CUSTOMREQUEST=>strtoupper($method),CURLOPT_HTTPHEADER=>self::headers($headers,$json!==null),CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>max(5,min(180,$timeout)),CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2];
  if($json!==null){$opts[CURLOPT_POSTFIELDS]=json_encode($json,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);}elseif(is_array($body)){$opts[CURLOPT_POSTFIELDS]=self::multipart($body);}elseif($body!==null){$opts[CURLOPT_POSTFIELDS]=(string)$body;}
  curl_setopt_array($ch,$opts);$started=microtime(true);$raw=curl_exec($ch);$errno=curl_errno($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$hs=(int)curl_getinfo($ch,CURLINFO_HEADER_SIZE);curl_close($ch);
  if($raw===false||$errno)throw new SocialException('Social provider network error',0,true);
  $headerText=substr((string)$raw,0,$hs);$responseBody=substr((string)$raw,$hs);$respHeaders=[];foreach(preg_split('/\r\n|\n|\r/',$headerText) as $line){if(str_contains($line,':')){[$k,$v]=explode(':',$line,2);$respHeaders[strtolower(trim($k))]=trim($v);}}
  $data=json_decode($responseBody,true);if(!is_array($data))$data=['raw'=>$responseBody];
  if($status<200||$status>=300){$msg=(string)($data['error']['message']??$data['error']['description']??$data['message']??'Social provider request failed');throw new SocialException(substr($msg,0,500),$status,$status===408||$status===409||$status===429||$status>=500);}
  return ['status'=>$status,'data'=>$data,'headers'=>$respHeaders,'latency_ms'=>(int)round((microtime(true)-$started)*1000)];
 }
 private static function multipart(array $fields):array{$out=[];foreach($fields as $k=>$v){if(is_string($v)&&str_starts_with($v,'@')&&is_file(substr($v,1))){$out[$k]=new CURLFile(substr($v,1));}elseif($v instanceof CURLFile){$out[$k]=$v;}else{$out[$k]=$v;}}return $out;}
 private static function headers(array $headers,bool $json):array{$out=[];$hasContent=false;foreach($headers as $k=>$v){$out[]=$k.': '.$v;if(strtolower($k)==='content-type')$hasContent=true;}if($json&&!$hasContent)$out[]='Content-Type: application/json';return $out;}
}
