<?php
declare(strict_types=1);
final class YouTubeAdapter implements SocialAdapterInterface {
 public function platform():string{return 'youtube';}
 public function validate(array $account,array $content):void{
  if(empty($account['access_token_enc'])) throw new DomainException('توکن YouTube تنظیم نشده است.');
  $type=strtolower((string)($content['media_type']??'video'));
  if($type!=='video') throw new DomainException('YouTube Publisher فعلاً فقط ویدئو را پشتیبانی می‌کند.');
  $path=(string)($content['media_path']??'');
  if($path==='' || !is_file($path) || !is_readable($path)) throw new InvalidArgumentException('مسیر فایل ویدئوی YouTube معتبر نیست.');
 }
 public function postStatus(array $account,string $videoId):array{
  $token=SocialTokenCipher::decrypt($account['access_token_enc']??null); if($token==='') throw new SocialException('YouTube access token is not configured.');
  $videoId=trim($videoId); if($videoId==='')throw new InvalidArgumentException('videoId is required.');
  $url='https://www.googleapis.com/youtube/v3/videos?part=processingDetails,status&id='.rawurlencode($videoId);
  return $this->request('GET',$url,['Authorization: Bearer '.$token]);
 }
 public function publish(array $account,array $content):array{
  $token=SocialTokenCipher::decrypt($account['access_token_enc']??null);
  if($token==='') throw new DomainException('توکن YouTube قابل استفاده نیست.');
  $this->validate($account,$content);
  $path=(string)$content['media_path']; $size=filesize($path); if($size===false||$size<1)throw new InvalidArgumentException('فایل ویدئو خالی یا نامعتبر است.');
  $mime=(string)($content['mime_type']??mime_content_type($path)?:'video/mp4');
  $title=trim((string)($content['title']??$content['caption']??'MeeLano Video')); $title=mb_substr($title,0,100);
  $description=(string)($content['description']??$content['caption']??''); $description=mb_substr($description,0,5000);
  $privacy=(string)($content['privacy_status']??'private'); if(!in_array($privacy,['private','public','unlisted'],true))$privacy='private';
  $body=['snippet'=>['title'=>$title,'description'=>$description,'categoryId'=>(string)($content['category_id']??'22')],'status'=>['privacyStatus'=>$privacy,'selfDeclaredMadeForKids'=>(bool)($content['made_for_kids']??false)]];
  $init=$this->request('POST','https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',['Authorization: Bearer '.$token,'Content-Type: application/json; charset=UTF-8','X-Upload-Content-Length: '.$size,'X-Upload-Content-Type: '.$mime],json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
  $uploadUrl=$init['headers']['location']??''; if($uploadUrl==='')throw new SocialException('YouTube resumable upload URL was not returned.');
  $chunk=8*1024*1024;$fp=fopen($path,'rb');if(!$fp)throw new RuntimeException('امکان خواندن فایل YouTube وجود ندارد.');$offset=0;$videoId='';try{
   while($offset<$size){$remaining=$size-$offset;$len=min($chunk,$remaining);$data=fread($fp,$len);if($data===false||strlen($data)!==$len)throw new RuntimeException('خطا در خواندن chunk ویدئو.');$end=$offset+$len-1;
    $r=$this->request('PUT',$uploadUrl,['Authorization: Bearer '.$token,'Content-Length: '.$len,'Content-Type: '.$mime,'Content-Range: bytes '.$offset.'-'.$end.'/'.$size],$data,true);
    $status=(int)$r['status'];if($status===308){$range=(string)($r['headers']['range']??'');if(preg_match('/-(\d+)$/',$range,$m))$offset=(int)$m[1]+1;else $offset=$end+1;}elseif($status>=200&&$status<300){$videoId=(string)($r['json']['id']??'');break;}else throw new SocialException('YouTube upload failed with HTTP '.$status,$status,$status>=500||$status===429);
   }
  }finally{fclose($fp);}
  if($videoId==='')throw new SocialException('YouTube upload completed without a video ID.');
  return ['external_post_id'=>$videoId,'provider_status'=>'UPLOADED','url'=>'https://www.youtube.com/watch?v='.rawurlencode($videoId)];
 }
 private function request(string $method,string $url,array $headers,string $body,bool $binary=false):array{
  $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HEADER=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>180,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_POSTFIELDS=>$body]);$raw=curl_exec($ch);if($raw===false){$e=curl_error($ch);curl_close($ch);throw new SocialException('YouTube HTTP error: '.$e,0,true);} $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$hs=(int)curl_getinfo($ch,CURLINFO_HEADER_SIZE);$headerText=substr($raw,0,$hs);$respBody=substr($raw,$hs);curl_close($ch);$outHeaders=[];foreach(preg_split('/\r\n|\n|\r/',$headerText) as $line){if(str_contains($line,':')){[$k,$v]=array_map('trim',explode(':',$line,2));$outHeaders[strtolower($k)]=$v;}}
  $json=json_decode($respBody,true);if($status<200||$status>=300&&$status!==308){$msg='YouTube request failed';if(is_array($json))$msg=(string)($json['error']['message']??$msg);throw new SocialException($msg,$status,$status>=500||$status===429);}return ['status'=>$status,'headers'=>$outHeaders,'body'=>$respBody,'json'=>is_array($json)?$json:[]];
 }
}
