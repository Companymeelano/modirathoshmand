<?php
declare(strict_types=1);
final class LinkedInAdapter implements SocialAdapterInterface {
 public function platform():string{return 'linkedin';}
 private function version():string{$v=trim((string)Env::get('LINKEDIN_VERSION','202608'));return preg_match('/^20\d{4}$/',$v)?$v:'202608';}
 private function token(array $account):string{if(empty($account['access_token_enc']))throw new SocialException('LinkedIn access token is not configured.',401,false);$t=SocialTokenCipher::decrypt((string)$account['access_token_enc']);if($t==='')throw new SocialException('LinkedIn access token is invalid.',401,false);return $t;}
 private function author(array $account):string{$a=(string)($account['external_account_id']??'');if(!preg_match('/^urn:li:person:[A-Za-z0-9_-]+$/',$a))throw new SocialException('LinkedIn member URN is missing.',422,false);return $a;}
 private function headers(string $token,string $contentType='application/json'):array{return ['Authorization: Bearer '.$token,'Linkedin-Version: '.$this->version(),'X-Restli-Protocol-Version: 2.0.0','Content-Type: '.$contentType,'Accept: application/json'];}
 public function validate(array $account,array $content):void{
  $type=strtolower((string)($content['media_type']??'text'));
  if(!in_array($type,['text','link','image','video'],true))throw new DomainException('نوع رسانه LinkedIn پشتیبانی نمی‌شود.');
  if(trim((string)($content['caption']??''))==='')throw new InvalidArgumentException('متن LinkedIn الزامی است.');
  if($type==='link' && filter_var((string)($content['media_url']??$content['url']??''),FILTER_VALIDATE_URL)===false)throw new InvalidArgumentException('URL لینک LinkedIn معتبر نیست.');
  if(in_array($type,['image','video'],true)){$path=$this->safePath((string)($content['media_path']??''));if(!is_file($path)||!is_readable($path))throw new InvalidArgumentException('فایل رسانه LinkedIn معتبر نیست.');}
 }
 public function publish(array $account,array $content):array{
  $this->validate($account,$content);$token=$this->token($account);$author=$this->author($account);$type=strtolower((string)($content['media_type']??'text'));
  $body=['author'=>$author,'commentary'=>(string)$content['caption'],'visibility'=>'PUBLIC','distribution'=>['feedDistribution'=>'MAIN_FEED','targetEntities'=>[],'thirdPartyDistributionChannels'=>[]],'lifecycleState'=>'PUBLISHED','isReshareDisabledByAuthor'=>false];
  if($type==='link'){$url=(string)($content['media_url']??$content['url']);$body['content']=['article'=>['source'=>$url,'title'=>(string)($content['title']??'')]];}
  elseif($type==='image'){$urn=$this->uploadImage($token,$author,$this->safePath((string)$content['media_path']));$body['content']=['media'=>['id'=>$urn,'altText'=>mb_substr((string)($content['alt_text']??$content['caption']),0,4086)]];}
  elseif($type==='video'){$urn=$this->uploadVideo($token,$author,$this->safePath((string)$content['media_path']));$body['content']=['media'=>['id'=>$urn,'title'=>mb_substr((string)($content['title']??''),0,200)]];}
  $r=$this->jsonRequest('POST','https://api.linkedin.com/rest/posts',$token,$body);$id=(string)($r['headers']['x-restli-id']??$r['data']['id']??'');
  if($id==='')throw new SocialException('LinkedIn post was created without a post ID.',502,true);
  return ['external_post_id'=>$id,'provider_status'=>'PUBLISHED','response'=>$r['data'],'latency_ms'=>$r['latency_ms']??null,'media_type'=>$type];
 }
 private function uploadImage(string $token,string $owner,string $path):string{
  $mime=(string)(mime_content_type($path)?:'image/jpeg');if(!in_array($mime,['image/jpeg','image/png','image/gif'],true))throw new InvalidArgumentException('فرمت تصویر LinkedIn باید JPG، PNG یا GIF باشد.');
  $init=$this->jsonRequest('POST','https://api.linkedin.com/rest/images?action=initializeUpload',$token,['initializeUploadRequest'=>['owner'=>$owner]]);$v=$init['data']['value']??[];$url=(string)($v['uploadUrl']??'');$urn=(string)($v['image']??'');if($url===''||$urn==='')throw new SocialException('LinkedIn image upload initialization failed.',502,true);
  $this->binaryPut($url,$path,$mime,180);return $urn;
 }
 private function uploadVideo(string $token,string $owner,string $path):string{
  $size=filesize($path);if($size===false||$size<75000||$size>500*1024*1024)throw new InvalidArgumentException('حجم ویدئوی LinkedIn باید بین 75KB و 500MB باشد.');
  $mime=(string)(mime_content_type($path)?:'video/mp4');if($mime!=='video/mp4')throw new InvalidArgumentException('LinkedIn Videos API در این نسخه فقط MP4 را می‌پذیرد.');
  $init=$this->jsonRequest('POST','https://api.linkedin.com/rest/videos?action=initializeUpload',$token,['initializeUploadRequest'=>['owner'=>$owner,'fileSizeBytes'=>$size,'uploadCaptions'=>false,'uploadThumbnail'=>false]]);$v=$init['data']['value']??[];$urn=(string)($v['video']??'');$tokenUpload=(string)($v['uploadToken']??'');$instructions=$v['uploadInstructions']??[];if($urn===''||!is_array($instructions)||!$instructions)throw new SocialException('LinkedIn video upload initialization failed.',502,true);
  $fp=fopen($path,'rb');if(!$fp)throw new RuntimeException('امکان خواندن ویدئوی LinkedIn وجود ندارد.');$etags=[];try{foreach($instructions as $i=>$ins){$first=(int)($ins['firstByte']??-1);$last=(int)($ins['lastByte']??-1);$url=(string)($ins['uploadUrl']??'');if($first<0||$last<$first||$url==='')throw new SocialException('LinkedIn video upload instruction is invalid.',502,false);if(fseek($fp,$first)!==0)throw new RuntimeException('جابجایی فایل ویدئو ناموفق بود.');$len=$last-$first+1;$data='';while(strlen($data)<$len){$chunk=fread($fp,min(1048576,$len-strlen($data)));if($chunk===false||$chunk==='')throw new RuntimeException('خواندن بخش ویدئوی LinkedIn ناموفق بود.');$data.=$chunk;}$r=$this->binaryPutData($url,$data,'video/mp4',180);$etag=trim((string)($r['headers']['etag']??''),'" ');if($etag==='')throw new SocialException('LinkedIn did not return an ETag for video part '.($i+1).'.',502,true);$etags[]=$etag;}}
  finally{fclose($fp);}
  $fin=$this->jsonRequest('POST','https://api.linkedin.com/rest/videos?action=finalizeUpload',$token,['finalizeUploadRequest'=>['video'=>$urn,'uploadToken'=>$tokenUpload,'uploadedPartIds'=>$etags]]);
  return $urn;
 }
 private function safePath(string $path):string{$path=trim($path);if($path==='')return '';if(str_contains($path,"\0"))throw new InvalidArgumentException('مسیر رسانه نامعتبر است.');$root=realpath(dirname(__DIR__,2));$candidate=$path[0]==='/'?$path:$root.'/'.ltrim($path,'/');$real=realpath($candidate);if($real===false||!str_starts_with($real,$root.DIRECTORY_SEPARATOR))throw new InvalidArgumentException('مسیر رسانه خارج از فضای مجاز است.');return $real;}
 private function jsonRequest(string $method,string $url,string $token,array $body):array{return SocialHttp::request($method,$url,$this->headers($token),$body,null,180);}
 private function binaryPut(string $url,string $path,string $mime,int $timeout):array{$data=file_get_contents($path);if($data===false)throw new RuntimeException('خواندن رسانه LinkedIn ناموفق بود.');return $this->binaryPutData($url,$data,$mime,$timeout);}
 private function binaryPutData(string $url,string $data,string $mime,int $timeout):array{$ch=curl_init($url);if($ch===false)throw new SocialException('HTTP client unavailable',0,true);curl_setopt_array($ch,[CURLOPT_CUSTOMREQUEST=>'PUT',CURLOPT_RETURNTRANSFER=>true,CURLOPT_HEADER=>true,CURLOPT_HTTPHEADER=>['Content-Type: '.$mime,'Content-Length: '.strlen($data)],CURLOPT_POSTFIELDS=>$data,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>$timeout,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);$started=microtime(true);$raw=curl_exec($ch);$errno=curl_errno($ch);$error=curl_error($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$hs=(int)curl_getinfo($ch,CURLINFO_HEADER_SIZE);curl_close($ch);if($raw===false||$errno)throw new SocialException('LinkedIn media upload network error',0,true);$ht=substr($raw,0,$hs);$headers=[];foreach(preg_split('/\r\n|\n|\r/',$ht) as $line){if(str_contains($line,':')){[$k,$v]=explode(':',$line,2);$headers[strtolower(trim($k))]=trim($v);}}$body=substr($raw,$hs);if($status<200||$status>=300){throw new SocialException('LinkedIn media upload failed with HTTP '.$status,$status,$status===408||$status===429||$status>=500);}return ['status'=>$status,'headers'=>$headers,'body'=>$body,'latency_ms'=>(int)round((microtime(true)-$started)*1000)];}
}
