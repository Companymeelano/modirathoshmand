<?php
declare(strict_types=1);
final class InstagramAdapter implements SocialAdapterInterface {
 public function platform():string{return 'instagram';}
 public function validate(array $account,array $content):void{
  if(trim((string)($account['access_token_enc']??''))==='')throw new DomainException('توکن Instagram تنظیم نشده است.');
  $ig=(string)($account['external_account_id']??''); if($ig==='')throw new DomainException('Instagram Professional Account ID تنظیم نشده است.');
  $scopes=json_decode((string)($account['scopes']??'[]'),true)?:[];
  if(is_array($scopes)&&$scopes&&!in_array('instagram_business_content_publish',$scopes,true))throw new DomainException('Scope موردنیاز instagram_business_content_publish برای این حساب وجود ندارد.');
  $type=strtolower((string)($content['media_type']??'image'));
  if(!in_array($type,['image','video','reels','carousel'],true))throw new DomainException('نوع رسانه Instagram پشتیبانی نمی‌شود.');
  if($type==='image' && empty($content['media_url']) && empty($content['media_path']) && empty($content['asset_id']))throw new InvalidArgumentException('برای Instagram باید media_url یا asset_id ارائه شود.');
  if(in_array($type,['video','reels'],true) && empty($content['video_url']) && empty($content['media_url']) && empty($content['media_path']) && empty($content['asset_id']))throw new InvalidArgumentException('برای Reel باید video_url یا asset_id ارائه شود.');
 }
 public function publish(array $account,array $content):array{
  $this->validate($account,$content);
  $token=SocialTokenCipher::decrypt($account['access_token_enc']??null); if($token==='')throw new DomainException('توکن Instagram قابل استفاده نیست.');
  $ig=trim((string)$account['external_account_id']); $version=trim((string)Env::get('META_GRAPH_VERSION','v25.0')); $base='https://graph.instagram.com/'.$version;
  $type=strtolower((string)($content['media_type']??'image')); $caption=mb_substr((string)($content['caption']??''),0,2200);
  $params=['access_token'=>$token];
  if($caption!=='')$params['caption']=$caption;
  if($type==='image'){$params['image_url']=$this->publicUrl($content); if(!empty($content['alt_text']))$params['alt_text']=mb_substr((string)$content['alt_text'],0,1000);}
  elseif(in_array($type,['video','reels'],true)){$params['media_type']='REELS';$params['video_url']=$this->publicUrl($content);$params['share_to_feed']=array_key_exists('share_to_feed',$content)?(bool)$content['share_to_feed']:true;}
  else throw new DomainException('Instagram carousel باید در مرحله مستقل Orchestrator ساخته شود.');
  $created=$this->request('POST',$base.'/'.$ig.'/media',$params); $creation=(string)($created['json']['id']??''); if($creation==='')throw new SocialException('Instagram media container ID was not returned.');
  $status=$this->waitContainer($base,$creation,$token);
  if(!in_array($status['status_code'],['FINISHED','PUBLISHED'],true))throw new SocialException('Instagram media container آماده انتشار نشد: '.($status['status']??$status['status_code']));
  $published=$this->request('POST',$base.'/'.$ig.'/media_publish',['creation_id'=>$creation,'access_token'=>$token]); $mediaId=(string)($published['json']['id']??''); if($mediaId==='')throw new SocialException('Instagram published media ID was not returned.');
  return ['external_post_id'=>$mediaId,'provider_status'=>'PUBLISH_COMPLETE','container_id'=>$creation,'url'=>'https://www.instagram.com/'];
 }
 private function publicUrl(array $content):string{
  foreach(['public_url','media_url','video_url'] as $k){$v=trim((string)($content[$k]??''));if($v!==''&&preg_match('#^https://#i',$v))return $v;}
  $assetId=(int)($content['asset_id']??0);if($assetId<1)throw new InvalidArgumentException('Instagram به URL عمومی HTTPS نیاز دارد.');
  $base=rtrim((string)Env::get('APP_BASE_URL',''),' /');if($base==='')throw new DomainException('APP_BASE_URL برای ساخت URL عمومی رسانه تنظیم نشده است.');
  $exp=time()+3600;$key=(string)Env::get('APP_KEY','');if($key==='')throw new DomainException('APP_KEY برای URL امن رسانه تنظیم نشده است.');$sig=hash_hmac('sha256',$assetId.'|'.$exp,$key);return $base.'/api/?action=social_media_public&asset_id='.$assetId.'&expires='.$exp.'&sig='.$sig;
 }
 private function waitContainer(string $base,string $id,string $token):array{
  $last=['status_code'=>'IN_PROGRESS'];
  for($i=0;$i<10;$i++){$r=$this->request('GET',$base.'/'.rawurlencode($id),['fields'=>'status_code,status','access_token'=>$token]);$last=$r['json'];$code=(string)($last['status_code']??'');if(in_array($code,['FINISHED','ERROR','EXPIRED','PUBLISHED'],true))return $last;sleep(3);}
  return $last;
 }
 private function request(string $method,string $url,array $params):array{
  $ch=curl_init($url);$headers=['Accept: application/json'];if($method==='POST'){curl_setopt($ch,CURLOPT_POST,true);curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($params));$headers[]='Content-Type: application/x-www-form-urlencoded';}else{$url.=(str_contains($url,'?')?'&':'?').http_build_query($params);curl_setopt($ch,CURLOPT_URL,$url);}curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>60,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);$raw=curl_exec($ch);if($raw===false){$e=curl_error($ch);curl_close($ch);throw new SocialException('Instagram HTTP error: '.$e,0,true);} $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$json=json_decode((string)$raw,true);if(!is_array($json))$json=[];if($status<200||$status>=300){$msg=(string)($json['error']['message']??'Instagram API request failed');throw new SocialException($msg,$status,$status>=500||$status===429);}return ['status'=>$status,'json'=>$json];
 }
}
