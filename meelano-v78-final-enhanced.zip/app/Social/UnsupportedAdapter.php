<?php
declare(strict_types=1);
final class UnsupportedAdapter implements SocialAdapterInterface { public function __construct(private string $name){} public function platform():string{return $this->name;} public function validate(array $account,array $content):void{} public function publish(array $account,array $content):array{throw new SocialException('No official publisher adapter is configured for '.$this->name.'.',501,false);} }
