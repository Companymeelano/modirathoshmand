<?php
interface AIProviderInterface { public function generate(string $task,array $input): array; public function name(): string; public function capabilities(): array; }
