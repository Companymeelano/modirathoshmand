<?php
declare(strict_types=1);
interface PaymentGatewayInterface { public function code():string; public function request(array $transaction,array $context=[]):array; public function verify(array $transaction,array $callback=[]):array; public function refund(array $transaction,float $amount,array $context=[]):array; }
