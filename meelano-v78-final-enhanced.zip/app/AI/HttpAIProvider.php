<?php
declare(strict_types=1);
final class HttpAIProvider implements AIProviderInterface {
 public function __construct(private array $provider, private array $model){}
 public function name():string{return (string)$this->provider['provider_code'];}
 public function capabilities():array{return [(string)$this->model['capability']];}
 public function generate(string $task,array $input):array{
  $code=strtolower((string)$this->provider['provider_code']);
  return match($code){
   'openai'=> $this->openAI($task,$input),
   'gemini'=> $this->gemini($task,$input),
   'anthropic','claude'=> $this->anthropic($task,$input),
   default=> $this->openAICompatible($task,$input),
  };
 }
 public function generateVision(string $task,array $input):array{
  $code=strtolower((string)$this->provider['provider_code']); return match($code){
   'openai'=> $this->openAIVision($task,$input),
   'gemini'=> $this->geminiVision($task,$input),
   'anthropic','claude'=> $this->anthropicVision($task,$input),
   default=> $this->openAIVision($task,$input),
  };
 }
 private function openAIVision(string $task,array $input):array{
  $key=$this->key();if($key==='')throw new AIProviderException('AI vision API key is not configured.');$base=rtrim((string)($this->provider['base_url']?:'https://api.openai.com/v1'),'/');$content=[['type'=>'input_text','text'=>$this->userText($input)]];foreach(($input['images']??[]) as $im){if(!isset($im['base64'],$im['mime']))continue;$content[]=['type'=>'input_image','image_url'=>'data:'.$im['mime'].';base64,'.$im['base64']];}$body=['model'=>$this->modelCode(),'input'=>[['role'=>'system','content'=>[['type'=>'input_text','text'=>$this->systemText($task,$input)]]],['role'=>'user','content'=>$content]]];if((int)($this->model['supports_json_mode']??0)===1&&!empty($input['json_mode']))$body['text']=['format'=>['type'=>'json_object']];$h=$this->headers();$h['Authorization']='Bearer '.$key;$r=$this->request($base.'/responses',$h,$body);return $this->result($this->extractResponsesText($r),$r,(int)($r['usage']['input_tokens']??0),(int)($r['usage']['output_tokens']??0));
 }
 private function geminiVision(string $task,array $input):array{
  $key=$this->key();if($key==='')throw new AIProviderException('Gemini vision API key is not configured.');$base=rtrim((string)($this->provider['base_url']?:'https://generativelanguage.googleapis.com'),'/');$model=rawurlencode($this->modelCode());$parts=[['text'=>$this->userText($input)]];foreach(($input['images']??[]) as $im){if(isset($im['base64'],$im['mime']))$parts[]=['inline_data'=>['mime_type'=>$im['mime'],'data'=>$im['base64']]];}$body=['contents'=>[['role'=>'user','parts'=>$parts]],'systemInstruction'=>['parts'=>[['text'=>$this->systemText($task,$input)]]]];if((int)($this->model['supports_json_mode']??0)===1&&!empty($input['json_mode']))$body['generationConfig']=['responseMimeType'=>'application/json'];$h=$this->headers();$h['x-goog-api-key']=$key;$r=$this->request($base.'/v1beta/models/'.$model.':generateContent',$h,$body);return $this->result((string)($r['candidates'][0]['content']['parts'][0]['text']??''),$r,(int)($r['usageMetadata']['promptTokenCount']??0),(int)($r['usageMetadata']['candidatesTokenCount']??0));
 }
 private function anthropicVision(string $task,array $input):array{
  $key=$this->key();if($key==='')throw new AIProviderException('Anthropic vision API key is not configured.');$base=rtrim((string)($this->provider['base_url']?:'https://api.anthropic.com'),'/');$content=[['type'=>'text','text'=>$this->userText($input)]];foreach(($input['images']??[]) as $im){if(isset($im['base64'],$im['mime']))$content[]=['type'=>'image','source'=>['type'=>'base64','media_type'=>$im['mime'],'data'=>$im['base64']]];}$body=['model'=>$this->modelCode(),'max_tokens'=>(int)($this->model['max_output_tokens']?:1024),'system'=>$this->systemText($task,$input),'messages'=>[['role'=>'user','content'=>$content]]];$h=$this->headers();$h['x-api-key']=$key;$h['anthropic-version']=(string)($this->provider['api_version']?:'2023-06-01');$r=$this->request($base.'/v1/messages',$h,$body);$text='';foreach(($r['content']??[]) as $part)if(($part['type']??'')==='text')$text.=(string)($part['text']??'');return $this->result($text,$r,(int)($r['usage']['input_tokens']??0),(int)($r['usage']['output_tokens']??0));
 }
 private function config():array{ $x=json_decode((string)($this->provider['extra_config']??''),true);return is_array($x)?$x:[]; }
 private function headers():array{
  $h=['Content-Type: application/json'];$x=json_decode((string)($this->provider['default_headers']??''),true);if(is_array($x))foreach($x as $k=>$v)if(is_string($k)&&is_scalar($v))$h[$k]=(string)$v;return $h;
 }
 private function key():string{return (string)SecretCipher::decrypt((string)($this->provider['api_key_enc']??$this->provider['api_key']??''));}
 private function modelCode():string{return (string)($this->model['model_code']??'');}
 private function timeout():int{ $t=(int)($this->config()['timeout']??30);return max(5,min(120,$t)); }
 private function request(string $url,array $headers,array $body):array{
  $ch=curl_init($url);if($ch===false)throw new AIProviderException('HTTP client unavailable',0,true);
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>$this->headerLines($headers),CURLOPT_POSTFIELDS=>json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_CONNECTTIMEOUT=>min(10,$this->timeout()),CURLOPT_TIMEOUT=>$this->timeout(),CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
  $started=microtime(true);$raw=curl_exec($ch);$errno=curl_errno($ch);$err=curl_error($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
  $lat=(int)round((microtime(true)-$started)*1000);
  if($raw===false||$errno!==0)throw new AIProviderException('AI provider network timeout/error',0,true,null);
  $json=json_decode((string)$raw,true);if(!is_array($json))throw new AIProviderException('AI provider returned invalid JSON',$status,$status===0||$status>=500);
  if($status<200||$status>=300){$msg=(string)($json['error']['message']??$json['message']??'AI provider request failed');$retry=$status===408||$status===409||$status===429||$status>=500;throw new AIProviderException(mb_substr($msg,0,500),$status,$retry,(string)($json['id']??''));}
  $json['_latency_ms']=$lat;return $json;
 }
 private function headerLines(array $headers):array{$o=[];foreach($headers as $k=>$v)$o[]=$k.': '.$v;return $o;}
 private function openAI(string $task,array $input):array{
  $key=$this->key();if($key==='')throw new AIProviderException('OpenAI API key is not configured.');
  $base=rtrim((string)($this->provider['base_url']?:'https://api.openai.com/v1'),'/');$url=$base.'/responses';$messages=$this->messages($task,$input);
  $body=['model'=>$this->modelCode(),'input'=>$messages,'temperature'=>(float)($this->model['default_temperature']??0.7)];$max=(int)($this->model['max_output_tokens']??0);if($max>0)$body['max_output_tokens']=$max;
  if((int)($this->model['supports_json_mode']??0)===1 && !empty($input['json_mode']))$body['text']=['format'=>['type'=>'json_object']];
  $h=$this->headers();$h['Authorization']='Bearer '.$key;if(($this->provider['organization_id']??''))$h['OpenAI-Organization']=$this->provider['organization_id'];if(($this->provider['project_id']??''))$h['OpenAI-Project']=$this->provider['project_id'];
  $r=$this->request($url,$h,$body);$text=$this->extractResponsesText($r);return $this->result($text,$r,(int)($r['usage']['input_tokens']??0),(int)($r['usage']['output_tokens']??0));
 }
 private function openAICompatible(string $task,array $input):array{
  $key=$this->key();if($key==='')throw new AIProviderException('AI API key is not configured.');
  $base=rtrim((string)$this->provider['base_url'],'/');$cfg=$this->config();$endpoint=(string)($cfg['endpoint']??'/chat/completions');$url=str_starts_with($endpoint,'http')?$endpoint:$base.'/'.ltrim($endpoint,'/');
  $body=['model'=>$this->modelCode(),'messages'=>$this->messages($task,$input),'temperature'=>(float)($this->model['default_temperature']??0.7),'stream'=>false];$max=(int)($this->model['max_output_tokens']??0);if($max>0)$body['max_tokens']=$max;if(!empty($input['json_mode'])&&(int)($this->model['supports_json_mode']??0)===1)$body['response_format']=['type'=>'json_object'];
  $h=$this->headers();$h['Authorization']='Bearer '.$key;$r=$this->request($url,$h,$body);$text=(string)($r['choices'][0]['message']['content']??'');return $this->result($text,$r,(int)($r['usage']['prompt_tokens']??0),(int)($r['usage']['completion_tokens']??0));
 }
 private function anthropic(string $task,array $input):array{
  $key=$this->key();if($key==='')throw new AIProviderException('Anthropic API key is not configured.');
  $base=rtrim((string)($this->provider['base_url']?:'https://api.anthropic.com'),'/');$url=$base.'/v1/messages';$body=['model'=>$this->modelCode(),'max_tokens'=>(int)($this->model['max_output_tokens']?:1024),'system'=>$this->systemText($task,$input),'messages'=>[['role'=>'user','content'=>$this->userText($input)]]];$t=$this->model['default_temperature'];if($t!==null)$body['temperature']=(float)$t;
  $h=$this->headers();$h['x-api-key']=$key;$h['anthropic-version']=(string)($this->provider['api_version']?:'2023-06-01');$r=$this->request($url,$h,$body);$text='';foreach(($r['content']??[]) as $part)if(($part['type']??'')==='text')$text.=(string)($part['text']??'');return $this->result($text,$r,(int)($r['usage']['input_tokens']??0),(int)($r['usage']['output_tokens']??0));
 }
 private function gemini(string $task,array $input):array{
  $key=$this->key();if($key==='')throw new AIProviderException('Gemini API key is not configured.');$base=rtrim((string)($this->provider['base_url']?:'https://generativelanguage.googleapis.com'),'/');$model=rawurlencode($this->modelCode());$url=$base.'/v1beta/models/'.$model.':generateContent';$body=['contents'=>[['role'=>'user','parts'=>[['text'=>$this->userText($input)]]]],'systemInstruction'=>['parts'=>[['text'=>$this->systemText($task,$input)]]]];$cfg=['temperature'=>(float)($this->model['default_temperature']??0.7)];$max=(int)($this->model['max_output_tokens']??0);if($max>0)$cfg['maxOutputTokens']=$max;if(!empty($input['json_mode'])&&(int)($this->model['supports_json_mode']??0)===1)$cfg['responseMimeType']='application/json';$body['generationConfig']=$cfg;$h=$this->headers();$h['x-goog-api-key']=$key;$r=$this->request($url,$h,$body);$text=(string)($r['candidates'][0]['content']['parts'][0]['text']??'');return $this->result($text,$r,(int)($r['usageMetadata']['promptTokenCount']??0),(int)($r['usageMetadata']['candidatesTokenCount']??0));
 }
 private function messages(string $task,array $input):array{return [['role'=>'system','content'=>$this->systemText($task,$input)],['role'=>'user','content'=>$this->userText($input)]];}
 private function systemText(string $task,array $input):string{return (string)($input['system_prompt']??'You are MeeLano Business AI. Task: '.$task.'. Use only supplied context. Do not invent business facts.');}
 private function userText(array $input):string{$v=$input['prompt']??$input['message']??'';if(is_array($v))$v=json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);return (string)$v;}
 private function extractResponsesText(array $r):string{if(isset($r['output_text'])&&is_string($r['output_text']))return $r['output_text'];$out='';foreach(($r['output']??[]) as $item)foreach(($item['content']??[]) as $c)if(isset($c['text']))$out.=(string)$c['text'];return $out;}
 private function result(string $text,array $raw,int $in,int $out):array{return ['ok'=>true,'provider'=>$this->name(),'model'=>$this->modelCode(),'text'=>$text,'prompt_tokens'=>$in,'completion_tokens'=>$out,'total_tokens'=>$in+$out,'provider_request_id'=>(string)($raw['id']??''),'latency_ms'=>(int)($raw['_latency_ms']??0)];}
}
