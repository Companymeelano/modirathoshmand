<?php
declare(strict_types=1);
final class SecretCipher {
 private static function key():string{
  $raw=(string)(getenv('APP_KEY')?:getenv('MEELANO_APP_KEY')?:'');
  if($raw==='')throw new RuntimeException('APP_KEY is not configured.');
  return hash('sha256',$raw,true);
 }
 public static function encrypt(?string $value):?string{
  if($value===null||$value==='')return $value;
  $iv=random_bytes(12);$tag='';$ct=openssl_encrypt($value,'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,$iv,$tag);
  if($ct===false)throw new RuntimeException('Secret encryption failed.');
  return 'v1.'.base64_encode($iv.$tag.$ct);
 }
 public static function decrypt(?string $value):?string{
  if($value===null||$value==='')return $value;
  if(!str_starts_with($value,'v1.'))return $value;
  $bin=base64_decode(substr($value,3),true);if($bin===false||strlen($bin)<28)throw new RuntimeException('Invalid encrypted secret.');
  $iv=substr($bin,0,12);$tag=substr($bin,12,16);$ct=substr($bin,28);
  $plain=openssl_decrypt($ct,'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,$iv,$tag);
  if($plain===false)throw new RuntimeException('Secret decryption failed.');return $plain;
 }
}
