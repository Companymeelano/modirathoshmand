<?php
final class MockSafeProvider implements AIProviderInterface { public function generate(string $task,array $input):array{return ['ok'=>false,'provider'=>$this->name(),'error'=>'No AI provider configured'];} public function name():string{return 'safe-null';} public function capabilities():array{return [];} }
