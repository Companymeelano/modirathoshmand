<?php
declare(strict_types=1);
final class AIProviderException extends RuntimeException {
 public function __construct(string $message, private int $httpStatus=0, private bool $retryable=false, private ?string $providerRequestId=null){parent::__construct($message,$httpStatus);}
 public function httpStatus():int{return $this->httpStatus;}
 public function retryable():bool{return $this->retryable;}
 public function providerRequestId():?string{return $this->providerRequestId;}
}
