<?php
declare(strict_types=1);
final class DeploymentSafetyService {
    public function __construct(private PDO $db, private string $migrationDir) {}

    public function preflight(): array {
        $checks = [];
        $checks['php'] = ['ok'=>version_compare(PHP_VERSION,'8.3.0','>='),'value'=>PHP_VERSION];
        foreach (['pdo_mysql','curl','openssl','mbstring','json','fileinfo'] as $ext) {
            $checks['ext_'.$ext] = ['ok'=>extension_loaded($ext),'value'=>extension_loaded($ext) ? 'loaded':'missing'];
        }
        $checks['https'] = ['ok'=>(($_SERVER['HTTPS'] ?? '') !== '' && ($_SERVER['HTTPS'] ?? '') !== 'off') || Env::get('APP_ENV') === 'local','value'=>(($_SERVER['HTTPS'] ?? '') !== '' ? 'detected':'not-detected')];
        $checks['app_key'] = ['ok'=>trim((string)Env::get('APP_KEY')) !== '','value'=>Env::get('APP_KEY') ? 'configured':'missing'];
        $checks['migration_dir'] = ['ok'=>is_dir($this->migrationDir) && is_readable($this->migrationDir),'value'=>$this->migrationDir];
        foreach (['storage','uploads'] as $dir) {
            $path=dirname(__DIR__,2).'/'.$dir;
            $checks['writable_'.$dir] = ['ok'=>is_dir($path) && is_writable($path),'value'=>$path];
        }
        try { $this->db->query('SELECT 1'); $checks['database']=['ok'=>true,'value'=>'connected']; }
        catch(Throwable $e){ $checks['database']=['ok'=>false,'value'=>'unavailable']; }
        $checks['migration_integrity']=$this->migrationIntegrity();
        $ok=true; foreach($checks as $c){ if(!$c['ok']){$ok=false;break;} }
        return ['ok'=>$ok,'checks'=>$checks,'generated_at'=>date('c')];
    }

    public function migrationIntegrity(): array {
        $result=['ok'=>true,'pending'=>[],'modified'=>[],'count'=>0];
        try {
            $this->db->exec("CREATE TABLE IF NOT EXISTS app_migrations (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,version VARCHAR(100) NOT NULL UNIQUE,checksum CHAR(64) NOT NULL,applied_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $rows=$this->db->query('SELECT version,checksum FROM app_migrations')->fetchAll(PDO::FETCH_KEY_PAIR);
            $files=glob(rtrim($this->migrationDir,'/').'/*.sql')?:[]; sort($files,SORT_NATURAL); $result['count']=count($files);
            foreach($files as $file){$v=basename($file,'.sql');$checksum=hash_file('sha256',$file);if(!isset($rows[$v]))$result['pending'][]=$v;elseif(!hash_equals((string)$rows[$v],$checksum))$result['modified'][]=$v;}
            $result['ok']=count($result['modified'])===0;
        } catch(Throwable $e){$result=['ok'=>false,'pending'=>[],'modified'=>[],'count'=>0,'error'=>'migration_integrity_unavailable'];}
        return $result;
    }

    public function acquireLock(int $timeout=5): bool {
        $timeout=max(0,min(30,$timeout));
        $stmt=$this->db->prepare('SELECT GET_LOCK(?,?)');
        $stmt->execute(['meelano_deployment_lock',$timeout]);
        return (int)$stmt->fetchColumn()===1;
    }
    public function releaseLock(): void { try{$this->db->query("SELECT RELEASE_LOCK('meelano_deployment_lock')");}catch(Throwable $e){} }

    public function persist(string $type, string $status, array $report, ?int $userId=null, int $appliedCount=0): int {
        $stmt=$this->db->prepare('INSERT INTO deployment_runs(run_type,status,release_version,applied_count,report_json,started_at,finished_at,created_by) VALUES(?,?,?,?,?,NOW(),NOW(),?)');
        $stmt->execute([$type,$status,'V70',$appliedCount,json_encode($report,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$userId]);
        return (int)$this->db->lastInsertId();
    }

    public function runUpgrade(bool $allowPending=true): array {
        if(!$this->acquireLock()) throw new RuntimeException('DEPLOYMENT_LOCK_UNAVAILABLE');
        try {
            $pre=$this->preflight();
            if(!$pre['ok']) throw new RuntimeException('DEPLOYMENT_PREFLIGHT_FAILED');
            $integrity=$this->migrationIntegrity();
            if(!$integrity['ok']) throw new RuntimeException('MIGRATION_INTEGRITY_FAILED');
            if(!$allowPending && $integrity['pending']) throw new RuntimeException('PENDING_MIGRATIONS_PRESENT');
            $runner=new MigrationRunner($this->db,$this->migrationDir);
            $done=$runner->run();
            $report=['ok'=>true,'applied'=>$done,'count'=>count($done),'preflight'=>$pre];
            $this->persist('upgrade','completed',$report,null,count($done));
            return $report;
        } finally { $this->releaseLock(); }
    }
}
