<?php
declare(strict_types=1);
final class AIContentIntelligenceService {
 public function __construct(private PDO $db, private AIService $ai, private Audit $audit){}
 public function analyze(?string $platform=null, ?int $userId=null):array {
  $platform=$platform!==null?strtolower(trim($platform)):null;
  if($platform!==null && !in_array($platform,['instagram','linkedin','tiktok','youtube'],true)) throw new InvalidArgumentException('پلتفرم نامعتبر است.');
  $data=$this->dataset($platform);
  if(!$data['contents']) return ['ok'=>false,'status'=>'insufficient_data','message'=>'برای تحلیل هوشمند هنوز داده عملکرد محتوای کافی ثبت نشده است.','data'=>$data];
  $prompt=$this->buildPrompt($data);
  $result=$this->ai->run('content_intelligence',['prompt'=>$prompt,'system_prompt'=>'You are MeeLano Content Intelligence Engine. Use only the supplied aggregated historical content-performance dataset. Never invent metrics, platforms, dates, or causal claims. Return strict JSON only with keys: executive_summary (string), winning_patterns (array of strings), weak_patterns (array of strings), best_times (array of objects with platform,hour,confidence), platform_strategies (array of objects with platform,format,hook,cta,timing,reason), experiments (array of objects with hypothesis,control,variant,primary_metric), risk_flags (array of strings). Recommendations must be testable and should never guarantee virality, Explore/FYP placement, or business outcomes. If a sample is small, explicitly say so.'],$userId);
  if(empty($result['ok'])) return $result+['data'=>$data];
  $parsed=$this->parseJson((string)($result['text']??''));
  if($parsed===null) throw new RuntimeException('AI پاسخ ساختاریافته JSON برنگرداند.');
  $id=$this->persist($platform,$data,$parsed,$result,$userId);
  if($userId) $this->audit->log($userId,'ai_content_intelligence_generated','social_ai_content_insights',$id,$id,['platform'=>$platform,'contents'=>$data['contents']]);
  return ['ok'=>true,'status'=>'generated','id'=>$id,'analysis'=>$parsed,'dataset'=>$data,'model'=>$result['model']??null,'latency_ms'=>$result['latency_ms']??null];
 }
 public function latest(?string $platform=null):array {
  $where=$platform!==null&&trim($platform)!==''?'WHERE platform=?':'WHERE platform IS NULL';
  $args=$platform!==null&&trim($platform)!==''?[strtolower(trim($platform))]:[];
  if($platform===null){$where='WHERE platform IS NULL';$args=[];}
  $sql="SELECT id,platform,generated_at,status,content_count,analysis,recommendations,model_code,latency_ms,created_at FROM social_ai_content_insights {$where} ORDER BY generated_at DESC LIMIT 1";
  $q=$this->db->prepare($sql);$q->execute($args);$r=$q->fetch(PDO::FETCH_ASSOC);if(!$r)return [];
  $r['analysis']=$this->decode((string)$r['analysis'],[]);$r['recommendations']=$this->decode((string)$r['recommendations'],[]);return $r;
 }
 public function recent(int $limit=20):array{$limit=max(1,min(100,$limit));$q=$this->db->query("SELECT id,platform,generated_at,status,content_count,analysis,recommendations,model_code,latency_ms,created_at FROM social_ai_content_insights ORDER BY generated_at DESC,id DESC LIMIT {$limit}");$rows=$q->fetchAll(PDO::FETCH_ASSOC);foreach($rows as &$r){$r['analysis']=$this->decode((string)$r['analysis'],[]);$r['recommendations']=$this->decode((string)$r['recommendations'],[]);}return $rows;}
 private function dataset(?string $platform):array {
  $where=$platform!==null?'WHERE p.platform=?':'WHERE 1=1';$args=$platform!==null?[$platform]:[];
  $q=$this->db->prepare("SELECT p.platform,p.media_type,p.published_at,p.reach,p.views,p.engagement,p.engagement_rate,p.performance_score FROM social_content_performance p {$where} ORDER BY p.captured_at DESC,p.id DESC LIMIT 500");$q->execute($args);$rows=$q->fetchAll(PDO::FETCH_ASSOC);
  $summary=[];$times=[];$contents=count($rows);
  foreach($rows as $r){$p=(string)$r['platform'];if(!isset($summary[$p]))$summary[$p]=['platform'=>$p,'samples'=>0,'avg_score'=>0,'avg_engagement_rate'=>0,'avg_reach'=>0,'avg_views'=>0,'formats'=>[]];$summary[$p]['samples']++;$summary[$p]['avg_score']+=(float)$r['performance_score'];$summary[$p]['avg_engagement_rate']+=(float)$r['engagement_rate'];$summary[$p]['avg_reach']+=(float)$r['reach'];$summary[$p]['avg_views']+=(float)$r['views'];$fmt=(string)($r['media_type']?:'text');$summary[$p]['formats'][$fmt]=($summary[$p]['formats'][$fmt]??0)+1;if(!empty($r['published_at'])){$h=(int)date('G',strtotime((string)$r['published_at']));$k=$p.'|'.$h;if(!isset($times[$k]))$times[$k]=['platform'=>$p,'hour'=>$h,'samples'=>0,'score'=>0,'er'=>0];$times[$k]['samples']++;$times[$k]['score']+=(float)$r['performance_score'];$times[$k]['er']+=(float)$r['engagement_rate'];}}
  foreach($summary as &$s){$n=max(1,$s['samples']);$s['avg_score']=round($s['avg_score']/$n,2);$s['avg_engagement_rate']=round($s['avg_engagement_rate']/$n,4);$s['avg_reach']=round($s['avg_reach'],2);$s['avg_views']=round($s['avg_views'],2);}
  $best=array_values($times);foreach($best as &$t){$n=max(1,$t['samples']);$t['avg_score']=round($t['score']/$n,2);$t['avg_engagement_rate']=round($t['er']/$n,4);unset($t['score'],$t['er']);}usort($best,fn($a,$b)=>$b['avg_score']<=>$a['avg_score']?:$b['samples']<=>$a['samples']);
  return ['contents'=>$contents,'platforms'=>array_values($summary),'best_times'=>array_slice($best,0,20),'top_contents'=>$this->topContents($rows,20)];
 }
 private function topContents(array $rows,int $limit):array{usort($rows,fn($a,$b)=>(float)$b['performance_score']<=>(float)$a['performance_score']);return array_map(fn($r)=>['platform'=>$r['platform'],'media_type'=>$r['media_type']?:'text','published_at'=>$r['published_at'],'reach'=>(float)$r['reach'],'views'=>(float)$r['views'],'engagement'=>(float)$r['engagement'],'engagement_rate'=>(float)$r['engagement_rate'],'performance_score'=>(float)$r['performance_score']],array_slice($rows,0,$limit));}
 private function buildPrompt(array $d):string{return 'Analyze this dataset and return strict JSON. Dataset: '.json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
 private function parseJson(string $text):?array{$text=trim($text);if(str_starts_with($text,'```')){$text=preg_replace('/^```(?:json)?\s*/i','',$text)??$text;$text=preg_replace('/\s*```$/','',$text)??$text;}$a=json_decode($text,true);if(is_array($a))return $a;if(preg_match('/\{.*\}/s',$text,$m)){$a=json_decode($m[0],true);if(is_array($a))return $a;}return null;}
 private function decode(string $v,array $fallback):array{$a=json_decode($v,true);return is_array($a)?$a:$fallback;}
 private function persist(?string $platform,array $data,array $analysis,array $result,?int $userId):int{$stmt=$this->db->prepare('INSERT INTO social_ai_content_insights(platform,generated_at,status,content_count,analysis,recommendations,model_code,latency_ms,created_by,created_at) VALUES(?,NOW(),\'success\',?,?,?,?,?,?,NOW())');$recommendations=['winning_patterns'=>$analysis['winning_patterns']??[],'weak_patterns'=>$analysis['weak_patterns']??[],'best_times'=>$analysis['best_times']??[],'platform_strategies'=>$analysis['platform_strategies']??[],'experiments'=>$analysis['experiments']??[],'risk_flags'=>$analysis['risk_flags']??[]];$stmt->execute([$platform,$data['contents'],json_encode($analysis,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),json_encode($recommendations,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),(string)($result['model']??''),(int)($result['latency_ms']??0),$userId]);return (int)$this->db->lastInsertId();}
}
