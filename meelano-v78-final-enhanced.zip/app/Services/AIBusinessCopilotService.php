<?php
declare(strict_types=1);
final class AIBusinessCopilotService {
 public function __construct(private PDO $db,private AIService $ai){}
 public function ask(string $question,?int $userId=null):array{
  if(trim($question)==='')throw new InvalidArgumentException('سؤال هوش تجاری الزامی است.');
  $context=$this->readOnlyContext();
  return $this->ai->run('business_copilot',['prompt'=>$question,'system_prompt'=>'You are MeeLano Business Copilot. Analyze only the supplied read-only business context. Never invent figures. If data is insufficient, say so. Do not execute or propose hidden database queries. For destructive or financial actions, return a recommendation that requires explicit human approval. Context: '.json_encode($context,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)],$userId);
 }
 private function readOnlyContext():array{
  $out=[];$out['products']=(int)$this->db->query("SELECT COUNT(*) FROM products WHERE status='active'")->fetchColumn();$out['orders_today']=(int)$this->db->query("SELECT COUNT(*) FROM orders WHERE created_at>=CURDATE() AND order_status<>'cancelled'")->fetchColumn();$out['sales_today']=(float)$this->db->query("SELECT COALESCE(SUM(payable_amount),0) FROM orders WHERE created_at>=CURDATE() AND payment_status='paid'")->fetchColumn();$out['pending_orders']=(int)$this->db->query("SELECT COUNT(*) FROM orders WHERE order_status IN ('pending','processing','packed','shipped')")->fetchColumn();$out['low_stock']=(int)$this->db->query("SELECT COUNT(*) FROM product_inventory WHERE (current_stock-reserved_stock)<=min_stock")->fetchColumn();$out['customers']=(int)$this->db->query("SELECT COUNT(*) FROM customers")->fetchColumn();return $out;
 }
}
