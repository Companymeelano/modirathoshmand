<?php
declare(strict_types=1);
final class ProductionObservabilityService
{
    public function __construct(private PDO $db) {}
    public function snapshot(): array
    {
        $checks=[];
        $checks['php']=['status'=>version_compare(PHP_VERSION,'8.3.0','>=' )?'pass':'fail','value'=>PHP_VERSION];
        foreach(['pdo','openssl','curl','mbstring','fileinfo'] as $ext){$checks['ext_'.$ext]=['status'=>extension_loaded($ext)?'pass':'fail','value'=>extension_loaded($ext)];}
        $checks['gd']=['status'=>extension_loaded('gd')?'pass':'warn','value'=>extension_loaded('gd')];
        try{$this->db->query('SELECT 1');$checks['database']=['status'=>'pass','value'=>'ok'];}catch(Throwable $e){$checks['database']=['status'=>'fail','value'=>'unavailable'];}
        foreach(['social_publish_jobs','social_publish_attempts','social_publish_recovery_events','ai_video_provider_lifecycle'] as $t){$checks['table_'.$t]=$this->table($t)?['status'=>'pass','value'=>true]:['status'=>'warn','value'=>false];}
        $queue=$this->metric('SELECT COUNT(*) FROM social_publish_jobs WHERE status IN (\'Queued\',\'Retrying\')');
        $stale=$this->metric("SELECT COUNT(*) FROM social_publish_jobs WHERE status='Processing' AND claim_expires_at IS NOT NULL AND claim_expires_at<NOW()");
        return ['generated_at'=>gmdate('c'),'checks'=>$checks,'queue'=>['pending'=>$queue,'stale_processing'=>$stale],'healthy'=>!in_array('fail',array_column($checks,'status'),true)];
    }
    public function persist(array $snapshot): ?int
    {
        if(!$this->table('system_observability_snapshots')) return null;
        $s=$this->db->prepare('INSERT INTO system_observability_snapshots(status,checks_json,metrics_json,created_at) VALUES(?,?,?,NOW())');
        $s->execute([$snapshot['healthy']?'healthy':'degraded',json_encode($snapshot['checks'],JSON_UNESCAPED_UNICODE),json_encode(['queue'=>$snapshot['queue']],JSON_UNESCAPED_UNICODE)]);return (int)$this->db->lastInsertId();
    }
    public function recent(int $limit=20):array
    {
        if(!$this->table('system_observability_snapshots')) return [];
        $limit=max(1,min(100,$limit));$q=$this->db->query('SELECT id,status,checks_json,metrics_json,created_at FROM system_observability_snapshots ORDER BY id DESC LIMIT '.$limit);return $q->fetchAll(PDO::FETCH_ASSOC);
    }
    private function metric(string $sql):int{try{return (int)$this->db->query($sql)->fetchColumn();}catch(Throwable $e){return 0;}}
    private function table(string $name):bool{try{$s=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$s->execute([$name]);return (int)$s->fetchColumn()===1;}catch(Throwable $e){return false;}}
}
