<?php
declare(strict_types=1);
final class SocialQueueService { public function __construct(private PDO $db){} public function enqueue(int $accountId,string $platform,string $payload,string $when):int{$q=$this->db->prepare('INSERT INTO social_publish_jobs(account_id,platform,status,scheduled_at,attempts,payload,created_at,updated_at) VALUES(?,?,?,?,0,?,NOW(),NOW())');$q->execute([$accountId,$platform,'Queued',$when,$payload]);return (int)$this->db->lastInsertId();}}
