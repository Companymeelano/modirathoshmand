<?php
declare(strict_types=1);
final class OrderService {
    public function __construct(private PDO $db,private InventoryService $inv,private ?Audit $audit=null,private ?CustomerService $customers=null,private ?ShippingService $shipping=null){}
    public function create(array $customer,array $items,?int $userId=null):int {
        if(!$items) throw new InvalidArgumentException('سبد سفارش خالی است.');
        $this->db->beginTransaction();
        try {
            $number='ML-'.date('YmdHis').'-'.strtoupper(bin2hex(random_bytes(4)));
            $subtotal=0.0; $weight=0.0; $normalized=[];
            foreach($items as $i){
                $pid=(int)($i['product_id']??0); $vid=isset($i['variant_id'])&&$i['variant_id']!==''?(int)$i['variant_id']:null; $qty=(float)($i['quantity']??0);
                if($pid<1||$qty<=0) throw new InvalidArgumentException('آیتم سفارش نامعتبر است.');
                $p=$this->db->prepare('SELECT id,title,sku,sale_price_retail,tax_percent,duty_percent,default_warehouse_id FROM products WHERE id=? AND status="active" FOR UPDATE');
                $p->execute([$pid]); $r=$p->fetch(PDO::FETCH_ASSOC); if(!$r) throw new RuntimeException('محصول نامعتبر یا غیرفعال است.');
                $extra=0.0; $vtitle=null; $sku=$r['sku'];
                if($vid!==null){$v=$this->db->prepare('SELECT id,variant_title,sku,extra_price FROM product_variants WHERE id=? AND product_id=? AND status="active" FOR UPDATE');$v->execute([$vid,$pid]);$vr=$v->fetch(PDO::FETCH_ASSOC);if(!$vr)throw new RuntimeException('تنوع محصول نامعتبر است.');$extra=(float)$vr['extra_price'];$vtitle=$vr['variant_title'];$sku=$vr['sku']?:$sku;}
                $unit=(float)$r['sale_price_retail']+$extra; $line=$unit*$qty; $subtotal+=$line;
                $normalized[]=['row'=>$r,'variant_id'=>$vid,'variant_title'=>$vtitle,'sku'=>$sku,'qty'=>$qty,'unit'=>$unit,'line'=>$line];
            }
            $customerId=$this->customers?->upsertFromOrder($customer);
            $ship=['available'=>true,'amount'=>0.0,'rule_id'=>null,'name'=>null,'region_type'=>null];
            if($this->shipping)$ship=$this->shipping->quote($customer,$subtotal,$weight);
            if(!$ship['available']) throw new DomainException('روش ارسال برای این سفارش پیدا نشد.');
            $payable=$subtotal+(float)$ship['amount'];
            $q=$this->db->prepare('INSERT INTO orders(order_number,user_id,customer_name,customer_mobile,customer_email,province,city,address,postal_code,subtotal_amount,shipping_amount,cargo_amount,payable_amount,payment_method,payment_status,order_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            $q->execute([$number,$userId,$customer['name']??'',$customer['mobile']??'',$customer['email']??null,$customer['province']??null,$customer['city']??null,$customer['address']??null,$customer['postal_code']??null,$subtotal,$ship['amount'],0,$payable,null,'pending','pending']);
            $id=(int)$this->db->lastInsertId();
            foreach($normalized as $n){$r=$n['row'];$this->db->prepare('INSERT INTO order_items(order_id,product_id,variant_id,product_title,variant_title,sku,quantity,unit_price,extra_price,tax_percent,duty_percent,line_total) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$id,$r['id'],$n['variant_id'],$r['title'],$n['variant_title'],$n['sku'],$n['qty'],$r['sale_price_retail'],$n['unit']-(float)$r['sale_price_retail'],$r['tax_percent'],$r['duty_percent'],$n['line']]);if($r['default_warehouse_id'])$this->inv->reserveWithinTransaction((int)$r['id'],(int)$r['default_warehouse_id'],$n['qty'],$id,$n['variant_id']);}
            $this->db->prepare('INSERT INTO shipping_quotes(order_id,province,city,subtotal,amount,rule_id,created_at) VALUES(?,?,?,?,?,?,NOW())')->execute([$id,$customer['province']??null,$customer['city']??null,$subtotal,$ship['amount'],$ship['rule_id']]);
            if($customerId!==null){$this->db->prepare('INSERT IGNORE INTO customer_order_links(customer_id,order_id) VALUES(?,?)')->execute([$customerId,$id]);$this->db->prepare('UPDATE customers SET total_orders=total_orders+1,total_spent=total_spent+?,last_order_at=NOW(),segment=CASE WHEN total_orders+1>=10 THEN "vip" WHEN total_orders+1>=2 THEN "returning" ELSE segment END,updated_at=NOW() WHERE id=?')->execute([$payable,$customerId]);}
            if($this->audit)$this->audit->log($userId,'create','orders','order',$id,['order_number'=>$number,'subtotal'=>$subtotal,'shipping'=>$ship['amount']]);
            $this->db->commit(); return $id;
        } catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}
    }
    public function releaseReservations(int $orderId,?int $userId=null):void {$this->transitionReservations($orderId,'release',$userId);}
    public function commitReservations(int $orderId,?int $userId=null):void {$this->transitionReservations($orderId,'commit',$userId);}
    private function transitionReservations(int $orderId,string $mode,?int $userId):void {
        $this->db->beginTransaction();
        try{$q=$this->db->prepare('SELECT oi.product_id,oi.variant_id,oi.quantity,p.default_warehouse_id FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=? FOR UPDATE');$q->execute([$orderId]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);if(!$rows)throw new RuntimeException('سفارش یافت نشد.');foreach($rows as $r){if(!$r['default_warehouse_id'])continue;if($mode==='release')$this->inv->releaseWithinTransaction((int)$r['product_id'],(int)$r['default_warehouse_id'],(float)$r['quantity'],$orderId,$r['variant_id']!==null?(int)$r['variant_id']:null,(int)$r['id']);else $this->inv->commitWithinTransaction((int)$r['product_id'],(int)$r['default_warehouse_id'],(float)$r['quantity'],$orderId,$r['variant_id']!==null?(int)$r['variant_id']:null,(int)$r['id']);}$this->db->commit();if($this->audit)$this->audit->log($userId,$mode==='release'?'release':'commit_inventory','orders','order',$orderId,['items'=>count($rows)]);}catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}
    }
}
