<?php
declare(strict_types=1);
final class PricingPolicyService {
    public function __construct(private PDO $db, private ?Audit $audit=null) {}
    public function propose(int $productId, ?int $variantId, float $cost, float $marketPrice, float $demand=1.0, float $stockFactor=1.0, ?int $ruleSetId=null, ?int $userId=null): array {
        if($productId<1||$cost<0) throw new DomainException('پارامتر قیمت‌گذاری نامعتبر است.');
        $this->assertProductVariant($productId,$variantId);
        $rs=$ruleSetId!==null?$this->getRuleSet($ruleSetId):$this->defaultRuleSet();
        $baseMargin=(float)$rs['target_margin']; $target=$cost*(1+$baseMargin/100);
        $marketAdj=$marketPrice>0?($marketPrice-$target)*$this->ruleWeight($rs['id'],'market_weight'):0;
        $demandAdj=$target*($demand-1)*$this->ruleWeight($rs['id'],'demand_weight');
        $stockAdj=$target*($stockFactor-1)*$this->ruleWeight($rs['id'],'stock_weight');
        $proposed=$target+$marketAdj+$demandAdj+$stockAdj;
        $minMargin=(float)$rs['min_margin']; $maxMargin=$rs['max_margin']!==null?(float)$rs['max_margin']:null;
        $floor=max($cost*(1+$minMargin/100),(float)($this->ruleValue($rs['id'],'min_price')??0));
        $ceiling=$maxMargin!==null?$cost*(1+$maxMargin/100):null;
        $ruleMax=$this->ruleValue($rs['id'],'max_price'); if($ruleMax!==null)$ceiling=$ceiling===null?(float)$ruleMax:min($ceiling,(float)$ruleMax);
        $proposed=max($proposed,$floor); if($ceiling!==null)$proposed=min($proposed,$ceiling);
        $round=max(1,(float)$rs['rounding']); $proposed=round($proposed/$round)*$round;
        $proposed=max($proposed,$floor); if($ceiling!==null)$proposed=min($proposed,$ceiling);
        $current=$this->currentPrice($productId,$variantId);
        $status=$rs['mode']==='automatic'?'approved':'pending'; $id=null;
        if($rs['mode']!=='automatic'){
            $i=$this->db->prepare('INSERT INTO product_price_approvals(product_id,variant_id,rule_set_id,old_price,proposed_price,status,requested_by,created_at) VALUES(?,?,?,?,?,?,?,NOW())');
            $i->execute([$productId,$variantId,$rs['id'],$current,$proposed,$status,$userId]); $id=(int)$this->db->lastInsertId();
        }
        if($this->audit)$this->audit->log($userId,'price_propose','pricing','product',$productId,['approval_id'=>$id,'old'=>$current,'new'=>$proposed]);
        return ['product_id'=>$productId,'variant_id'=>$variantId,'current_price'=>$current,'recommended_price'=>$proposed,'floor_price'=>$floor,'ceiling_price'=>$ceiling,'margin_percent'=>round((($proposed-$cost)/max($cost,0.00001))*100,3),'mode'=>$rs['mode'],'status'=>$status,'approval_id'=>$id];
    }
    public function review(int $approvalId,string $decision,?string $note,?int $userId=null):void {
        if(!in_array($decision,['approved','rejected'],true)) throw new DomainException('تصمیم نامعتبر است.');
        $this->db->beginTransaction();
        try{
            $q=$this->db->prepare('SELECT * FROM product_price_approvals WHERE id=? FOR UPDATE');$q->execute([$approvalId]);$r=$q->fetch(PDO::FETCH_ASSOC);
            if(!$r)throw new RuntimeException('درخواست قیمت‌گذاری یافت نشد.');
            if($r['status']!=='pending')throw new DomainException('این درخواست قبلاً بررسی شده است.');
            $this->db->prepare('UPDATE product_price_approvals SET status=?,reviewed_by=?,review_note=?,reviewed_at=NOW() WHERE id=?')->execute([$decision,$userId,$note,$approvalId]);
            $this->db->commit(); if($this->audit)$this->audit->log($userId,'price_review','pricing','approval',$approvalId,['decision'=>$decision]);
        }catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}
    }
    public function apply(int $approvalId,?int $userId=null):void {
        $this->db->beginTransaction();
        try{
            $q=$this->db->prepare('SELECT * FROM product_price_approvals WHERE id=? FOR UPDATE');$q->execute([$approvalId]);$r=$q->fetch(PDO::FETCH_ASSOC);
            if(!$r)throw new RuntimeException('درخواست قیمت‌گذاری یافت نشد.');
            if($r['status']!=='approved')throw new DomainException('فقط درخواست تاییدشده قابل اعمال است.');
            $this->assertProductVariant((int)$r['product_id'],$r['variant_id']!==null?(int)$r['variant_id']:null);
            $old=$this->currentPrice((int)$r['product_id'],null); $new=(float)$r['proposed_price'];
            $u=$this->db->prepare('UPDATE products SET sale_price_retail=?,updated_at=NOW() WHERE id=?');$u->execute([$new,$r['product_id']]);
            $this->db->prepare('INSERT INTO product_price_history(product_id,variant_id,old_price,new_price,source,reason,created_by,created_at) VALUES(?,?,?,?,?,?,?,NOW())')->execute([$r['product_id'],$r['variant_id'],$old,$new,'policy_approval','Approved pricing policy #'.$approvalId,$userId]);
            $this->db->prepare('UPDATE product_price_approvals SET status="applied",applied_at=NOW() WHERE id=?')->execute([$approvalId]);
            $this->db->commit(); if($this->audit)$this->audit->log($userId,'price_apply','pricing','approval',$approvalId,['old'=>$old,'new'=>$new]);
        }catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}
    }
    private function assertProductVariant(int $p,?int $v):void{
        $q=$this->db->prepare('SELECT id FROM products WHERE id=?');$q->execute([$p]);if(!$q->fetchColumn())throw new RuntimeException('محصول یافت نشد.');
        if($v!==null){$q=$this->db->prepare('SELECT id FROM product_variants WHERE id=? AND product_id=?');$q->execute([$v,$p]);if(!$q->fetchColumn())throw new RuntimeException('تنوع محصول نامعتبر است.');}
    }
    private function currentPrice(int $p,?int $v):?float{$q=$this->db->prepare('SELECT sale_price_retail FROM products WHERE id=?');$q->execute([$p]);$x=$q->fetchColumn();return $x===false?null:(float)$x;}
    private function getRuleSet(int $id):array{$q=$this->db->prepare('SELECT * FROM price_rule_sets WHERE id=? AND is_active=1');$q->execute([$id]);$r=$q->fetch(PDO::FETCH_ASSOC);if(!$r)throw new RuntimeException('Price rule set not found');return $r;}
    private function defaultRuleSet():array{$q=$this->db->query('SELECT * FROM price_rule_sets WHERE is_active=1 ORDER BY id LIMIT 1');$r=$q->fetch(PDO::FETCH_ASSOC);if(!$r)throw new RuntimeException('هیچ Price Rule فعالی وجود ندارد.');return $r;}
    private function ruleWeight(int $ruleSet,string $column):float{$q=$this->db->prepare("SELECT {$column} FROM price_policy_rules WHERE rule_set_id=? AND is_active=1 ORDER BY priority LIMIT 1");$q->execute([$ruleSet]);$v=$q->fetchColumn();return $v===false?0:(float)$v;}
    private function ruleValue(int $ruleSet,string $column):?float{$q=$this->db->prepare("SELECT {$column} FROM price_policy_rules WHERE rule_set_id=? AND is_active=1 AND {$column} IS NOT NULL ORDER BY priority LIMIT 1");$q->execute([$ruleSet]);$v=$q->fetchColumn();return $v===false?null:(float)$v;}
}
