<?php
declare(strict_types=1);
final class AIVideoVariantOrchestratorService {
 public function __construct(private PDO $db, private Audit $audit, private AISocialVideoDirectorService $director, private ?AITrendIntelligenceService $trends=null, private ?AICreativeLearningService $learning=null, private ?StrategyBanditService $bandit=null){}
 public function createBatch(int $productId,array $platforms,int $variants,int $userId,?int $sourceAssetId=null,?int $campaignId=null):array {
  $variants=max(2,min(6,$variants));
  $cat=$this->categoryId($productId); $bandit=$this->bandit ?: new StrategyBanditService($this->db,$this->audit); $items=[]; $trendSvc=$this->trends ?: new AITrendIntelligenceService($this->db,new AIService($this->db,$this->audit),$this->audit); $learnSvc=$this->learning ?: new AICreativeLearningService($this->db,$this->audit);
  foreach($platforms as $platform){
   $selected=$bandit->selectStrategies($platform,$cat,$variants);
   $strategies=array_map(fn($x)=>$this->strategyDefinition((string)$x['name'])+$x,$selected);
   $trend=$trendSvc->liveForVideo($platform,$productId);
   $weights=is_array($trend['recommended_variant_weights']??null)?$trend['recommended_variant_weights']:[]; $learning=$learnSvc->hint($platform,$productId);
   foreach($strategies as $i=>$strategy){
    if($weights){$strategy['trend_weight_hint']=$weights[$strategy['name']]??null;}
    if(!empty($learning['available'])){ $strategy['learning_weight_hint']=$learning['weights'][$strategy['name']]??null; $strategy['learning_confidence']=$learning['confidence']; $strategy['learning_snapshot_id']=$learning['snapshot_id']; $strategy['learning_hook_hint']=$learning['hook_weights'][$strategy['hook_style']]??null; $strategy['learning_cta_hint']=$learning['cta_weights'][$strategy['cta_style']]??null; }
    $strategy['live_trend_context']=$trend;
    $r=$this->director->create($productId,[$platform],$userId,$sourceAssetId,$campaignId,array_merge($strategy,['variant_index'=>$i+1,'variant_total'=>$variants]));
    foreach(($r['jobs']??[]) as $j)$items[]=['job_id'=>(int)$j['id'],'platform'=>$platform,'variant_index'=>$i+1,'strategy'=>$strategy];
   }
  }
  if(!$items)throw new InvalidArgumentException('هیچ Variant معتبری ساخته نشد.');
  $this->db->prepare('INSERT INTO social_ai_video_variant_batches(product_id,campaign_id,variant_count,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,NOW(),NOW())')->execute([$productId,$campaignId,$variants,'queued',$userId]);
  $batchId=(int)$this->db->lastInsertId();
  $ins=$this->db->prepare('INSERT INTO social_ai_video_variant_batch_items(batch_id,job_id,platform,variant_index,strategy_json,created_at) VALUES(?,?,?,?,?,NOW())');
  foreach($items as $x)$ins->execute([$batchId,$x['job_id'],$x['platform'],$x['variant_index'],json_encode($x['strategy'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
  $this->audit->log($userId,'ai_video_variant_batch_created','social_ai_video_variant_batches',$batchId,$batchId,['jobs'=>count($items),'variants'=>$variants]);
  return $this->getBatch($batchId);
 }
 public function runBatch(int $batchId,int $userId):array {
  $b=$this->getBatch($batchId); $this->db->prepare("UPDATE social_ai_video_variant_batches SET status='processing',updated_at=NOW() WHERE id=?")->execute([$batchId]);
  $jobs=[]; foreach($b['items'] as $it){try{$jobs[]=$this->director->run((int)$it['job_id'],$userId);}catch(Throwable $e){$jobs[]=['id'=>(int)$it['job_id'],'status'=>'failed','error'=>$e->getMessage()];}}
  $ids=array_map(fn($x)=>(int)$x['job_id'],$b['items']); $selection=$this->director->selectWinners($ids);
  $bandit=$this->bandit ?: new StrategyBanditService($this->db,$this->audit); $byPlatform=[];
  foreach($b['items'] as $it){$byPlatform[(string)$it['platform']][]=$it;}
  foreach($byPlatform as $platform=>$items){
   $played=[]; foreach($items as $it){$sx=json_decode((string)$it['strategy_json'],true)?:[]; if(!empty($sx['name']))$played[]=(string)$sx['name'];}
   $winner=null; $reward=0; foreach(($selection['winners']??[]) as $w){$wid=(int)($w['id']??$w['job_id']??0); foreach($items as $it) if((int)$it['job_id']===$wid){$sx=json_decode((string)$it['strategy_json'],true)?:[];$winner=(string)($sx['name']??'');$reward=((float)($w['variant_score']??0))/100;break 2;}}
   if($winner!==null)$bandit->recordBatchOutcomes($platform,(int)$b['category_id'],$played,$winner,$reward);
  }
  $active=array_filter($selection['all'],fn($x)=>in_array($x['status'],['queued','analyzing','processing'],true)); $status=$active?'processing':($selection['winners']?'completed':'failed');
  $this->db->prepare('UPDATE social_ai_video_variant_batches SET status=?,winner_json=?,updated_at=NOW() WHERE id=?')->execute([$status,json_encode($selection['winners'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$batchId]);
  return $this->getBatch($batchId);
 }
 public function getBatch(int $id):array {
  $q=$this->db->prepare('SELECT b.*,p.category_id FROM social_ai_video_variant_batches b LEFT JOIN products p ON p.id=b.product_id WHERE b.id=?');$q->execute([$id]);$b=$q->fetch(PDO::FETCH_ASSOC);if(!$b)throw new InvalidArgumentException('Variant Batch یافت نشد.');
  $q=$this->db->prepare('SELECT * FROM social_ai_video_variant_batch_items WHERE batch_id=? ORDER BY platform,variant_index');$q->execute([$id]);$b['items']=$q->fetchAll(PDO::FETCH_ASSOC);
  foreach($b['items'] as &$it){$x=$this->director->get((int)$it['job_id']);$it['job']=$x;$it['strategy_json']=json_decode((string)$it['strategy_json'],true)?:[];}unset($it);$b['winner_json']=json_decode((string)$b['winner_json'],true)?:[];return $b;
 }
 private function categoryId(int $productId):int {try{$q=$this->db->prepare('SELECT category_id FROM products WHERE id=? LIMIT 1');$q->execute([$productId]);return (int)($q->fetchColumn()?:0);}catch(Throwable){return 0;}}
 private function strategyDefinition(string $name):array {
  $base=[
   'hook-first'=>['name'=>'hook-first','hook_style'=>'pattern_interrupt','pacing'=>'fast','camera'=>'close_product_macro','cta_style'=>'direct'],
   'benefit-first'=>['name'=>'benefit-first','hook_style'=>'benefit_led','pacing'=>'medium','camera'=>'hero_product_tracking','cta_style'=>'benefit'],
   'story-first'=>['name'=>'story-first','hook_style'=>'micro_story','pacing'=>'medium','camera'=>'cinematic_sequence','cta_style'=>'soft'],
   'proof-first'=>['name'=>'proof-first','hook_style'=>'proof_demo','pacing'=>'fast','camera'=>'detail_demo','cta_style'=>'evidence'],
   'trend-adaptive'=>['name'=>'trend-adaptive','hook_style'=>'current_trend_adapted','pacing'=>'dynamic','camera'=>'platform_native','cta_style'=>'native'],
   'minimal-premium'=>['name'=>'minimal-premium','hook_style'=>'curiosity','pacing'=>'slow','camera'=>'luxury_hero','cta_style'=>'minimal'],
  ]; return $base[$name]??$base['hook-first'];
 }
}
