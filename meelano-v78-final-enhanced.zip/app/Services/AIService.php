<?php
declare(strict_types=1);
final class AIService {
 public function __construct(private PDO $db,private Audit $audit){}
 public function run(string $task,array $input,?int $userId=null,?int $preferredModelId=null):array{
  if($task==='')throw new InvalidArgumentException('AI task الزامی است.');
  $providers=$this->providers($preferredModelId);if(!$providers){$this->audit->log($userId,'ai_no_provider','ai',null,null,['task'=>$task]);return ['ok'=>false,'error'=>'No active AI provider configured'];}
  $last=null;$attempt=0;
  foreach($providers as $row){$attempt++;$started=microtime(true);$log=$this->createLog($row,$task,$input,$userId);
   try{$provider=new HttpAIProvider($row,$row);$result=$provider->generate($task,$input);$this->finishLog($log,$result,null,'success');$result['attempt']=$attempt;return $result;
   }catch(AIProviderException $e){$last=$e;$this->finishLog($log,['provider_request_id'=>$e->providerRequestId()],$e,$e->httpStatus()===429?'rate_limited':($e->retryable()?'timeout':'failed'));continue;
   }catch(Throwable $e){$last=$e;$this->finishLog($log,[],$e,'failed');}
  }
  $this->audit->log($userId,'ai_failed','ai',null,null,['task'=>$task,'attempts'=>$attempt]);return ['ok'=>false,'error'=>$last instanceof Throwable?'AI request could not be completed':'No AI provider configured'];
 }
 public function runVision(string $task,array $input,?int $userId=null,?int $preferredModelId=null):array{
  if($task==='')throw new InvalidArgumentException('AI task الزامی است.');
  $providers=$this->providersByCapabilities($preferredModelId,['vision','chat','completion']); if(!$providers){$this->audit->log($userId,'ai_no_vision_provider','ai',null,null,['task'=>$task]);return ['ok'=>false,'error'=>'No vision-capable AI provider configured'];}
  $last=null;$attempt=0; foreach($providers as $row){$attempt++;$log=$this->createLog($row,$task,$input,$userId); try{$provider=new HttpAIProvider($row,$row);$result=$provider->generateVision($task,$input);$this->finishLog($log,$result,null,'success');$result['attempt']=$attempt;return $result;}catch(Throwable $e){$last=$e;$this->finishLog($log,[],$e,$e instanceof AIProviderException && $e->httpStatus()===429?'rate_limited':'failed');continue;}}
  $this->audit->log($userId,'ai_vision_failed','ai',null,null,['task'=>$task,'attempts'=>$attempt]);return ['ok'=>false,'error'=>$last instanceof Throwable?'Vision analysis could not be completed':'No AI provider configured'];
 }
 private function providersByCapabilities(?int $preferredModelId,array $capabilities):array{
  $pCols=$this->columns('ai_providers');$mCols=$this->columns('ai_models');$providerIdCol=in_array('id',$pCols,true)?'p.id':'p.provider_id';$modelProviderCol=in_array('provider_id',$mCols,true)?'m.provider_id':'m.ai_provider_id';$providerActive=in_array('is_active',$pCols,true)?'p.is_active=1':'1=1';$modelActive=in_array('is_active',$mCols,true)?'m.is_active=1':'1=1';
  $select=["$providerIdCol AS provider_id",'p.provider_code','p.display_name']; foreach(['api_key','api_key_enc','api_secret','api_secret_enc','base_url','api_version','default_headers','extra_config'] as $c)if(in_array($c,$pCols,true))$select[]='p.'.$c; foreach(['id AS model_id','model_code','capability','max_output_tokens','default_temperature','supports_json_mode','supports_tools'] as $c){$base=explode(' AS ',$c)[0];if(in_array($base,$mCols,true))$select[]='m.'.$c;} $place=implode(',',array_fill(0,count($capabilities),'?'));$sql='SELECT '.implode(',',$select).' FROM ai_providers p JOIN ai_models m ON '.$modelProviderCol.'='.$providerIdCol.' AND '.$modelActive.' WHERE '.$providerActive.' AND m.capability IN ('.$place.') ORDER BY '.(in_array('is_default',$pCols,true)?'p.is_default DESC,':'').'p.id ASC,m.id ASC';$q=$this->db->prepare($sql);$q->execute($capabilities);return $q->fetchAll(PDO::FETCH_ASSOC);
 }
 public function testProvider(int $providerId):array{
  $rows=$this->providers(null);$r=null;foreach($rows as $row)if((int)$row['provider_id']===$providerId){$r=$row;break;}if(!$r)throw new InvalidArgumentException('Provider یا مدل فعال یافت نشد.');
  $t=microtime(true);try{$res=(new HttpAIProvider($r,$r))->generate('provider_test',['prompt'=>'Reply with exactly: MeeLano AI OK','system_prompt'=>'You are a connectivity test. Return only the requested text.']);$this->updateProviderTest($providerId,'ok',mb_substr((string)$res['text'],0,500));return ['ok'=>true,'provider'=>$r['provider_code'],'model'=>$r['model_code'],'latency_ms'=>(int)round((microtime(true)-$t)*1000),'text'=>$res['text']];}catch(Throwable $e){$this->updateProviderTest($providerId,'failed',mb_substr($e->getMessage(),0,500));throw $e;}
 }
 private function providers(?int $preferredModelId):array{
  $pCols=$this->columns('ai_providers');$mCols=$this->columns('ai_models');
  $providerIdCol=in_array('id',$pCols,true)?'p.id':'p.provider_id';
  $modelProviderCol=in_array('provider_id',$mCols,true)?'m.provider_id':'m.ai_provider_id';
  $providerActive=in_array('is_active',$pCols,true)?'p.is_active=1':(in_array('active',$pCols,true)?'p.active=1':'1=1');
  $modelActive=in_array('is_active',$mCols,true)?'m.is_active=1':(in_array('active',$mCols,true)?'m.active=1':'1=1');
  $select=["$providerIdCol AS provider_id","p.provider_code","p.display_name"];
  foreach(['api_key','api_key_enc','api_secret','api_secret_enc','base_url','api_version','default_headers','extra_config'] as $c)if(in_array($c,$pCols,true))$select[]='p.'.$c;
  if(in_array('organization_id',$pCols,true))$select[]='p.organization_id';elseif(in_array('org',$pCols,true))$select[]='p.org AS organization_id';
  if(in_array('project_id',$pCols,true))$select[]='p.project_id';elseif(in_array('project',$pCols,true))$select[]='p.project AS project_id';
  foreach(['id AS model_id','model_code','capability','max_output_tokens','default_temperature','supports_json_mode','supports_tools'] as $c){$base=explode(' AS ',$c)[0];if(in_array($base,$mCols,true))$select[]='m.'.$c;}
  if(in_array('sort_order',$pCols,true))$select[]='p.sort_order';else $select[]='0 AS sort_order';
  $sql='SELECT '.implode(',',$select).' FROM ai_providers p JOIN ai_models m ON '.$modelProviderCol.'='.$providerIdCol.' AND '.$modelActive.' WHERE '.$providerActive.' AND m.capability IN (\'chat\',\'completion\')';$args=[];
  if($preferredModelId){$sql.=' AND m.id=?';$args[]=$preferredModelId;}
  $sql.=' ORDER BY '.(in_array('is_default',$pCols,true)?'p.is_default DESC,':'').'p.sort_order ASC'.(in_array('is_default',$mCols,true)?',m.is_default DESC':'').',m.id ASC';
  $q=$this->db->prepare($sql);$q->execute($args);return $q->fetchAll(PDO::FETCH_ASSOC);
 }
 private function columns(string $table):array{$q=$this->db->query('SHOW COLUMNS FROM `'.$table.'`');return array_map(static fn($r)=>(string)$r['Field'],$q->fetchAll(PDO::FETCH_ASSOC));}
 private function updateProviderTest(int $id,string $status,string $message):void{$cols=$this->columns('ai_providers');$sets=[];$args=[];if(in_array('last_tested_at',$cols,true))$sets[]='last_tested_at=NOW()';if(in_array('last_test_status',$cols,true)){$sets[]='last_test_status=?';$args[]=$status;}if(in_array('last_test_message',$cols,true)){$sets[]='last_test_message=?';$args[]=$message;}if($sets){$args[]=$id;$this->db->prepare('UPDATE ai_providers SET '.implode(',',$sets).' WHERE id=?')->execute($args);}}
 private function createLog(array $r,string $task,array $input,?int $userId):int{$req=(string)($_SERVER['REQUEST_ID']??bin2hex(random_bytes(16)));$s=$this->db->prepare("INSERT INTO ai_usage_logs(ai_provider_id,ai_model_id,user_id,request_id,purpose,status,request_payload,ip_address,created_at) VALUES(?,?,?,?,?,'pending',?,?,NOW())");$safe=['task'=>$task,'input'=>$this->redact($input)];$s->execute([(int)$r['provider_id'],(int)$r['model_id'],$userId,$req,$task,json_encode($safe,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$_SERVER['REMOTE_ADDR']??null]);return (int)$this->db->lastInsertId();}
 private function finishLog(int $id,array $result,?Throwable $e,string $status):void{$in=(int)($result['prompt_tokens']??0);$out=(int)($result['completion_tokens']??0);$cost=null;$q=$this->db->prepare("UPDATE ai_usage_logs SET status=?,provider_request_id=?,prompt_tokens=?,completion_tokens=?,total_tokens=?,latency_ms=?,response_payload=?,error_message=? WHERE id=?");$q->execute([$status,(string)($result['provider_request_id']??''),$in,$out,$in+$out,(int)($result['latency_ms']??0),json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$e?mb_substr($e->getMessage(),0,500):null,$id]);}
 private function redact(array $input):array{unset($input['api_key'],$input['api_secret'],$input['token'],$input['password']);return $input;}
}
