<?php
declare(strict_types=1);
final class ReturnService {
    private const ALLOWED=['requested'=>['approved','rejected','cancelled'],'approved'=>['received','cancelled'],'received'=>['restocked'],'restocked'=>['refunded'],'rejected'=>[],'refunded'=>[],'cancelled'=>[]];
    public function __construct(private PDO $db,private ?Audit $audit=null,private ?RefundService $refunds=null){}
    public function request(int $orderId,?int $orderItemId,?float $qty,string $reason,?int $userId=null):int {
        $this->db->beginTransaction();
        try{
            $q=$this->db->prepare('SELECT id,payment_status,order_status FROM orders WHERE id=? FOR UPDATE');$q->execute([$orderId]);$o=$q->fetch(PDO::FETCH_ASSOC);
            if(!$o)throw new RuntimeException('سفارش یافت نشد.');
            if(!in_array($o['payment_status'],['paid','refunded'],true))throw new RuntimeException('فقط سفارش پرداخت‌شده قابل مرجوعی است.');
            if($orderItemId===null)throw new DomainException('برای کنترل موجودی، آیتم سفارش باید مشخص شود.');
            $i=$this->db->prepare('SELECT id,product_id,variant_id,quantity FROM order_items WHERE id=? AND order_id=? FOR UPDATE');$i->execute([$orderItemId,$orderId]);$item=$i->fetch(PDO::FETCH_ASSOC);if(!$item)throw new RuntimeException('آیتم سفارش نامعتبر است.');
            if($qty===null||$qty<=0||$qty>(float)$item['quantity'])throw new DomainException('تعداد مرجوعی نامعتبر است.');
            $sum=$this->db->prepare("SELECT COALESCE(SUM(quantity),0) FROM order_returns WHERE order_item_id=? AND status IN ('requested','approved','received','restocked','refunded')");$sum->execute([$orderItemId]);
            if((float)$sum->fetchColumn()+$qty>(float)$item['quantity']+0.000001)throw new DomainException('بخشی از این آیتم قبلاً برای مرجوعی ثبت شده است.');
            $this->db->prepare('INSERT INTO order_returns(order_id,order_item_id,quantity,reason,status,requested_by) VALUES(?,?,?,?,?,?)')->execute([$orderId,$orderItemId,$qty,$reason,'requested',$userId]);
            $id=(int)$this->db->lastInsertId();$this->db->commit();
            if($this->audit)$this->audit->log($userId,'create','returns','return',$id,['order_id'=>$orderId,'order_item_id'=>$orderItemId,'quantity'=>$qty]);return $id;
        }catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}
    }
    public function transition(int $returnId,string $to,?int $userId=null):void {
        $this->db->beginTransaction();
        try{
            $q=$this->db->prepare('SELECT * FROM order_returns WHERE id=? FOR UPDATE');$q->execute([$returnId]);$r=$q->fetch(PDO::FETCH_ASSOC);if(!$r)throw new RuntimeException('درخواست مرجوعی یافت نشد.');
            $from=$r['status'];if(!in_array($to,self::ALLOWED[$from]??[],true))throw new DomainException("تغییر وضعیت مجاز نیست: {$from} -> {$to}");$now=date('Y-m-d H:i:s');
            if($to==='restocked')$this->restock($r,$userId);
            $fields='status=?,updated_at=?';$params=[$to,$now];
            if($to==='approved'){$fields.=',approved_by=?,approved_at=?';$params[]=$userId;$params[]=$now;}
            if($to==='received'){$fields.=',received_at=?';$params[]=$now;}
            if($to==='refunded'){$fields.=',refunded_at=?';$params[]=$now;}
            $params[]=$returnId;$this->db->prepare("UPDATE order_returns SET {$fields} WHERE id=?")->execute($params);
            $this->db->commit();if($this->audit)$this->audit->log($userId,'transition','returns','return',$returnId,['from'=>$from,'to'=>$to]);
        }catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;}
    }
    private function restock(array $r,?int $userId):void {
        $q=$this->db->prepare('SELECT oi.product_id,oi.variant_id,oi.quantity,p.default_warehouse_id FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.id=? FOR UPDATE');$q->execute([(int)$r['order_item_id']]);$i=$q->fetch(PDO::FETCH_ASSOC);
        if(!$i)throw new RuntimeException('آیتم سفارش برای استرداد موجودی یافت نشد.');if(!$i['default_warehouse_id'])throw new RuntimeException('انبار پیش‌فرض محصول مشخص نیست.');
        $qty=(float)$r['quantity'];
        $a=$this->db->prepare('INSERT INTO return_inventory_actions(return_id,order_item_id,product_id,variant_id,warehouse_id,quantity,status,applied_by,applied_at) VALUES(?,?,?,?,?,?,"applied",?,NOW())');
        try{$a->execute([(int)$r['id'],(int)$r['order_item_id'],(int)$i['product_id'],$i['variant_id']!==null?(int)$i['variant_id']:null,(int)$i['default_warehouse_id'],$qty,$userId]);}
        catch(PDOException $e){if((int)$e->errorInfo[1]===1062)throw new DomainException('موجودی این مرجوعی قبلاً ثبت شده است.');throw $e;}
        $sql='SELECT id FROM product_inventory WHERE product_id=? AND warehouse_id=? AND '.($i['variant_id']===null?'variant_id IS NULL':'variant_id=?').' FOR UPDATE';$params=$i['variant_id']===null?[(int)$i['product_id'],(int)$i['default_warehouse_id']]:[(int)$i['product_id'],(int)$i['default_warehouse_id'],(int)$i['variant_id']];$s=$this->db->prepare($sql);$s->execute($params);$row=$s->fetch(PDO::FETCH_ASSOC);if(!$row)throw new RuntimeException('رکورد موجودی انبار یافت نشد.');
        $this->db->prepare('UPDATE product_inventory SET current_stock=current_stock+?,updated_at=NOW() WHERE id=?')->execute([$qty,$row['id']]);
        $this->db->prepare('INSERT INTO inventory_movements(product_id,variant_id,warehouse_id,movement_type,quantity,reference_type,reference_id,note,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())')->execute([(int)$i['product_id'],$i['variant_id']!==null?(int)$i['variant_id']:null,(int)$i['default_warehouse_id'],'in',$qty,'return',$r['id'],'Returned item restocked']);
    }
}
