<?php
declare(strict_types=1);
final class DisasterRecoveryService
{
    public function __construct(private PDO $db) {}
    public function audit(): array
    {
        $checks=[];
        $checks['database']=$this->dbCheck();
        $checks['migrations']=$this->migrationCheck();
        $checks['backup']=$this->backupCheck();
        $checks['queue']=$this->queueCheck();
        $checks['audit_integrity']=$this->auditCheck();
        $fails=array_filter($checks,fn($v)=>($v['status']??'fail')==='fail');
        return ['generated_at'=>gmdate('c'),'status'=>$fails?'fail':'pass','checks'=>$checks,'readiness'=>$fails?0:100];
    }
    public function persist(array $report): ?int
    {
        if(!$this->table('system_recovery_reports')) return null;
        $q=$this->db->prepare('INSERT INTO system_recovery_reports(status,report_json,created_at) VALUES(?,?,NOW())');
        $q->execute([$report['status'],json_encode($report,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]); return (int)$this->db->lastInsertId();
    }
    public function recent(int $limit=20):array
    {
        if(!$this->table('system_recovery_reports')) return [];
        $limit=max(1,min(100,$limit));
        $q=$this->db->query('SELECT id,status,report_json,created_at FROM system_recovery_reports ORDER BY id DESC LIMIT '.$limit);
        return $q->fetchAll(PDO::FETCH_ASSOC);
    }
    private function dbCheck():array { try{$this->db->query('SELECT 1');return ['status'=>'pass','message'=>'database reachable'];}catch(Throwable $e){return ['status'=>'fail','message'=>'database unavailable'];} }
    private function migrationCheck():array
    {
        if(!$this->table('app_migrations')) return ['status'=>'fail','message'=>'migration registry missing'];
        $files=glob(dirname(__DIR__,2).'/database/migrations/*.sql')?:[]; sort($files,SORT_NATURAL);
        $q=$this->db->query('SELECT version,checksum FROM app_migrations'); $applied=[];
        foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r)$applied[$r['version']]=$r['checksum'];
        $missing=[];$mismatch=[];
        foreach($files as $f){$v=basename($f,'.sql');if(!isset($applied[$v])){$missing[]=$v;continue;}if(!hash_equals($applied[$v],hash('sha256',(string)file_get_contents($f))))$mismatch[]=$v;}
        if($mismatch)return ['status'=>'fail','message'=>'migration checksum mismatch','mismatch'=>$mismatch];
        return ['status'=>$missing?'warn':'pass','message'=>$missing?'unapplied migrations detected':'migration registry consistent','missing'=>$missing];
    }
    private function backupCheck():array
    {
        $dir=(string)Env::get('MEELANO_BACKUP_DIR','');
        if($dir==='')return ['status'=>'warn','message'=>'backup directory is not configured'];
        if(!is_dir($dir)||!is_readable($dir))return ['status'=>'fail','message'=>'backup directory unavailable'];
        $files=glob(rtrim($dir,'/').'/*')?:[]; $valid=0; $latest=0;
        foreach($files as $f)if(is_file($f)&&filesize($f)>0){$valid++;$latest=max($latest,(int)filemtime($f));}
        if(!$valid)return ['status'=>'fail','message'=>'no non-empty backup artifact found'];
        $age=time()-$latest; return ['status'=>$age<=172800?'pass':'warn','message'=>$age<=172800?'recent backup artifact found':'backup artifact is older than 48 hours','artifact_count'=>$valid,'age_seconds'=>$age];
    }
    private function queueCheck():array
    {
        try{$q=(int)$this->db->query("SELECT COUNT(*) FROM social_publish_jobs WHERE status IN ('Queued','Retrying')")->fetchColumn();$s=(int)$this->db->query("SELECT COUNT(*) FROM social_publish_jobs WHERE status='Processing' AND claim_expires_at IS NOT NULL AND claim_expires_at<NOW()")->fetchColumn();return ['status'=>$s>0?'warn':'pass','pending'=>$q,'stale_processing'=>$s];}catch(Throwable $e){return ['status'=>'warn','message'=>'queue metrics unavailable'];}
    }
    private function auditCheck():array
    {
        if(!$this->table('audit_logs')) return ['status'=>'warn','message'=>'audit log table unavailable'];
        try{$q=$this->db->query('SELECT COUNT(*) FROM audit_logs');return ['status'=>'pass','entries'=>(int)$q->fetchColumn()];}catch(Throwable $e){return ['status'=>'warn','message'=>'audit log check unavailable'];}
    }
    private function table(string $name):bool { try{$q=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$name]);return (int)$q->fetchColumn()===1;}catch(Throwable $e){return false;} }
}
