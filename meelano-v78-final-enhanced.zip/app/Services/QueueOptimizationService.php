<?php
declare(strict_types=1);
final class QueueOptimizationService
{
    public function __construct(private PDO $db) {}
    public function report(): array
    {
        if(!$this->table('social_publish_jobs')) return ['status'=>'unavailable','reason'=>'social_publish_jobs table not found'];
        $q=$this->db->query("SELECT status,COUNT(*) count FROM social_publish_jobs GROUP BY status"); $counts=[]; foreach($q->fetchAll(PDO::FETCH_ASSOC)?:[] as $r)$counts[(string)$r['status']]=(int)$r['count'];
        $stale=(int)($this->scalar("SELECT COUNT(*) FROM social_publish_jobs WHERE status='Processing' AND updated_at < DATE_SUB(NOW(),INTERVAL 15 MINUTE)")??0);
        $retrying=(int)($counts['Retrying']??0); $queued=(int)($counts['Queued']??0); $processing=(int)($counts['Processing']??0); $failed=(int)($counts['Failed']??0)+(int)($counts['DeadLetter']??0)+(int)($counts['deadletter']??0);
        $hour=(int)($this->scalar("SELECT COUNT(*) FROM social_publish_jobs WHERE status='Completed' AND updated_at>=DATE_SUB(NOW(),INTERVAL 1 HOUR)")??0);
        $recommendedBatch=$hour>500?50:($hour>100?25:10);
        $recommendedConcurrency=min(8,max(1,(int)ceil(max(1,$hour)/100)));
        $backoff=$retrying>50?'exponential_120_3600':($retrying>10?'exponential_60_1800':'exponential_30_900');
        return ['status'=>'ok','counts'=>$counts,'stale_processing'=>$stale,'completed_last_hour'=>$hour,'recommendations'=>['batch_size'=>$recommendedBatch,'concurrency'=>$recommendedConcurrency,'lease_minutes'=>$stale>0?10:15,'retry_backoff'=>$backoff,'actions'=>array_values(array_filter(['stale_processing'=>$stale>0?'reclaim stale processing jobs safely':'none','retry_pressure'=>$retrying>50?'reduce retry pressure and inspect provider failures':'none','queue_depth'=>$queued>1000?'increase worker cadence within hosting limits':'none','failed'=>$failed>0?'inspect DLQ/failed jobs before replay':'none']))]];
    }
    private function table(string $t):bool{try{$q=$this->db->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?");$q->execute([$t]);return (int)$q->fetchColumn()===1;}catch(Throwable){return false;}}
    private function scalar(string $sql):mixed{try{return $this->db->query($sql)->fetchColumn();}catch(Throwable){return null;}}
}
