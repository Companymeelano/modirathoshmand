<?php
declare(strict_types=1);
final class AdminNotificationService {
 public function __construct(private PDO $db){}
 public function notify(string $event,string $title,string $message,?string $entityType=null,?int $entityId=null,string $severity='warning',array $payload=[]):void {
  try { $this->db->prepare('INSERT INTO admin_notifications(event_code,entity_type,entity_id,severity,title,message,payload_json,created_at) VALUES(?,?,?,?,?,?,?,NOW())')->execute([$event,$entityType,$entityId,$severity,$title,$message,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]); } catch(Throwable){}
  $url=trim((string)Env::get('ADMIN_NOTIFY_WEBHOOK_URL','')); if($url!=='' && preg_match('#^https://#i',$url)){ try { SocialHttp::request('POST',$url,['Content-Type'=>'application/json'],null,json_encode(['event'=>$event,'title'=>$title,'message'=>$message,'severity'=>$severity,'entity_type'=>$entityType,'entity_id'=>$entityId,'payload'=>$payload],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),10); } catch(Throwable){} }
 }
}
