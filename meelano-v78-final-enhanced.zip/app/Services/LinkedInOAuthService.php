<?php
declare(strict_types=1);
final class LinkedInOAuthService {
 public function __construct(private PDO $db){}
 private function cfg(string $key,string $default=''):string{$v=trim((string)Env::get($key,$default));if($v==='')throw new RuntimeException($key.' is not configured.');return $v;}
 public function begin(int $userId,string $redirectUri,?string $scope=null):string{
  $state=bin2hex(random_bytes(32));
  $this->db->prepare('INSERT INTO social_oauth_states(platform,state_hash,user_id,redirect_uri,expires_at,created_at) VALUES(?,?,?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE),NOW())')->execute(['linkedin',hash('sha256',$state),$userId,$redirectUri]);
  $scope=$scope?:trim((string)Env::get('LINKEDIN_SCOPES','openid profile email w_member_social r_member_postAnalytics'));
  return 'https://www.linkedin.com/oauth/v2/authorization?'.http_build_query(['response_type'=>'code','client_id'=>$this->cfg('LINKEDIN_CLIENT_ID'),'redirect_uri'=>$redirectUri,'state'=>$state,'scope'=>$scope]);
 }
 public function exchange(string $code,string $redirectUri):array{
  if(trim($code)==='')throw new InvalidArgumentException('Authorization code is required.');
  $r=SocialHttp::request('POST','https://www.linkedin.com/oauth/v2/accessToken',['Content-Type'=>'application/x-www-form-urlencoded'],null,http_build_query(['grant_type'=>'authorization_code','code'=>$code,'client_id'=>$this->cfg('LINKEDIN_CLIENT_ID'),'client_secret'=>$this->cfg('LINKEDIN_CLIENT_SECRET'),'redirect_uri'=>$redirectUri]),30);
  $d=$r['data']??[];if(empty($d['access_token']))throw new SocialException('LinkedIn OAuth response is incomplete.');return $d;
 }
 public function save(int $userId,array $token):int{
  $access=(string)($token['access_token']??'');if($access==='')throw new InvalidArgumentException('LinkedIn access token is missing.');
  $u=SocialHttp::request('GET','https://api.linkedin.com/v2/userinfo',['Authorization'=>'Bearer '.$access,'Accept'=>'application/json'],null,null,30);$profile=$u['data']??[];
  $sub=(string)($profile['sub']??'');if($sub==='')throw new SocialException('LinkedIn member identity was not returned.');
  $name=trim((string)($profile['name']??''));if($name==='')$name=$sub;
  $meta=['person_urn'=>'urn:li:person:'.$sub,'sub'=>$sub,'email'=>(string)($profile['email']??''),'picture'=>(string)($profile['picture']??'')];
  $scopes=preg_split('/\s+/',trim((string)($token['scope']??Env::get('LINKEDIN_SCOPES',''))),-1,PREG_SPLIT_NO_EMPTY);
  $expires=isset($token['expires_in'])?date('Y-m-d H:i:s',time()+(int)$token['expires_in']):null;
  $refresh=(string)($token['refresh_token']??'');
  $q=$this->db->prepare("SELECT id FROM social_accounts WHERE platform='linkedin' AND external_account_id=? LIMIT 1");$q->execute(['urn:li:person:'.$sub]);$existing=$q->fetchColumn();
  $enc=SocialTokenCipher::encrypt($access);$renc=$refresh!==''?SocialTokenCipher::encrypt($refresh):null;
  if($existing){$id=(int)$existing;$sql='UPDATE social_accounts SET account_name=?,status=\'active\',scopes=?,access_token_enc=?,token_expires_at=?,metadata=?,last_error=NULL,updated_at=NOW()';$args=[$name,json_encode($scopes),$enc,$expires,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)];if($renc!==null){$sql.=',refresh_token_enc=?';$args[]=$renc;}$sql.=' WHERE id=?';$args[]=$id;$this->db->prepare($sql)->execute($args);}else{$this->db->prepare("INSERT INTO social_accounts(platform,account_name,external_account_id,status,scopes,access_token_enc,refresh_token_enc,token_expires_at,metadata,created_at,updated_at) VALUES('linkedin',?,?, 'active',?,?,?,?,?,NOW(),NOW())")->execute([$name,'urn:li:person:'.$sub,json_encode($scopes),$enc,$renc,$expires,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);$id=(int)$this->db->lastInsertId();}
  return $id;
 }
 public function refreshDue(int $limit=20):array{
  $limit=max(1,min(50,$limit));$q=$this->db->query("SELECT id,refresh_token_enc FROM social_accounts WHERE platform='linkedin' AND status='active' AND refresh_token_enc IS NOT NULL AND (token_expires_at IS NULL OR token_expires_at<=DATE_ADD(NOW(),INTERVAL 10 MINUTE)) ORDER BY token_expires_at ASC LIMIT {$limit}");$out=[];
  foreach($q->fetchAll(PDO::FETCH_ASSOC) as $a){try{$refresh=SocialTokenCipher::decrypt((string)$a['refresh_token_enc']);$r=SocialHttp::request('POST','https://www.linkedin.com/oauth/v2/accessToken',['Content-Type'=>'application/x-www-form-urlencoded'],null,http_build_query(['grant_type'=>'refresh_token','refresh_token'=>$refresh,'client_id'=>$this->cfg('LINKEDIN_CLIENT_ID'),'client_secret'=>$this->cfg('LINKEDIN_CLIENT_SECRET')]),30);$d=$r['data']??[];$access=(string)($d['access_token']??'');if($access==='')throw new SocialException('LinkedIn refresh response missing access_token.');$exp=isset($d['expires_in'])?date('Y-m-d H:i:s',time()+(int)$d['expires_in']):null;$newRefresh=(string)($d['refresh_token']??$refresh);$this->db->prepare('UPDATE social_accounts SET access_token_enc=?,refresh_token_enc=?,token_expires_at=?,last_error=NULL,updated_at=NOW() WHERE id=?')->execute([SocialTokenCipher::encrypt($access),SocialTokenCipher::encrypt($newRefresh),$exp,(int)$a['id']]);$out[]=['id'=>(int)$a['id'],'status'=>'refreshed'];}catch(Throwable $e){$msg=mb_substr($e->getMessage(),0,500);$this->db->prepare("UPDATE social_accounts SET status=CASE WHEN ?=1 THEN 'reauthorize' ELSE status END,last_error=?,updated_at=NOW() WHERE id=?")->execute([stripos($msg,'invalid')!==false?1:0,$msg,(int)$a['id']]);$out[]=['id'=>(int)$a['id'],'status'=>'error','error'=>$msg];}}
  return $out;
 }
}
