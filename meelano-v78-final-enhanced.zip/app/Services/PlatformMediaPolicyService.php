<?php
declare(strict_types=1);
final class PlatformMediaPolicyService {
 public function rules(string $platform):array {
  return match(strtolower($platform)){
   'instagram'=>['formats'=>['reel'],'preferred_aspect'=>'9:16','codec'=>'H.264/HEVC','audio'=>'AAC','notes'=>'Use platform-supported Reel specs; ranking is not guaranteed.'],
   'tiktok'=>['formats'=>['video'],'preferred_aspect'=>'9:16','codec'=>'MP4/H.264','notes'=>'Respect creator_info limits and approved Content Posting API settings.'],
   'youtube'=>['formats'=>['short','video'],'preferred_aspect'=>'9:16 for Shorts','notes'=>'Use current YouTube publishing limits; Shorts eligibility and ranking are not guaranteed.'],
   'linkedin'=>['formats'=>['video'],'preferred_aspect'=>'9:16 or 1:1 depending on creative','notes'=>'Use current LinkedIn Posts/Video API constraints and member permissions.'],
   default=>['formats'=>['video'],'preferred_aspect'=>'9:16','notes'=>'Unknown platform; use conservative short-form settings.'],
  };
 }
 public function all():array{return array_map(fn($p)=>$this->rules($p),['instagram','tiktok','youtube','linkedin']);}
}
