<?php
declare(strict_types=1);
final class CacheService
{
    private string $dir;
    public function __construct(?string $dir=null){$this->dir=$dir?:dirname(__DIR__,2).'/storage/cache'; if(!is_dir($this->dir))@mkdir($this->dir,0750,true);}
    public function get(string $key,mixed $default=null):mixed{ $f=$this->file($key);if(!is_file($f))return $default;$raw=@file_get_contents($f);if($raw===false)return $default;$v=@json_decode($raw,true);if(!is_array($v)||($v['expires']??0)<time()){ @unlink($f);return $default;}return $v['value']??$default; }
    public function put(string $key,mixed $value,int $ttl=60):bool{if($ttl<1)$ttl=1;$f=$this->file($key);$tmp=$f.'.'.bin2hex(random_bytes(4)).'.tmp';$ok=@file_put_contents($tmp,json_encode(['expires'=>time()+$ttl,'value'=>$value],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX)!==false;if($ok)$ok=@rename($tmp,$f);else @unlink($tmp);return $ok;}
    public function forget(string $key):bool{$f=$this->file($key);return !is_file($f)||@unlink($f);}
    public function remember(string $key,int $ttl,callable $resolver):mixed{$v=$this->get($key,null);if($v!==null)return $v;$v=$resolver();$this->put($key,$v,$ttl);return $v;}
    public function pathFor(string $key,string $suffix='cache'):string{return $this->dir.'/'.hash('sha256',$key).'.'.$suffix;}
    public function lock(string $key,int $ttl=10):bool{$path=$this->pathFor($key,'lock');$fh=@fopen($path,'x');if($fh!==false){fwrite($fh,(string)time());fclose($fh);return true;}if(is_file($path)&&@filemtime($path)<time()-max(1,$ttl))@unlink($path);return false;}
    public function unlock(string $key):void{@unlink($this->pathFor($key,'lock'));}
    private function file(string $key):string{return $this->pathFor($key,'cache');}
}
