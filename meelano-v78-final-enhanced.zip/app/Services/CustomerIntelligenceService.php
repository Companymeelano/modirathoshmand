<?php
declare(strict_types=1);
final class CustomerIntelligenceService {
 public function __construct(private PDO $db,private ?Audit $audit=null){}
 public function recalculate(int $customerId,?int $userId=null):array {
  $q=$this->db->prepare('SELECT id,segment FROM customers WHERE id=? FOR UPDATE');$q->execute([$customerId]);$c=$q->fetch(PDO::FETCH_ASSOC);if(!$c)throw new RuntimeException('مشتری یافت نشد.');
  $o=$this->db->prepare("SELECT COUNT(*) frequency,COALESCE(SUM(payable_amount),0) monetary,MAX(created_at) last_order_at FROM orders WHERE user_id=? AND payment_status IN ('paid','refunded') AND order_status<>'cancelled'");$o->execute([$customerId]);$m=$o->fetch(PDO::FETCH_ASSOC);
  $frequency=(int)$m['frequency'];$monetary=(float)$m['monetary'];$last=$m['last_order_at']?strtotime($m['last_order_at']):0;$recency=$last?max(0,(int)floor((time()-$last)/86400)):9999;$aov=$frequency>0?$monetary/$frequency:0;
  $r=$recency<=7?5:($recency<=30?4:($recency<=90?3:($recency<=180?2:1)));$f=$frequency>=12?5:($frequency>=6?4:($frequency>=3?3:($frequency>=2?2:1)));$mScore=$monetary>=100000000?5:($monetary>=50000000?4:($monetary>=20000000?3:($monetary>=5000000?2:1)));
  $risk=round(min(100,max(0,($recency>=180?80:($recency>=90?55:($recency>=45?30:10)))-(($f-1)*4))),4);
  $segment=$frequency===0?'new':($risk>=70?'lost':($risk>=45?'dormant':($risk>=25?'at_risk':($mScore>=4&&$f>=4?'vip':($mScore>=3||$f>=3?'high_value':'returning')))));
  $clv=round(max($aov,$monetary)*max(1,min(12,1+($f/2)))*max(.5,1-($risk/200)),2);
  $sql='INSERT INTO customer_intelligence_metrics(customer_id,recency_days,frequency,monetary,aov,r_score,f_score,m_score,clv_estimate,risk_score,segment,calculated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE recency_days=VALUES(recency_days),frequency=VALUES(frequency),monetary=VALUES(monetary),aov=VALUES(aov),r_score=VALUES(r_score),f_score=VALUES(f_score),m_score=VALUES(m_score),clv_estimate=VALUES(clv_estimate),risk_score=VALUES(risk_score),segment=VALUES(segment),calculated_at=NOW()';$this->db->prepare($sql)->execute([$customerId,$recency,$frequency,$monetary,$aov,$r,$f,$mScore,$clv,$risk,$segment]);
  if($segment!==$c['segment'])$this->db->prepare('INSERT INTO customer_segment_history(customer_id,old_segment,new_segment,score,reason,calculated_at) VALUES(?,?,?,?,?,NOW())')->execute([$customerId,$c['segment'],$segment,round(($r+$f+$mScore)*100/15,2),'rfm_clv_recalculation']);
  $this->db->prepare('UPDATE customers SET segment=?,updated_at=NOW() WHERE id=?')->execute([$segment,$customerId]);$this->audit?->log($userId,'recalculate','crm','customer',$customerId,['segment'=>$segment,'recency'=>$recency,'frequency'=>$frequency,'monetary'=>$monetary,'clv'=>$clv,'risk'=>$risk]);
  return ['customer_id'=>$customerId,'segment'=>$segment,'recency_days'=>$recency,'frequency'=>$frequency,'monetary'=>$monetary,'aov'=>round($aov,2),'rfm'=>['r'=>$r,'f'=>$f,'m'=>$mScore],'clv_estimate'=>$clv,'risk_score'=>$risk];
 }
}
