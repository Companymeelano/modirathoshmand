<?php
declare(strict_types=1);
final class AssetPerformanceService
{
    public function __construct(private string $root){}
    public function audit():array{
        $dirs=['assets','public','admin/assets','pwa'];$rows=[];$total=0;$count=0;$large=0;
        foreach($dirs as $d){$base=$this->root.'/'.$d;if(!is_dir($base))continue;$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS));foreach($it as $f){if(!$f->isFile())continue;$ext=strtolower($f->getExtension());if(!in_array($ext,['js','css','png','jpg','jpeg','webp','svg','woff','woff2','gif'],true))continue;$size=$f->getSize();$count++;$total+=$size;if($size>500*1024){$large++;$rows[]=['file'=>str_replace($this->root.'/','',$f->getPathname()),'bytes'=>$size,'issue'=>'large_asset'];}}}
        return ['status'=>'ok','asset_count'=>$count,'total_bytes'=>$total,'large_assets'=>$large,'recommendations'=>['Prefer WebP/AVIF for raster images where supported.','Serve compressed/minified JS/CSS in production.','Use long immutable cache headers for versioned static assets.'],'large_files'=>array_slice($rows,0,100)];
    }
}
