<?php
declare(strict_types=1);
final class AdminDashboardService {
 public function __construct(private PDO $db){}
 private function scalar(string $sql,array $args=[]):int{$q=$this->db->prepare($sql);$q->execute($args);return (int)$q->fetchColumn();}
 public function summary():array{
  return [
   'orders_total'=>$this->scalar('SELECT COUNT(*) FROM orders'),
   'orders_pending'=>$this->scalar("SELECT COUNT(*) FROM orders WHERE order_status IN ('pending','processing','packed')"),
   'orders_paid'=>$this->scalar("SELECT COUNT(*) FROM orders WHERE payment_status='paid'"),
   'customers_total'=>$this->scalar('SELECT COUNT(*) FROM users WHERE role=\'customer\''),
   'products_active'=>$this->scalar("SELECT COUNT(*) FROM products WHERE status='active'"),
   'low_stock'=>$this->scalar('SELECT COUNT(*) FROM product_inventory WHERE current_stock <= min_stock'),
   'social_accounts'=>$this->scalar('SELECT COUNT(*) FROM social_accounts WHERE status=\'active\''),
   'social_queue'=>$this->scalar("SELECT COUNT(*) FROM social_publish_jobs WHERE status IN ('Queued','Processing','Retrying')"),
   'ai_requests_24h'=>$this->scalar('SELECT COUNT(*) FROM ai_usage_logs WHERE created_at >= DATE_SUB(NOW(),INTERVAL 24 HOUR)'),
  ];
 }
 public function recentOrders(int $limit=8):array{$limit=max(1,min(20,$limit));$q=$this->db->query("SELECT id,order_number,customer_name,payable_amount,payment_status,order_status,created_at FROM orders ORDER BY id DESC LIMIT {$limit}");return $q->fetchAll(PDO::FETCH_ASSOC);}
 public function socialQueue(int $limit=8):array{$limit=max(1,min(20,$limit));$q=$this->db->query("SELECT j.id,j.platform,j.status,j.scheduled_at,j.attempts,j.external_post_id,j.last_error,a.account_name FROM social_publish_jobs j LEFT JOIN social_accounts a ON a.id=j.account_id ORDER BY j.id DESC LIMIT {$limit}");return $q->fetchAll(PDO::FETCH_ASSOC);}
}
