<?php
declare(strict_types=1);
final class SocialPublishingRollbackService {
    public function __construct(private PDO $db, private Audit $audit) {}
    private const TERMINAL=['Failed','Cancelled','RolledBack'];
    public function request(int $jobId,int $userId,string $reason=''):array {
        $j=$this->job($jobId);
        $s=(string)$j['status'];
        if(in_array($s,self::TERMINAL,true)) throw new DomainException('این Job دیگر قابل Rollback نیست.');
        if($s==='RollingBack'||$s==='RollbackRequested') return ['job_id'=>$jobId,'status'=>$s,'deduplicated'=>true];
        if($s==='Queued'||$s==='Retrying') {
            $this->db->prepare("UPDATE social_publish_jobs SET status='Cancelled',last_error=?,updated_at=NOW() WHERE id=? AND status IN ('Queued','Retrying')")->execute([$this->reason($reason,'Cancelled before publishing.'),$jobId]);
            $this->event($jobId,$s,'Cancelled',(string)$j['platform'],(string)($j['external_post_id']??''),$reason,null,$userId);
            $this->audit->log($userId,'social_publish_rollback_cancelled','social_publish_jobs',$jobId,$jobId,['from'=>$s,'reason'=>$reason]);
            return ['job_id'=>$jobId,'status'=>'Cancelled','external_deleted'=>false];
        }
        if(!in_array($s,['Processing','Completed','RollbackFailed'],true)) throw new DomainException('وضعیت فعلی برای Rollback مجاز نیست.');
        $this->db->prepare("UPDATE social_publish_jobs SET status='RollbackRequested',last_error=?,updated_at=NOW() WHERE id=? AND status=?")->execute([$reason!==''?$reason:null,$jobId,$s]);
        $this->event($jobId,$s,'RollbackRequested',(string)$j['platform'],(string)($j['external_post_id']??''),$reason,null,$userId);
        $this->audit->log($userId,'social_publish_rollback_requested','social_publish_jobs',$jobId,$jobId,['from'=>$s,'reason'=>$reason]);
        return ['job_id'=>$jobId,'status'=>'RollbackRequested'];
    }
    public function processDue(int $limit=10,int $userId=0):array {
        $limit=max(1,min(50,$limit));
        $q=$this->db->query("SELECT j.*,a.access_token_enc,a.account_name,a.external_account_id,a.scopes,a.metadata FROM social_publish_jobs j JOIN social_accounts a ON a.id=j.account_id WHERE j.status='RollbackRequested' ORDER BY j.updated_at,j.id LIMIT {$limit}");
        $out=[];
        foreach($q->fetchAll(PDO::FETCH_ASSOC) as $j){
            $id=(int)$j['id'];
            $claim=$this->db->prepare("UPDATE social_publish_jobs SET status='RollingBack',updated_at=NOW() WHERE id=? AND status='RollbackRequested'");$claim->execute([$id]);
            if($claim->rowCount()!==1) continue;
            try {
                $external=trim((string)($j['external_post_id']??''));
                if($external==='') { $this->finish($id,'RolledBack',null); $this->event($id,'RollingBack','RolledBack',(string)$j['platform'],'','no_external_post_id',null,$userId); $out[]=['job_id'=>$id,'status'=>'RolledBack','external_deleted'=>false,'reason'=>'no_external_post_id']; continue; }
                $platform=strtolower((string)$j['platform']);
                $result=$this->deleteExternal($platform,$j,$external);
                $this->finish($id,'RolledBack',null);
                $this->event($id,'RollingBack','RolledBack',$platform,$external,null,$result,$userId);
                if($userId>0)$this->audit->log($userId,'social_publish_rollback_completed','social_publish_jobs',$id,$id,['platform'=>$platform,'external_post_id'=>$external]);
                $out[]=['job_id'=>$id,'status'=>'RolledBack','external_deleted'=>true,'platform'=>$platform,'result'=>$result];
            } catch(Throwable $e) {
                $msg=mb_substr($e->getMessage(),0,500); $this->finish($id,'RollbackFailed',$msg); $this->event($id,'RollingBack','RollbackFailed',(string)$j['platform'],(string)($j['external_post_id']??''),$msg,null,$userId);
                if($userId>0)$this->audit->log($userId,'social_publish_rollback_failed','social_publish_jobs',$id,$id,['error'=>$msg]);
                $out[]=['job_id'=>$id,'status'=>'RollbackFailed','error'=>$msg,'retryable'=>$e instanceof SocialException && $e->retryable];
            }
        }
        return $out;
    }
    public function get(int $jobId):array { return $this->job($jobId); }
    private function deleteExternal(string $platform,array $j,string $external):array {
        $token=SocialTokenCipher::decrypt((string)($j['access_token_enc']??''));
        if($token==='') throw new SocialException('Social access token is not configured.',401,false);
        if($platform==='youtube') {
            $r=SocialHttp::request('DELETE','https://www.googleapis.com/youtube/v3/videos?id='.rawurlencode($external),['Authorization'=>'Bearer '.$token]);
            return ['status'=>$r['status'],'provider'=>'youtube'];
        }
        if($platform==='linkedin') {
            $urn=rawurlencode($external);
            $version=trim((string)Env::get('LINKEDIN_VERSION','202608')); if(!preg_match('/^20\d{4}$/',$version))$version='202608';
            $r=SocialHttp::request('DELETE','https://api.linkedin.com/v2/ugcPosts/'.$urn,['Authorization'=>'Bearer '.$token,'Linkedin-Version'=>$version,'X-Restli-Protocol-Version'=>'2.0.0','Accept'=>'application/json']);
            return ['status'=>$r['status'],'provider'=>'linkedin'];
        }
        throw new SocialException('Rollback رسمی برای این پلتفرم در این نسخه در دسترس نیست؛ حذف دستی لازم است.',501,false);
    }
    private function event(int $jobId,string $from,string $to,string $platform,string $external,string $reason,mixed $response,int $userId):void {
        try { $this->db->prepare('INSERT INTO social_publish_rollback_events(job_id,from_status,to_status,platform,external_post_id,reason,response_json,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())')->execute([$jobId,$from,$to,$platform,$external!==''?$external:null,$reason!==''?$reason:null,$response===null?null:json_encode($response,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$userId>0?$userId:null]); } catch(Throwable $e) { error_log('[MeeLano] rollback event audit failed: '.$e->getMessage()); }
    }
    private function job(int $id):array { if($id<1)throw new InvalidArgumentException('job_id نامعتبر است.');$q=$this->db->prepare('SELECT j.*,a.access_token_enc,a.account_name,a.external_account_id,a.scopes,a.metadata FROM social_publish_jobs j JOIN social_accounts a ON a.id=j.account_id WHERE j.id=? LIMIT 1');$q->execute([$id]);$j=$q->fetch(PDO::FETCH_ASSOC);if(!$j)throw new InvalidArgumentException('Job یافت نشد.');return $j; }
    private function finish(int $id,string $status,?string $error):void { $this->db->prepare('UPDATE social_publish_jobs SET status=?,last_error=?,updated_at=NOW() WHERE id=? AND status=\'RollingBack\'')->execute([$status,$error,$id]); }
    private function reason(string $reason,string $fallback):string { $reason=trim($reason);return mb_substr($reason!==''?$reason:$fallback,0,500); }
}
