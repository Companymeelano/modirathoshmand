<?php
declare(strict_types=1);
final class DatabaseIntelligenceService
{
    public function __construct(private PDO $db) {}

    public function tables(): array
    {
        $q=$this->db->query("SELECT table_name, table_rows, data_length, index_length, (data_length+index_length) total_bytes FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE' ORDER BY total_bytes DESC");
        return $q->fetchAll(PDO::FETCH_ASSOC)?:[];
    }

    public function indexes(string $table=''): array
    {
        $sql="SELECT TABLE_NAME,INDEX_NAME,COLUMN_NAME,SEQ_IN_INDEX,CARDINALITY,NON_UNIQUE FROM information_schema.statistics WHERE TABLE_SCHEMA=DATABASE()";
        $args=[]; if($table!==''){ $sql.=' AND TABLE_NAME=?'; $args[]=$table; }
        $sql.=' ORDER BY TABLE_NAME,INDEX_NAME,SEQ_IN_INDEX';
        $q=$this->db->prepare($sql);$q->execute($args);return $q->fetchAll(PDO::FETCH_ASSOC)?:[];
    }

    public function explain(string $sql): array
    {
        $sql=trim($sql);
        if($sql==='') throw new InvalidArgumentException('SQL الزامی است.');
        if(strlen($sql)>4000) throw new InvalidArgumentException('SQL بیش از حد طولانی است.');
        if(!preg_match('/^SELECT\\s/i',$sql)) throw new InvalidArgumentException('فقط SELECT مجاز است.');
        if(str_contains($sql,';') || preg_match('/(--|#|\/\\*)/',$sql)) throw new InvalidArgumentException('کامنت و چند دستور همزمان مجاز نیست.');
        if(preg_match('/\\b(INTO\\s+OUTFILE|INTO\\s+DUMPFILE|LOAD_FILE|FOR\\s+UPDATE|LOCK\\s+TABLE|SLEEP\\s*\\()/i',$sql)) throw new InvalidArgumentException('عبارت پرخطر مجاز نیست.');
        $q=$this->db->prepare('EXPLAIN '.$sql);$q->execute();$rows=$q->fetchAll(PDO::FETCH_ASSOC)?:[];
        $warnings=[]; foreach($rows as $r){ if(($r['type']??'')==='ALL')$warnings[]='Full table scan detected'; if((int)($r['rows']??0)>10000)$warnings[]='Estimated rows exceed 10,000'; if(($r['Extra']??'')!=='' && stripos((string)$r['Extra'],'Using filesort')!==false)$warnings[]='Using filesort'; if(($r['Extra']??'')!=='' && stripos((string)$r['Extra'],'Using temporary')!==false)$warnings[]='Using temporary'; }
        return ['status'=>'ok','plan'=>$rows,'warnings'=>array_values(array_unique($warnings)),'safe_read_only'=>true];
    }

    public function recommendations(): array
    {
        $recs=[];
        $tables=['orders'=>['user_id','order_status','payment_status','created_at'],'order_items'=>['order_id','product_id','variant_id'],'product_inventory'=>['product_id','variant_id','warehouse_id'],'social_publish_jobs'=>['status','scheduled_at','claim_expires_at','account_id'],'social_content_performance'=>['platform','captured_at','external_content_id'],'social_ai_video_director_jobs'=>['status','platform','created_at'],'system_performance_metrics'=>['action','created_at','http_status']];
        foreach($tables as $t=>$cols){ if(!$this->exists($t))continue; $idx=$this->indexMap($t); foreach($cols as $c){$found=false;foreach($idx as $x){if(count($x)===1&&$x[0]===$c){$found=true;break;} if($x[0]===$c){$found=true;break;}} if(!$found)$recs[]=['table'=>$t,'column'=>$c,'reason'=>'Frequently filtered/sorted operational column; validate with EXPLAIN before creating index.'];}}
        return ['generated_at'=>gmdate('c'),'recommendations'=>$recs,'count'=>count($recs)];
    }
    private function indexMap(string $t):array{ $q=$this->db->prepare('SELECT INDEX_NAME,COLUMN_NAME,SEQ_IN_INDEX FROM information_schema.statistics WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? ORDER BY INDEX_NAME,SEQ_IN_INDEX');$q->execute([$t]);$o=[];foreach($q as $r){$n=(string)$r['INDEX_NAME'];$o[$n][]=(string)$r['COLUMN_NAME'];}return array_values($o); }
    private function exists(string $t):bool{$q=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');$q->execute([$t]);return (int)$q->fetchColumn()===1;}
}
