<?php
declare(strict_types=1);
final class AdaptiveIndexPlannerService
{
    public function __construct(private PDO $db, private QueryCacheService $queries) {}

    public function plan(): array
    {
        $plans=[];$recommendations=[];
        foreach($this->queries->specs() as $name=>$spec){
            $sql=(string)$spec['sql'];
            $item=['name'=>$name,'sql'=>$sql,'status'=>'skipped'];
            try{
                $tables=$spec['tables']??[];$missing=false;foreach($tables as $t){if(!$this->table($t)){$missing=true;break;}}
                if($missing){$item['reason']='required table missing';$plans[]=$item;continue;}
                $q=$this->db->query('EXPLAIN '.$sql);$rows=$q->fetchAll(PDO::FETCH_ASSOC)?:[];$item['status']='ok';$item['explain']=$rows;
                foreach($rows as $r){$type=strtolower((string)($r['type']??''));$extra=strtolower((string)($r['Extra']??''));if($type==='all')$recommendations[]=['query'=>$name,'severity'=>'high','reason'=>'EXPLAIN reports full table scan','action'=>'validate composite index against production workload'];if(str_contains($extra,'using filesort')||str_contains($extra,'using temporary'))$recommendations[]=['query'=>$name,'severity'=>'medium','reason'=>$extra,'action'=>'review ORDER BY/GROUP BY index coverage'];}
            }catch(Throwable $e){$item['status']='error';$item['reason']='EXPLAIN unavailable in current environment';}
            $plans[]=$item;
        }
        return ['status'=>'ok','generated_at'=>gmdate('c'),'plans'=>$plans,'recommendations'=>$recommendations,'safety'=>'recommendation_only'];
    }
    private function table(string $t):bool{try{$q=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$t]);return (int)$q->fetchColumn()===1;}catch(Throwable){return false;}}
}
