<?php
declare(strict_types=1);
final class QueryCacheService
{
    public function __construct(private PDO $db, private IntelligentCacheService $cache) {}

    public function run(string $name, array $params=[], int $ttl=30): array
    {
        $name=trim($name);
        $spec=$this->specs()[$name]??null;
        if($spec===null) throw new InvalidArgumentException('Query cache نامعتبر است.');
        $ttl=max(5,min(3600,$ttl));
        foreach(($spec['tables']??[]) as $table) if(!$this->table($table)) throw new RuntimeException('منبع Query Cache در دیتابیس موجود نیست.');
        $key=hash('sha256',json_encode(['name'=>$name,'params'=>$params,'schema'=>'v75'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return (array)$this->cache->remember('query.'.$name,$key,$ttl,function() use($spec,$params){
            $q=$this->db->prepare($spec['sql']);
            $q->execute($this->bind($spec['params']??[],$params));
            return $q->fetchAll(PDO::FETCH_ASSOC)?:[];
        });
    }

    public function invalidate(string $namespace): int { return $this->cache->flushNamespace('query.'.$namespace); }

    public function catalog(): array { $out=[]; foreach($this->specs() as $k=>$v)$out[]=['name'=>$k,'ttl'=>$v['ttl'],'description'=>$v['description']]; return $out; }

    public function specs(): array
    {
        $s=[
            'active_products'=>['sql'=>'SELECT id,category_id,default_warehouse_id,title,slug,sku,barcode,unit,sale_price_retail,sale_price_wholesale,status,featured,sort_order FROM products WHERE status="active" ORDER BY sort_order,id DESC LIMIT 200','params'=>[],'ttl'=>60,'description'=>'محصولات فعال برای کاتالوگ','tables'=>['products']],
            'category_tree'=>['sql'=>'SELECT id,parent_id,name,slug,status,sort_order FROM categories WHERE status="active" ORDER BY sort_order,id','params'=>[],'ttl'=>300,'description'=>'درخت دسته‌بندی فعال','tables'=>['categories']],
            'shipping_rules'=>['sql'=>'SELECT id,name,category_id,region_type,min_weight,max_weight,min_price,max_price,shipping_cost,cargo_cost,is_active,priority,conditions FROM shipping_rules WHERE is_active=1 ORDER BY priority DESC,id DESC','params'=>[],'ttl'=>300,'description'=>'قوانین ارسال فعال','tables'=>['shipping_rules']],
            'social_performance_summary'=>['sql'=>'SELECT platform,COUNT(*) content_count,ROUND(AVG(COALESCE(engagement_rate,0)),4) avg_engagement,SUM(COALESCE(reach,0)) reach,SUM(COALESCE(views,0)) views,SUM(COALESCE(engagement,0)) engagement FROM social_content_performance GROUP BY platform','params'=>[],'ttl'=>120,'description'=>'خلاصه عملکرد شبکه‌های اجتماعی','tables'=>['social_content_performance']],
        ];
        return $s;
    }
    private function table(string $table): bool { try { $q=$this->db->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?"); $q->execute([$table]); return (int)$q->fetchColumn()===1; } catch(Throwable) { return false; } }
    private function bind(array $allowed,array $input): array { $out=[]; foreach($allowed as $k){$out[$k]=$input[$k]??null;} return $out; }
}
