<?php
declare(strict_types=1);
final class BackupManifestService {
 public function __construct(private PDO $db) {}
 public function build(): array {
  $dir=trim((string)Env::get('MEELANO_BACKUP_DIR',''));
  if($dir==='') return ['status'=>'warn','message'=>'backup directory is not configured','artifacts'=>[]];
  if(!is_dir($dir)||!is_readable($dir)) return ['status'=>'fail','message'=>'backup directory unavailable','artifacts'=>[]];
  $items=[]; foreach(glob(rtrim($dir,'/').'/*')?:[] as $f){if(!is_file($f)||!is_readable($f))continue;$size=(int)filesize($f);if($size<=0)continue;$hash=hash_file('sha256',$f);if($hash===false)continue;$mtime=filemtime($f);$name=basename($f);$sig=$this->sign($hash.'|'.$size.'|'.$name);$items[]=['path'=>$f,'name'=>$name,'size_bytes'=>$size,'modified_at'=>$mtime?gmdate('Y-m-d H:i:s',$mtime):null,'sha256'=>$hash,'signature'=>$sig];}
  foreach($items as $x){$this->db->prepare('INSERT INTO system_backup_manifests(backup_path,artifact_name,size_bytes,modified_at,sha256,signature,verified,verification_message,created_at) VALUES(?,?,?,?,?,?,1,?,NOW())')->execute([$x['path'],$x['name'],$x['size_bytes'],$x['modified_at'],$x['sha256'],$x['signature'],'manifest generated']);}
  return ['status'=>$items?'pass':'fail','message'=>$items?'backup manifest generated':'no non-empty backup artifact found','count'=>count($items),'artifacts'=>$items];
 }
 public function verifyLatest(int $limit=20):array {
  if(!$this->table()) return ['status'=>'fail','message'=>'backup manifest table missing','artifacts'=>[]];
  $dir=trim((string)Env::get('MEELANO_BACKUP_DIR',''));if($dir==='')return ['status'=>'warn','message'=>'backup directory is not configured','artifacts'=>[]];
  $q=$this->db->query('SELECT * FROM system_backup_manifests ORDER BY id DESC LIMIT '.max(1,min(100,$limit)));$out=[];$fail=0;
  foreach($q->fetchAll(PDO::FETCH_ASSOC) as $m){$path=(string)$m['backup_path'];$ok=is_file($path)&&is_readable($path);$actual=$ok?hash_file('sha256',$path):false;$sig=$this->sign((string)$m['sha256'].'|'.(int)$m['size_bytes'].'|'.(string)$m['artifact_name']);$ok=$ok&&$actual!==false&&hash_equals((string)$m['sha256'],$actual)&&hash_equals((string)($m['signature']??''),$sig);if(!$ok)$fail++;$this->db->prepare('UPDATE system_backup_manifests SET verified=?,verification_message=?,verified_at=NOW() WHERE id=?')->execute([$ok?1:0,$ok?'hash and signature verified':'artifact missing or checksum/signature mismatch',(int)$m['id']]);$out[]=['id'=>(int)$m['id'],'artifact_name'=>$m['artifact_name'],'verified'=>$ok];}
  return ['status'=>$fail?'fail':'pass','message'=>$fail?'one or more backup manifests failed verification':'backup manifests verified','failed'=>$fail,'artifacts'=>$out];
 }
 public function restoreReadiness():array {
  $manifest=$this->verifyLatest(10);$migration=(new DisasterRecoveryService($this->db))->audit()['checks']['migrations']??['status'=>'fail'];$ready=($manifest['status']==='pass'&&in_array($migration['status'],['pass','warn'],true));return ['status'=>$ready?'pass':'fail','restore_ready'=>$ready,'backup'=>$manifest,'migrations'=>$migration,'generated_at'=>gmdate('c')];
 }
 private function sign(string $data):string{$key=(string)Env::get('APP_KEY','');return $key===''?'':hash_hmac('sha256',$data,$key);}
 private function table():bool{try{$q=$this->db->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='system_backup_manifests'");return (int)$q->fetchColumn()===1;}catch(Throwable $e){return false;}}
}
