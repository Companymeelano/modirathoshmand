<?php
declare(strict_types=1);
final class SocialMediaAssetService {
 public function __construct(private PDO $db, private Audit $audit){}
 public function upload(array $file,int $userId,?string $platform=null):array{
  if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) throw new InvalidArgumentException('آپلود رسانه ناموفق بود.');
  $size=(int)($file['size']??0); if($size<1||$size>524288000) throw new InvalidArgumentException('حجم فایل باید بین 1 بایت و 500 مگابایت باشد.');
  $tmp=(string)($file['tmp_name']??''); if($tmp===''||!is_uploaded_file($tmp)) throw new InvalidArgumentException('فایل آپلودشده معتبر نیست.');
  $f=finfo_open(FILEINFO_MIME_TYPE); if($f===false) throw new RuntimeException('تشخیص نوع فایل در دسترس نیست.'); try{$mime=(string)finfo_file($f,$tmp);}finally{finfo_close($f);}
  $allowed=['video/mp4'=>'mp4','video/quicktime'=>'mov','video/webm'=>'webm','image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
  if(!isset($allowed[$mime])) throw new InvalidArgumentException('نوع رسانه مجاز نیست.');
  $hash=hash_file('sha256',$tmp); if($hash===false) throw new RuntimeException('محاسبه checksum ناموفق بود.');
  $q=$this->db->prepare('SELECT id,relative_path,mime_type,file_size,status FROM social_media_assets WHERE sha256=? LIMIT 1');$q->execute([$hash]);$existing=$q->fetch(PDO::FETCH_ASSOC);if($existing&&$existing['status']==='ready')return ['asset_id'=>(int)$existing['id'],'deduplicated'=>true,'relative_path'=>$existing['relative_path'],'mime_type'=>$existing['mime_type'],'file_size'=>(int)$existing['file_size']];
  $root=dirname(__DIR__,2);$dir=$root.'/uploads/social/'.date('Y/m');if(!is_dir($dir)&&!mkdir($dir,0750,true)&&!is_dir($dir))throw new RuntimeException('ساخت مسیر رسانه ناموفق بود.');
  $stored=$hash.'.'.$allowed[$mime];$dest=$dir.'/'.$stored;if(!move_uploaded_file($tmp,$dest))throw new RuntimeException('ذخیره رسانه ناموفق بود.');chmod($dest,0640);
  $relative='uploads/social/'.date('Y/m').'/'.$stored;
  $this->db->prepare('INSERT INTO social_media_assets(platform,original_name,stored_name,relative_path,mime_type,file_size,sha256,uploaded_by,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,NOW(),NOW())')->execute([$platform,mb_substr((string)($file['name']??'media'),0,255),$stored,$relative,$mime,$size,$hash,$userId,'ready']);
  $id=(int)$this->db->lastInsertId();$this->audit->log($userId,'social_media_asset_uploaded','social_media_assets',$id,$id,['mime'=>$mime,'size'=>$size,'platform'=>$platform]);
  return ['asset_id'=>$id,'deduplicated'=>false,'relative_path'=>$relative,'mime_type'=>$mime,'file_size'=>$size];
 }
 public function list(int $limit=100):array{$limit=max(1,min(200,$limit));$q=$this->db->query("SELECT id,platform,original_name,relative_path,mime_type,file_size,sha256,status,uploaded_by,created_at FROM social_media_assets ORDER BY created_at DESC LIMIT {$limit}");return $q->fetchAll(PDO::FETCH_ASSOC);}
}
