<?php
declare(strict_types=1);
final class FulfillmentService {
    private const ALLOWED = [
        'pending'=>['ready','cancelled'],
        'ready'=>['shipped','cancelled'],
        'shipped'=>['delivered'],
        'delivered'=>[],
        'cancelled'=>[]
    ];
    public function __construct(private PDO $db, private ?Audit $audit=null) {}
    public function create(int $orderId, ?string $carrier=null, ?string $service=null, ?string $tracking=null, float $cost=0, ?int $userId=null): int {
        $outer=$this->db->inTransaction(); if(!$outer)$this->db->beginTransaction();
        try {
            $q=$this->db->prepare('SELECT id,order_status,payment_status FROM orders WHERE id=? FOR UPDATE'); $q->execute([$orderId]); $o=$q->fetch(PDO::FETCH_ASSOC);
            if(!$o) throw new RuntimeException('سفارش یافت نشد.');
            if(in_array($o['order_status'],['cancelled'],true)) throw new DomainException('برای سفارش لغوشده ارسال ساخته نمی‌شود.');
            $e=$this->db->prepare("SELECT id FROM fulfillment_shipments WHERE order_id=? AND status NOT IN ('cancelled') LIMIT 1"); $e->execute([$orderId]);
            if($e->fetchColumn()) throw new DomainException('برای این سفارش ارسال فعال از قبل وجود دارد.');
            $i=$this->db->prepare('INSERT INTO fulfillment_shipments(order_id,carrier,service,tracking_number,status,shipping_cost,created_at,updated_at) VALUES(?,?,?,?,?,?,NOW(),NOW())');
            $i->execute([$orderId,$carrier,$service,$tracking,'pending',$cost]); $id=(int)$this->db->lastInsertId();
            if(!$outer)$this->db->commit();
            $this->audit?->log($userId,'create','fulfillment','shipment',$id,['order_id'=>$orderId]); return $id;
        } catch(Throwable $e){ if(!$outer&&$this->db->inTransaction())$this->db->rollBack(); throw $e; }
    }
    public function transition(int $shipmentId,string $to,?int $userId=null,?string $note=null): void {
        $outer=$this->db->inTransaction(); if(!$outer)$this->db->beginTransaction();
        try {
            $q=$this->db->prepare('SELECT * FROM fulfillment_shipments WHERE id=? FOR UPDATE');$q->execute([$shipmentId]);$s=$q->fetch(PDO::FETCH_ASSOC);if(!$s)throw new RuntimeException('مرسوله یافت نشد.');
            $from=$s['status']; if(!in_array($to,self::ALLOWED[$from]??[],true))throw new DomainException("تغییر وضعیت ارسال مجاز نیست: {$from} -> {$to}");
            $now=date('Y-m-d H:i:s'); $this->db->prepare('UPDATE fulfillment_shipments SET status=?,shipped_at=CASE WHEN ?="shipped" THEN COALESCE(shipped_at,?) ELSE shipped_at END,delivered_at=CASE WHEN ?="delivered" THEN COALESCE(delivered_at,?) ELSE delivered_at END,updated_at=NOW() WHERE id=?')->execute([$to,$to,$now,$to,$now,$shipmentId]);
            $this->db->prepare('INSERT INTO fulfillment_status_history(shipment_id,from_status,to_status,changed_by,note) VALUES(?,?,?,?,?)')->execute([$shipmentId,$from,$to,$userId,$note]);
            if($to==='shipped')$this->db->prepare("UPDATE orders SET order_status='shipped',updated_at=NOW() WHERE id=? AND order_status IN ('pending','processing','packed')")->execute([$s['order_id']]);
            if($to==='delivered')$this->db->prepare("UPDATE orders SET order_status='completed',updated_at=NOW() WHERE id=? AND order_status='shipped'")->execute([$s['order_id']]);
            if(!$outer)$this->db->commit(); $this->audit?->log($userId,'transition','fulfillment','shipment',$shipmentId,['from'=>$from,'to'=>$to]);
        }catch(Throwable $e){if(!$outer&&$this->db->inTransaction())$this->db->rollBack();throw $e;}
    }
}
