<?php
declare(strict_types=1);
final class AICostService {
 public function __construct(private PDO $db){}
 public function estimate(string $provider,string $model,array $context=[]):?float {
  if($provider===''||$model==='') return null;
  try{$q=$this->db->prepare('SELECT unit_type,price_per_unit FROM ai_provider_pricing WHERE provider_code=? AND model_code=? AND is_active=1 ORDER BY id DESC LIMIT 1');$q->execute([$provider,$model]);$r=$q->fetch(PDO::FETCH_ASSOC);if(!$r)return null;$units=$this->units((string)$r['unit_type'],$context);return round((float)$r['price_per_unit']*$units,8);}catch(Throwable){return null;}
 }
 public function recordEstimate(string $entityType,int $entityId,string $provider,string $model,array $context=[]):?float {
  $cost=$this->estimate($provider,$model,$context); if($cost===null)return null;
  try{$q=$this->db->prepare('SELECT unit_type,price_per_unit FROM ai_provider_pricing WHERE provider_code=? AND model_code=? AND is_active=1 ORDER BY id DESC LIMIT 1');$q->execute([$provider,$model]);$r=$q->fetch(PDO::FETCH_ASSOC);$units=$this->units((string)$r['unit_type'],$context);$this->db->prepare('INSERT INTO ai_cost_events(entity_type,entity_id,provider_code,model_code,unit_type,units,estimated_cost_usd,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())')->execute([$entityType,$entityId,$provider,$model,$r['unit_type'],$units,$cost,json_encode($context,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]); }catch(Throwable){}
  return $cost;
 }
 public function recordActual(string $entityType,int $entityId,string $provider,string $model,float $actual,array $meta=[]):void {
  if($actual<0)return; try{$q=$this->db->prepare('UPDATE ai_cost_events SET actual_cost_usd=? WHERE entity_type=? AND entity_id=? AND provider_code=? AND model_code=? ORDER BY id DESC LIMIT 1');$q->execute([$actual,$entityType,$entityId,$provider,$model]);if($q->rowCount()===0)$this->db->prepare('INSERT INTO ai_cost_events(entity_type,entity_id,provider_code,model_code,unit_type,units,actual_cost_usd,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())')->execute([$entityType,$entityId,$provider,$model,'actual',1,$actual,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);}catch(Throwable){}
 }
 public function report(int $days=30):array {
  $days=max(1,min(365,$days));$out=[];try{$q=$this->db->prepare('SELECT DATE(created_at) day,provider_code,model_code,SUM(COALESCE(actual_cost_usd,estimated_cost_usd,0)) total_usd,SUM(CASE WHEN actual_cost_usd IS NOT NULL THEN actual_cost_usd ELSE 0 END) actual_usd,SUM(CASE WHEN actual_cost_usd IS NULL THEN COALESCE(estimated_cost_usd,0) ELSE 0 END) estimated_usd,COUNT(*) events FROM ai_cost_events WHERE created_at>=DATE_SUB(NOW(),INTERVAL ? DAY) GROUP BY DATE(created_at),provider_code,model_code ORDER BY day DESC');$q->execute([$days]);$out=$q->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable){}return $out;
 }
 private function units(string $unit,array $c):float { $u=strtolower($unit); if($u==='second')return max(1,(float)($c['duration_seconds']??$c['duration']??1)); if($u==='minute')return max(1,ceil(((float)($c['duration_seconds']??60))/60)); if($u==='token')return max(1,(float)($c['tokens']??$c['total_tokens']??1)); if($u==='1k_tokens'||$u==='1000_tokens')return max(0.001,(float)($c['tokens']??1)/1000); return 1.0; }
}
