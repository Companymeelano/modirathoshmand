<?php
declare(strict_types=1);
final class ShippingService {
 public function __construct(private PDO $db){}
 public function quote(array $destination,float $subtotal,float $weight=0,?int $categoryId=null):array {
  $q=$this->db->query('SELECT id,name,category_id,min_weight,max_weight,min_price,max_price,shipping_cost,cargo_cost,region_type,priority,conditions FROM shipping_rules WHERE is_active=1 ORDER BY priority DESC,id ASC');$rules=$q->fetchAll(PDO::FETCH_ASSOC);
  foreach($rules as $r){
   if($r['category_id']!==null&&$categoryId!==null&&(int)$r['category_id']!==$categoryId)continue;
   if($r['category_id']!==null&&$categoryId===null)continue;
   $minW=$r['min_weight']!==null?(float)$r['min_weight']:null;$maxW=$r['max_weight']!==null?(float)$r['max_weight']:null;$minP=$r['min_price']!==null?(float)$r['min_price']:null;$maxP=$r['max_price']!==null?(float)$r['max_price']:null;
   if($minW!==null&&$weight<$minW||$maxW!==null&&$weight>$maxW||$minP!==null&&$subtotal<$minP||$maxP!==null&&$subtotal>$maxP)continue;
   if(!$this->regionMatches((string)$r['region_type'],$destination,$r['conditions']))continue;
   return ['available'=>true,'amount'=>round((float)$r['shipping_cost']+(float)$r['cargo_cost'],2),'rule_id'=>(int)$r['id'],'name'=>$r['name'],'region_type'=>$r['region_type']];
  }
  return ['available'=>false,'amount'=>0,'rule_id'=>null,'reason'=>'NO_RULE'];
 }
 private function regionMatches(string $type,array $d,$conditions):bool { if($type==='custom'){ $c=json_decode((string)$conditions,true); if(!is_array($c))return true; foreach(['province','city','postal_prefix'] as $k){if(isset($c[$k])&&isset($d[$k])){if($k==='postal_prefix'&&!str_starts_with((string)$d[$k],(string)$c[$k]))return false;if($k!=='postal_prefix'&&(string)$c[$k]!==(string)$d[$k])return false;}} return true;} if($type==='local')return !empty($d['is_local']); if($type==='out_of_city')return isset($d['is_local'])?!(bool)$d['is_local']:true; if($type==='out_of_province')return !empty($d['out_of_province']); return true; }
}
