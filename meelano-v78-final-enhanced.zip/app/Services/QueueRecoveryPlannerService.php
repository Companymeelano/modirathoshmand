<?php
declare(strict_types=1);
final class QueueRecoveryPlannerService
{
    public function __construct(private PDO $db) {}
    public function preview(int $limit=50): array
    {
        $limit=max(1,min(200,$limit));
        if(!$this->table('social_publish_jobs'))return ['status'=>'unavailable','reason'=>'social_publish_jobs table not found','candidates'=>[]];
        $cols=$this->columns('social_publish_jobs');$hasLease=in_array('claim_expires_at',$cols,true);$hasExternal=in_array('external_post_id',$cols,true);$hasError=in_array('last_error',$cols,true);
        $candidates=[];
        if($hasLease){$sql="SELECT id,platform,status,attempts,".($hasExternal?'external_post_id':'NULL external_post_id').",".($hasError?'last_error':'NULL last_error').",claim_expires_at FROM social_publish_jobs WHERE status='Processing' AND claim_expires_at IS NOT NULL AND claim_expires_at<NOW() ORDER BY claim_expires_at,id LIMIT {$limit}";$q=$this->db->query($sql);foreach($q->fetchAll(PDO::FETCH_ASSOC)?:[] as $r){$decision=trim((string)($r['external_post_id']??''))!==''?'reconcile':'manual_review';$candidates[]=['job_id'=>(int)$r['id'],'platform'=>$r['platform'],'status'=>$r['status'],'attempts'=>(int)$r['attempts'],'claim_expires_at'=>$r['claim_expires_at'],'decision'=>$decision,'safe_action'=>$decision==='reconcile'?'release lease for provider reconciliation':'move to RecoveryRequired/manual review'];}}
        return ['status'=>'ok','candidate_count'=>count($candidates),'candidates'=>$candidates,'safety'=>'preview_only','note'=>'No queue state is changed by this endpoint.'];
    }
    private function columns(string $table):array{$q=$this->db->prepare('SELECT COLUMN_NAME FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$table]);return array_map(static fn($r)=>(string)$r['COLUMN_NAME'],$q->fetchAll(PDO::FETCH_ASSOC)?:[]);}
    private function table(string $t):bool{try{$q=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$t]);return (int)$q->fetchColumn()===1;}catch(Throwable){return false;}}
}
