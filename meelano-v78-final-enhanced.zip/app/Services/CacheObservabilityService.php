<?php
declare(strict_types=1);
final class CacheObservabilityService
{
    public function __construct(private PDO $db) {}

    public function report(int $hours=24): array
    {
        $hours=max(1,min(168,$hours));
        if(!$this->table('system_cache_metrics')) return ['status'=>'unavailable','reason'=>'system_cache_metrics table not found'];
        $q=$this->db->prepare('SELECT namespace,event_type,COUNT(*) event_count,ROUND(AVG(duration_ms),3) avg_duration_ms,ROUND(MAX(duration_ms),3) max_duration_ms FROM system_cache_metrics WHERE created_at>=DATE_SUB(NOW(),INTERVAL ? HOUR) GROUP BY namespace,event_type ORDER BY event_count DESC,namespace');
        $q->execute([$hours]);
        $rows=$q->fetchAll(PDO::FETCH_ASSOC)?:[];
        $ns=[];
        foreach($rows as $r){$n=(string)$r['namespace'];$e=(string)$r['event_type'];$c=(int)$r['event_count'];$ns[$n]??=['namespace'=>$n,'hits'=>0,'misses'=>0,'flushes'=>0,'events'=>0,'avg_miss_ms'=>null];$ns[$n]['events']+=$c;if(in_array($e,['hit','hit_after_wait','hit_after_lock'],true))$ns[$n]['hits']+=$c;if($e==='miss'){$ns[$n]['misses']+=$c;$ns[$n]['avg_miss_ms']=(float)$r['avg_duration_ms'];}if($e==='namespace_flush')$ns[$n]['flushes']+=$c;}
        foreach($ns as &$v){$total=$v['hits']+$v['misses'];$v['hit_rate']=$total?round($v['hits']/$total*100,2):0;}$ns=array_values($ns);usort($ns,static fn($a,$b)=>$b['events']<=>$a['events']);
        $invalidations=[];
        if($this->table('system_cache_invalidation_events')){$q=$this->db->prepare('SELECT namespace,reason,created_at FROM system_cache_invalidation_events WHERE created_at>=DATE_SUB(NOW(),INTERVAL ? HOUR) ORDER BY id DESC LIMIT 100');$q->execute([$hours]);$invalidations=$q->fetchAll(PDO::FETCH_ASSOC)?:[];}
        return ['status'=>'ok','hours'=>$hours,'namespaces'=>$ns,'invalidation_events'=>$invalidations,'recommendations'=>$this->recommend($ns)];
    }
    private function recommend(array $ns):array{ $out=[];foreach($ns as $n){if(($n['misses']??0)>=20 && ($n['hit_rate']??0)<50)$out[]=['namespace'=>$n['namespace'],'action'=>'review_ttl_or_invalidation_frequency','reason'=>'high miss pressure'];if(($n['flushes']??0)>=20)$out[]=['namespace'=>$n['namespace'],'action'=>'review_write-triggered invalidation','reason'=>'frequent namespace flush'];}return $out; }
    private function table(string $t):bool{try{$q=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$t]);return (int)$q->fetchColumn()===1;}catch(Throwable){return false;}}
}
