<?php
declare(strict_types=1);
final class ReservationLedger {
    public function __construct(private PDO $db){}
    public function record(int $orderId,?int $orderItemId,int $productId,?int $variantId,int $warehouseId,float $quantity,string $status='reserved'):int {
        $this->db->prepare('INSERT INTO product_inventory_reservations(order_id,order_item_id,product_id,variant_id,warehouse_id,quantity,status) VALUES(?,?,?,?,?,?,?)')->execute([$orderId,$orderItemId,$productId,$variantId,$warehouseId,$quantity,$status]);
        return (int)$this->db->lastInsertId();
    }
    public function transitionForItem(int $orderItemId,string $from,string $to,float $quantity):int {
        $q=$this->db->prepare('SELECT id,quantity FROM product_inventory_reservations WHERE order_item_id=? AND status=? ORDER BY id FOR UPDATE');
        $q->execute([$orderItemId,$from]); $left=$quantity; $changed=0;
        while($left>0.000001 && ($r=$q->fetch(PDO::FETCH_ASSOC))){
            $take=min($left,(float)$r['quantity']);
            if($take >= (float)$r['quantity']-0.000001){
                $u=$this->db->prepare('UPDATE product_inventory_reservations SET status=?,updated_at=NOW() WHERE id=? AND status=?');
                $u->execute([$to,$r['id'],$from]); $changed+=(int)$u->rowCount();
            } else {
                $this->db->prepare('UPDATE product_inventory_reservations SET quantity=quantity-?,updated_at=NOW() WHERE id=? AND status=?')->execute([$take,$r['id'],$from]);
                $this->db->prepare('INSERT INTO product_inventory_reservations(order_id,order_item_id,product_id,variant_id,warehouse_id,quantity,status) SELECT order_id,order_item_id,product_id,variant_id,warehouse_id,?,? FROM product_inventory_reservations WHERE id=?')->execute([$take,$to,$r['id']]);
                $changed++;
            }
            $left-=$take;
        }
        if($left>0.000001) throw new RuntimeException('رکورد رزرو متناظر برای آیتم سفارش پیدا نشد.');
        return $changed;
    }
    public function transitionOrder(int $orderId,string $from,string $to):int {
        $q=$this->db->prepare('UPDATE product_inventory_reservations SET status=?,updated_at=NOW() WHERE order_id=? AND status=?');$q->execute([$to,$orderId,$from]);return $q->rowCount();
    }
}
