<?php
declare(strict_types=1);
final class AICreativeLearningService {
 public function __construct(private PDO $db, private Audit $audit){}

 public function run(?string $platform=null, ?int $productId=null, int $userId=0, int $windowDays=90):array {
  $windowDays=max(7,min(365,$windowDays));
  $platform=$platform!==null&&trim($platform)!==''?strtolower(trim($platform)):null;
  if($platform!==null && !in_array($platform,['instagram','tiktok','youtube','linkedin'],true)) throw new InvalidArgumentException('پلتفرم نامعتبر است.');
  $observations=$this->collect($platform,$productId,$windowDays);
  $factors=$this->aggregateFactors($observations);
  $recommendations=$this->recommend($factors,$observations);
  $confidence=$this->overallConfidence($observations,$factors);
  $stmt=$this->db->prepare('INSERT INTO social_ai_learning_snapshots(platform,product_id,window_days,sample_count,confidence,observations_json,recommendations_json,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())');
  $stmt->execute([$platform,$productId,$windowDays,count($observations),$confidence,json_encode($observations,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),json_encode($recommendations,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$userId?:null]);
  $snapshotId=(int)$this->db->lastInsertId();
  $ins=$this->db->prepare('INSERT INTO social_ai_learning_factors(snapshot_id,platform,factor_type,factor_key,sample_count,weighted_score,confidence,evidence_json,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())');
  foreach($factors as $f){$ins->execute([$snapshotId,$f['platform'],$f['factor_type'],$f['factor_key'],$f['sample_count'],$f['weighted_score'],$f['confidence'],json_encode($f['evidence'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);}
  if($userId>0)$this->audit->log($userId,'ai_creative_learning_run','social_ai_learning_snapshots',$snapshotId,$snapshotId,['platform'=>$platform,'product_id'=>$productId,'samples'=>count($observations),'confidence'=>$confidence]);
  return $this->get($snapshotId);
 }

 public function latest(?string $platform=null, ?int $productId=null):?array {
  $where=[];$args=[];
  if($platform!==null&&$platform!==''){$where[]='platform=?';$args[]=strtolower($platform);}
  if($productId!==null&&$productId>0){$where[]='product_id=?';$args[]=$productId;}
  $q=$this->db->prepare('SELECT * FROM social_ai_learning_snapshots '.($where?'WHERE '.implode(' AND ',$where):'').' ORDER BY created_at DESC,id DESC LIMIT 1');$q->execute($args);$r=$q->fetch(PDO::FETCH_ASSOC);return $r?$this->decodeSnapshot($r):null;
 }
 public function list(?string $platform=null,int $limit=20):array {
  $limit=max(1,min(100,$limit));$args=[];$where='';
  if($platform!==null&&$platform!==''){$where='WHERE platform=?';$args[]=$platform;}
  $q=$this->db->prepare('SELECT id,platform,product_id,window_days,sample_count,confidence,created_by,created_at FROM social_ai_learning_snapshots '.$where.' ORDER BY id DESC LIMIT '.$limit);$q->execute($args);return $q->fetchAll(PDO::FETCH_ASSOC);
 }
 public function get(int $id):array {
  $q=$this->db->prepare('SELECT * FROM social_ai_learning_snapshots WHERE id=? LIMIT 1');$q->execute([$id]);$r=$q->fetch(PDO::FETCH_ASSOC);if(!$r)throw new InvalidArgumentException('Learning Snapshot یافت نشد.');
  $r=$this->decodeSnapshot($r);$q=$this->db->prepare('SELECT * FROM social_ai_learning_factors WHERE snapshot_id=? ORDER BY factor_type,weighted_score DESC,sample_count DESC');$q->execute([$id]);$r['factors']=$q->fetchAll(PDO::FETCH_ASSOC);foreach($r['factors'] as &$f)$f['evidence']=json_decode((string)$f['evidence_json'],true)?:[];unset($f);return $r;
 }

 /** Returns a compact, evidence-weighted hint consumed by the variant orchestrator. */
 public function hint(string $platform, ?int $productId=null):array {
  $r=$this->latest($platform,$productId)??$this->latest($platform,null);
  if(!$r)return ['available'=>false,'confidence'=>0,'weights'=>[],'notes'=>['No learning snapshot available.']];
  return ['available'=>true,'snapshot_id'=>(int)$r['id'],'confidence'=>(float)$r['confidence'],'weights'=>$r['recommendations']['variant_weights']??[],'hook_weights'=>$r['recommendations']['hook_weights']??[],'cta_weights'=>$r['recommendations']['cta_weights']??[],'timing'=>$r['recommendations']['timing']??[],'notes'=>$r['recommendations']['notes']??[]];
 }

 private function collect(?string $platform,?int $productId,int $days):array {
  $rows=[];$rows=array_merge($rows,$this->performanceObservations($platform,$productId,$days));
  $rows=array_merge($rows,$this->experimentObservations($platform,$productId,$days));
  return $rows;
 }
 private function performanceObservations(?string $platform,?int $productId,int $days):array {
  try{$where=['captured_at>=DATE_SUB(NOW(),INTERVAL '.$days.' DAY)'];$args=[];if($platform){$where[]='platform=?';$args[]=$platform;}
   $q=$this->db->prepare('SELECT * FROM social_content_performance WHERE '.implode(' AND ',$where).' ORDER BY captured_at DESC,id DESC LIMIT 2000');$q->execute($args);$out=[];$seen=[];
   foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r){$m=$this->json($r['metadata']??''); $dedupeKey=(string)$r['platform'].'|'.(string)($r['external_content_id']??''); if($dedupeKey!=='|' && isset($seen[$dedupeKey]))continue; if($dedupeKey!=='|')$seen[$dedupeKey]=true;$pid=(int)($m['product_id']??$m['productId']??0);if($productId!==null&&$productId>0&&$pid!==$productId)continue;
    $features=$this->features($m,$r);$score=$this->metricScore($r);if($score===null)continue;$out[]=$this->observation((string)$r['platform'],$score,$r['captured_at']??$r['published_at']??null,$features,'performance',(string)($r['external_content_id']??''));}
   return $out;
  }catch(Throwable){return [];}
 }
 private function experimentObservations(?string $platform,?int $productId,int $days):array {
  try{$where=['e.created_at>=DATE_SUB(NOW(),INTERVAL '.$days.' DAY)'];$args=[];if($platform){$where[]='e.platform=?';$args[]=$platform;}
   $sql='SELECT e.platform,e.created_at,e.primary_metric,v.*,c.metadata,c.caption,c.media_type FROM social_content_experiments e JOIN social_content_experiment_variants v ON v.experiment_id=e.id LEFT JOIN social_contents c ON c.id=v.content_id WHERE '.implode(' AND ',$where).' ORDER BY e.id DESC,v.id DESC LIMIT 2000';
   $q=$this->db->prepare($sql);$q->execute($args);$out=[];
   foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r){$m=$this->json($r['metadata']??'');$pid=(int)($m['product_id']??$m['productId']??0);if($productId!==null&&$productId>0&&$pid!==$productId)continue;
    $score=$this->experimentScore($r);if($score===null)continue;$features=$this->features($m,$r);$features['variant_key']=(string)($r['variant_key']??$features['variant_key']??'');$out[]=$this->observation((string)$r['platform'],$score,$r['updated_at']??$r['created_at']??null,$features,'experiment','experiment:'.(int)$r['experiment_id'].':variant:'.(int)$r['id']);}
   return $out;
  }catch(Throwable){return [];}
 }
 private function features(array $m,array $r):array {
  $strategy=$m['variant_strategy']??$m['strategy']??$m['variant']??$r['variant_key']??null;
  if(is_array($strategy))$strategy=$strategy['name']??null;
  return [
   'strategy'=>$this->normKey($strategy),
   'hook_style'=>$this->normKey($m['hook_style']??$m['hookStyle']??$m['hook_type']??$m['hook']??null),
   'cta_style'=>$this->normKey($m['cta_style']??$m['ctaStyle']??$m['cta_type']??$m['cta']??null),
   'media_type'=>$this->normKey($r['media_type']??$m['format']??null),
   'variant_key'=>$this->normKey($m['variant_key']??$m['variant']??$r['variant_key']??null),
   'published_hour'=>$this->hour($r['published_at']??null),
  ];
 }
 private function aggregateFactors(array $obs):array {
  $groups=[];foreach($obs as $o){foreach(['strategy','hook_style','cta_style','media_type','variant_key','published_hour'] as $type){$k=$o['features'][$type]??null;if($k===null||$k==='')continue;$key=(string)$k;$id=$o['platform'].'|'.$type.'|'.$key;if(!isset($groups[$id]))$groups[$id]=['platform'=>$o['platform'],'factor_type'=>$type,'factor_key'=>$key,'sample_count'=>0,'sum'=>0.0,'sumw'=>0.0,'scores'=>[]];$w=$this->recencyWeight($o['at']);$groups[$id]['sample_count']++;$groups[$id]['sum']+=$o['score']*$w;$groups[$id]['sumw']+=$w;$groups[$id]['scores'][]=$o['score'];}}
  $out=[];foreach($groups as $g){$mean=$g['sumw']>0?$g['sum']/$g['sumw']:0;$shrunk=$this->shrink($mean,$g['sample_count']);$conf=$this->factorConfidence($g['sample_count'],count($obs),$g['scores']);$out[]=['platform'=>$g['platform'],'factor_type'=>$g['factor_type'],'factor_key'=>$g['factor_key'],'sample_count'=>$g['sample_count'],'weighted_score'=>round($shrunk,6),'confidence'=>$conf,'evidence'=>['raw_weighted_mean'=>round($mean,6),'score_min'=>min($g['scores']),'score_max'=>max($g['scores'])]];}
  usort($out,fn($a,$b)=>($b['weighted_score']<=>$a['weighted_score'])?:($b['sample_count']<=>$a['sample_count']));return $out;
 }
 private function recommend(array $factors,array $obs):array {
  $by=function(string $type)use($factors){$x=array_values(array_filter($factors,fn($f)=>$f['factor_type']===$type&&$f['sample_count']>=2));usort($x,fn($a,$b)=>($b['weighted_score']<=>$a['weighted_score'])?:($b['confidence']<=>$a['confidence']));return $x;};
  $variant=$by('strategy');$hooks=$by('hook_style');$ctas=$by('cta_style');$hours=$by('published_hour');
  return ['variant_weights'=>$this->weights($variant),'hook_weights'=>$this->weights($hooks),'cta_weights'=>$this->weights($ctas),'timing'=>$this->timing($hours),'notes'=>[
   'Recommendations are evidence-weighted correlations, not causal guarantees.','Factors with fewer than 2 observations are excluded from active weighting.','Recent observations receive higher weight; low-sample results are shrunk toward the platform baseline.','No Explore/FYP/viral outcome is guaranteed.'
  ],'evidence'=>['observations'=>count($obs),'minimum_active_samples'=>2]];
 }
 private function weights(array $rows):array {if(!$rows)return []; $top=array_slice($rows,0,6);$base=max(1.0,(float)$top[0]['weighted_score']);$out=[];foreach($top as $r)$out[$r['factor_key']]=round(max(.1,min(2.0,(float)$r['weighted_score']/$base)),3);return $out;}
 private function timing(array $rows):array {if(!$rows)return [];return array_map(fn($r)=>['hour'=>(int)$r['factor_key'],'weight'=>round(max(.1,min(2.0,(float)$r['weighted_score'])),3),'sample_count'=>$r['sample_count'],'confidence'=>$r['confidence']],array_slice($rows,0,6));}
 private function metricScore(array $r):?float {foreach(['performance_score','engagement_rate'] as $k){if(isset($r[$k])&&is_numeric($r[$k])){$v=(float)$r[$k];return $k==='engagement_rate'?max(0,min(100,$v*100)):max(0,min(100,$v));}}$reach=(float)($r['reach']??0);$views=(float)($r['views']??0);$eng=(float)($r['engagement']??0);$den=max(1,$reach,$views);return max(0,min(100,($eng/$den)*100));}
 private function experimentScore(array $r):?float {if(isset($r['primary_rate'])&&is_numeric($r['primary_rate'])&&((float)$r['primary_rate']>0))return max(0,min(100,(float)$r['primary_rate']*100));if(isset($r['primary_value'])&&is_numeric($r['primary_value'])&&((float)$r['primary_value']>0))return max(0,min(100,(float)$r['primary_value']));$views=(float)($r['views']??0);$reach=(float)($r['reach']??0);$eng=(float)($r['engagement']??0);$den=max(1,$views,$reach);return max(0,min(100,$eng/$den*100));}
 private function observation(string $platform,float $score,?string $at,array $features,string $source,string $id):array{return ['platform'=>$platform,'score'=>round($score,6),'at'=>$at,'features'=>$features,'source'=>$source,'source_id'=>$id];}
 private function recencyWeight(?string $at):float {$t=$at?strtotime($at):false;if(!$t)return .5;$age=max(0,(time()-$t)/86400);return pow(.5,$age/45);}
 private function shrink(float $mean,int $n):float {$prior=50.0;return (($mean*$n)+($prior*3))/($n+3);}
 private function factorConfidence(int $n,int $total,array $scores):float {$coverage=$total>0?min(1,$n/10):0;$stability=1.0;if(count($scores)>1){$avg=array_sum($scores)/count($scores);$var=0;foreach($scores as $s)$var+=($s-$avg)**2;$var/=(count($scores)-1);$stability=max(0,min(1,1-sqrt($var)/50));}return round(min(1,$coverage*.65+$stability*.35),3);}
 private function overallConfidence(array $obs,array $factors):float {$n=count($obs);if(!$n)return 0.0;$factorEvidence=count(array_filter($factors,fn($f)=>$f['sample_count']>=2));return round(min(1,($n/30)*.55+min(1,$factorEvidence/12)*.45),3);}
 private function decodeSnapshot(array $r):array{$r['observations']=json_decode((string)$r['observations_json'],true)?:[];$r['recommendations']=json_decode((string)$r['recommendations_json'],true)?:[];return $r;}
 private function json($v):array{$x=json_decode((string)$v,true);return is_array($x)?$x:[];}
 private function normKey($v):string{$s=trim((string)$v);if($s==='')return '';return strtolower(preg_replace('/[^a-zA-Z0-9_\-:.]+/','_',mb_strtolower($s))??$s);}
 private function hour($v):string {if(!$v)return '';try{return (string)(int)date('G',strtotime((string)$v));}catch(Throwable){return '';}}
}
