<?php
declare(strict_types=1);
final class SocialAnalyticsService {
 public function __construct(private PDO $db, private Audit $audit){}
 private function account(int $id):array{
  $q=$this->db->prepare("SELECT * FROM social_accounts WHERE id=? AND status='active' LIMIT 1");$q->execute([$id]);$a=$q->fetch(PDO::FETCH_ASSOC);
  if(!$a) throw new InvalidArgumentException('حساب اجتماعی فعال یافت نشد.');
  return $a;
 }
 public function syncTikTok(int $accountId,int $userId=0):array{
  $a=$this->account($accountId); if($a['platform']!=='tiktok') throw new InvalidArgumentException('این Sync فقط برای TikTok فعال است.');
  $token=SocialTokenCipher::decrypt($a['access_token_enc']??null); if($token==='') throw new SocialException('TikTok access token is not configured.');
  $fields='open_id,union_id,avatar_url,display_name,profile_deep_link,bio_description,is_verified,username,follower_count,following_count,likes_count,video_count';
  $profile=SocialHttp::request('GET','https://open.tiktokapis.com/v2/user/info/?fields='.rawurlencode($fields),['Authorization'=>'Bearer '.$token]);
  $u=$profile['data']['user']??[];
  $videos=[]; $cursor=null;
  do {
   $body=['max_count'=>20]; if($cursor!==null)$body['cursor']=$cursor;
   $r=SocialHttp::request('POST','https://open.tiktokapis.com/v2/video/list/?fields=id,create_time,title,video_description,like_count,comment_count,share_count,view_count,share_url,embed_link',['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],$body);
   foreach(($r['data']['videos']??[]) as $v)$videos[]=$v;
   $resp=$r['data']['has_more']??false; $cursor=$resp?($r['data']['cursor']??null):null;
  } while($cursor!==null && count($videos)<50);
  $likes=0;$comments=0;$shares=0;$views=0;foreach($videos as $v){$likes+=(int)($v['like_count']??0);$comments+=(int)($v['comment_count']??0);$shares+=(int)($v['share_count']??0);$views+=(int)($v['view_count']??0);}
  $engagement=$likes+$comments+$shares;
  $meta=json_decode((string)($a['metadata']??'{}'),true)?:[];$meta['profile']=$u;$meta['recent_video_metrics']=['count'=>count($videos),'likes'=>$likes,'comments'=>$comments,'shares'=>$shares,'views'=>$views,'synced_at'=>date('c')];
  $this->db->prepare('INSERT INTO social_analytics_snapshots(account_id,captured_at,followers,following,posts,engagement,impressions,metadata) VALUES(?,?,?,?,?,?,?,?)')->execute([$accountId,date('Y-m-d H:i:s'),isset($u['follower_count'])?(int)$u['follower_count']:null,isset($u['following_count'])?(int)$u['following_count']:null,isset($u['video_count'])?(int)$u['video_count']:null,$engagement,$views,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
  $this->db->prepare('UPDATE social_accounts SET account_name=?,external_account_id=?,metadata=?,last_sync_at=NOW(),last_error=NULL,updated_at=NOW() WHERE id=?')->execute([trim((string)($u['display_name']??$a['account_name'])),(string)($u['open_id']??$a['external_account_id']),json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$accountId]);
  if($userId>0)$this->audit->log($userId,'social_analytics_synced','social_accounts',$accountId,$accountId,['platform'=>'tiktok']);
  return ['account_id'=>$accountId,'followers'=>$u['follower_count']??null,'following'=>$u['following_count']??null,'posts'=>$u['video_count']??null,'engagement'=>$engagement,'impressions'=>$views,'videos_sampled'=>count($videos)];
 }
 public function latest(int $accountId):?array{$q=$this->db->prepare('SELECT * FROM social_analytics_snapshots WHERE account_id=? ORDER BY captured_at DESC,id DESC LIMIT 1');$q->execute([$accountId]);$r=$q->fetch(PDO::FETCH_ASSOC);return $r?:null;}
 public function allLatest():array{$q=$this->db->query('SELECT s.*,a.platform,a.account_name FROM social_analytics_snapshots s JOIN (SELECT account_id,MAX(id) id FROM social_analytics_snapshots GROUP BY account_id) x ON x.id=s.id JOIN social_accounts a ON a.id=s.account_id ORDER BY a.platform,a.account_name');return $q->fetchAll(PDO::FETCH_ASSOC);}
}
