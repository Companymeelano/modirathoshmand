<?php
declare(strict_types=1);
final class SocialMediaUploadService {
 public function __construct(private PDO $db, private Audit $audit){}
 public function uploadTikTokVideo(array $account,array $content):array{
  $path=$this->safeLocalPath((string)($content['media_path']??''));
  $size=filesize($path); if($size===false||$size<1)throw new InvalidArgumentException('فایل ویدیو قابل خواندن نیست.');
  $mime=$this->detectMime($path); $allowed=['video/mp4'=>'video/mp4','video/quicktime'=>'video/quicktime','video/webm'=>'video/webm'];
  if(!isset($allowed[$mime]))throw new InvalidArgumentException('فرمت ویدیو باید MP4، MOV یا WebM باشد.');
  $token=SocialTokenCipher::decrypt($account['access_token_enc']??null); if($token==='')throw new SocialException('TikTok access token is not configured.');
  $info=SocialHttp::request('POST','https://open.tiktokapis.com/v2/post/publish/creator_info/query/',['Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'],[]);
  $privacy=$content['privacy_level']??(($info['data']['privacy_level_options'][0]??'SELF_ONLY'));$allowedPrivacy=$info['data']['privacy_level_options']??[];if(!in_array($privacy,$allowedPrivacy,true))$privacy=$allowedPrivacy[0]??'SELF_ONLY';
  $chunkSize=10*1024*1024;$chunks=(int)ceil($size/$chunkSize);
  $body=['post_info'=>['title'=>(string)($content['caption']??''),'privacy_level'=>$privacy,'disable_comment'=>(bool)($content['disable_comment']??false),'disable_duet'=>(bool)($content['disable_duet']??false),'disable_stitch'=>(bool)($content['disable_stitch']??false),'is_aigc'=>(bool)($content['is_aigc']??false)],'source_info'=>['source'=>'FILE_UPLOAD','video_size'=>$size,'chunk_size'=>$chunkSize,'total_chunk_count'=>$chunks]];
  $init=SocialHttp::request('POST','https://open.tiktokapis.com/v2/post/publish/video/init/',['Authorization'=>'Bearer '.$token],$body);
  $uploadUrl=(string)($init['data']['upload_url']??'');$publishId=(string)($init['data']['publish_id']??'');if($uploadUrl===''||$publishId==='')throw new SocialException('TikTok upload initialization returned incomplete data.');
  $fh=fopen($path,'rb');if($fh===false)throw new RuntimeException('فایل ویدیو باز نشد.');
  try{$index=0;$offset=0;while(!feof($fh)){$data=fread($fh,$chunkSize);if($data===false)throw new RuntimeException('خواندن chunk ویدیو ناموفق بود.');if($data==='')break;$len=strlen($data);$last=$offset+$len-1;SocialHttp::request('PUT',$uploadUrl,['Content-Type'=>$allowed[$mime],'Content-Length'=>(string)$len,'Content-Range'=>'bytes '.$offset.'-'.$last.'/'.$size],null,$data,120);$offset+=$len;$index++;}if($offset!==$size)throw new RuntimeException('آپلود ویدیو ناقص انجام شد.');}finally{fclose($fh);}
  $jobId=(int)($content['job_id']??0);$accountId=(int)($account['id']??0);$this->db->prepare('INSERT INTO social_media_uploads(platform,account_id,job_id,publish_id,upload_mode,media_type,file_size,chunk_size,total_chunks,uploaded_bytes,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())')->execute(['tiktok',$accountId,$jobId,$publishId,'FILE_UPLOAD','video',$size,$chunkSize,$chunks,$size,'completed']);
  $this->audit->log((int)($content['user_id']??0),'social_media_uploaded','social_publish_jobs',$jobId>0?'job':null,$jobId>0?$jobId:null,['platform'=>'tiktok','publish_id'=>$publishId,'chunks'=>$chunks,'size'=>$size]);
  return ['external_post_id'=>$publishId,'upload_mode'=>'FILE_UPLOAD','chunks'=>$chunks,'bytes'=>$size,'provider_status'=>'UPLOAD_SENT','provider_response'=>$init['data']??[]];
 }
 private function safeLocalPath(string $path):string{if($path===''||!is_file($path)||!is_readable($path))throw new InvalidArgumentException('مسیر فایل ویدیو نامعتبر است.');$real=realpath($path);$root=realpath(dirname(__DIR__,2));if($real===false||$root===false||($real!==$root&&strncmp($real,$root.DIRECTORY_SEPARATOR,strlen($root)+1)!==0)){throw new InvalidArgumentException('دسترسی به مسیر فایل مجاز نیست.');}return $real;}
 private function detectMime(string $path):string{$f=finfo_open(FILEINFO_MIME_TYPE);if($f===false)throw new RuntimeException('تشخیص نوع فایل در دسترس نیست.');try{$m=(string)finfo_file($f,$path);}finally{finfo_close($f);}return $m;}
}
