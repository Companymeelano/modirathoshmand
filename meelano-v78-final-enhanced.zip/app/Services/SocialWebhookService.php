<?php
declare(strict_types=1);
final class SocialWebhookService {
 public function __construct(private PDO $db, private Audit $audit){}
 public function verifyTikTokSignature(string $raw,string $header,string $secret,int $maxAge=300):void{
  $parts=[]; foreach(explode(',',trim($header)) as $part){$kv=explode('=',trim($part),2); if(count($kv)===2)$parts[$kv[0]]=$kv[1];}
  $ts=(string)($parts['t']??''); $sig=(string)($parts['s']??'');
  if($ts===''||$sig===''||$secret==='')throw new DomainException('امضای Webhook نامعتبر است.');
  if(!ctype_digit($ts)||abs(time()-(int)$ts)>$maxAge)throw new DomainException('Webhook منقضی یا خارج از بازه زمانی مجاز است.');
  $expected=hash_hmac('sha256',$ts.'.'.$raw,$secret);
  if(!hash_equals($expected,$sig))throw new DomainException('امضای Webhook معتبر نیست.');
 }
 public function ingestTikTok(string $raw,string $signature,string $secret):array{
  $this->verifyTikTokSignature($raw,$signature,$secret);
  $payload=json_decode($raw,true); if(!is_array($payload))throw new InvalidArgumentException('Webhook JSON نامعتبر است.');
  $event=(string)($payload['event']??$payload['event_name']??''); $publishId=(string)($payload['publish_id']??($payload['data']['publish_id']??''));
  $eventId=(string)($payload['event_id']??$payload['id']??''); if($eventId==='')$eventId=hash('sha256',$raw);
  $providerStatus=$this->mapEvent($event); $postId=(string)($payload['post_id']??($payload['data']['post_id']??'')); $reason=(string)($payload['reason']??$payload['fail_reason']??($payload['data']['reason']??''));
  try{$this->db->prepare('INSERT INTO social_webhook_events(platform,event_id,event_name,publish_id,post_id,payload,received_at) VALUES(?,?,?,?,?,?,NOW())')->execute(['tiktok',$eventId,$event,$publishId,$postId,$raw]);$duplicate=false;}catch(PDOException $e){if((int)($e->errorInfo[1]??0)!==1062)throw $e;$duplicate=true;}
  if(!$duplicate && $publishId!=='' && $providerStatus!==null){
   $status=$providerStatus==='Completed'?'Completed':($providerStatus==='Failed'?'Failed':'Processing');
   $this->db->prepare("UPDATE social_publish_jobs SET provider_status=?,status=?,published_at=CASE WHEN ?='Completed' THEN COALESCE(published_at,NOW()) ELSE published_at END,last_error=CASE WHEN ?='Failed' THEN NULLIF(?, '') ELSE NULL END,provider_checked_at=NOW(),updated_at=NOW() WHERE platform='tiktok' AND external_post_id=? AND status IN ('Queued','Processing','Retrying')")->execute([$event,$status,$status,$status,$reason,$publishId]);
  }
  return ['accepted'=>true,'duplicate'=>$duplicate,'event'=>$event,'publish_id'=>$publishId,'status'=>$providerStatus??'Ignored'];
 }
 private function mapEvent(string $event):?string{return match($event){'post.publish.complete'=>'Completed','post.publish.failed'=>'Failed','post.publish.publicly_available'=>'Completed','post.publish.no_longer_publicaly_available'=>'Processing','post.publish.inbox_delivered'=>'Processing',default=>null};}
}
