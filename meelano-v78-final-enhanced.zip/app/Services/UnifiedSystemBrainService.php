<?php
declare(strict_types=1);
final class UnifiedSystemBrainService
{
    public function __construct(
        private PDO $db,
        private AutonomousPerformanceService $autonomy,
        private SecurityHardeningService $security,
        private DeploymentSafetyService $deployment,
        private DisasterRecoveryService $recovery,
        private IncidentRecoveryCenterService $incidents
    ) {}

    public function analyze(bool $persist=false): array
    {
        $cycle=bin2hex(random_bytes(8));
        $autonomy=$this->safe(fn()=> $this->autonomy->plan(), ['status'=>'unavailable','actions'=>[]]);
        $security=$this->safe(fn()=> $this->security->audit(), ['status'=>'unavailable','score'=>0,'fail'=>1]);
        $deployment=$this->safe(fn()=> $this->deployment->preflight(), ['ok'=>false,'checks'=>[]]);
        $recovery=$this->safe(fn()=> $this->recovery->audit(), ['status'=>'fail','readiness'=>0,'checks'=>[]]);
        $incidents=$this->safe(fn()=> $this->incidents->overview(30), ['summary'=>[],'incidents'=>[]]);

        $signals=[];
        $securityFails=(int)($security['fail']??0);
        if($securityFails>0)$signals[]=$this->signal('security_hardening','critical',95,'ممیزی امنیتی دارای Failure است','رفع Failureهای امنیتی پیش از هر Recovery یا Deployment.',['failures'=>$securityFails]);
        if(($deployment['ok']??false)===false)$signals[]=$this->signal('deployment_preflight','high',90,'Preflight استقرار آماده نیست','Deployment نباید تا رفع موارد preflight اجرا شود.');
        $recoveryReadiness=(int)($recovery['readiness']??0);
        if($recoveryReadiness<100)$signals[]=$this->signal('disaster_recovery','high',85,'آمادگی Disaster Recovery کامل نیست','Backup/Migration/Queue/Audit باید بررسی شوند.',['readiness'=>$recoveryReadiness]);
        $criticalIncidents=(int)(($incidents['summary']['critical']??0));
        if($criticalIncidents>0)$signals[]=$this->signal('critical_incidents','critical',92,'Incident بحرانی فعال است','اولویت با Incident Center و reconcile کنترل‌شده است.',['count'=>$criticalIncidents]);
        foreach(($autonomy['actions']??[]) as $a){
            $severity=(string)($a['severity']??'medium');
            $confidence=(string)($a['confidence']??'medium');
            $score=$this->score($severity,$confidence);
            $signals[]=$this->signal((string)($a['type']??'autonomy_action'),$severity,$score,(string)($a['title']??'Autonomous recommendation'),(string)($a['reason']??''),(array)($a['context']??[]));
        }

        usort($signals,static fn($a,$b)=>($b['risk_score']<=>$a['risk_score']));
        $risk=$signals?max(array_map(static fn($s)=>(int)$s['risk_score'],$signals)):0;
        $status=$risk>=90?'critical':($risk>=70?'high':($risk>=40?'attention':'healthy'));
        $plan=[
            'brain'=>'MeeLano Unified System Brain','version'=>'V78','cycle_id'=>$cycle,'generated_at'=>gmdate('c'),
            'status'=>$status,'risk_score'=>$risk,'signal_count'=>count($signals),'signals'=>$signals,
            'decision_policy'=>['mode'=>'guarded_autonomy','automatic_destructive_actions'=>false,'automatic_sql_writes'=>false,'automatic_index_changes'=>false,'automatic_social_replay'=>false,'max_action_per_cycle'=>1,'cooldown_minutes'=>30],
            'sources'=>['autonomy'=>$autonomy,'security'=>$security,'deployment'=>$deployment,'recovery'=>$recovery,'incidents'=>$incidents]
        ];
        if($persist)$plan['persistence']=$this->persistPlan($plan);
        return $plan;
    }

    public function recent(int $limit=20): array
    {
        if(!$this->table('system_brain_runs'))return [];
        $limit=max(1,min(100,$limit));
        $q=$this->db->query('SELECT id,cycle_id,status,risk_score,signal_count,created_at FROM system_brain_runs ORDER BY id DESC LIMIT '.$limit);
        return $q->fetchAll(PDO::FETCH_ASSOC)?:[];
    }

    public function decisions(int $limit=50): array
    {
        if(!$this->table('system_brain_decisions'))return [];
        $limit=max(1,min(100,$limit));
        $q=$this->db->query('SELECT id,fingerprint,signal_type,severity,risk_score,status,occurrences,cooldown_until,created_at FROM system_brain_decisions ORDER BY id DESC LIMIT '.$limit);
        return $q->fetchAll(PDO::FETCH_ASSOC)?:[];
    }

    public function executeGuarded(string $action): array
    {
        $action=trim($action);
        if($action!=='incident_reconcile')throw new DomainException('این Action در V78 فقط برای Incident reconciliation کنترل‌شده مجاز است.');
        $cool=$this->cooldownActive('incident_reconcile');
        if($cool)return ['executed'=>false,'reason'=>'cooldown_active','cooldown_until'=>$cool];
        $result=$this->incidents->reconcile();
        $this->recordDecision('incident_reconcile','low',35,'executed',$result,30);
        return ['executed'=>true,'action'=>$action,'result'=>$result,'guardrail'=>'single low-risk reconciliation; no publishing, SQL or deployment mutation'];
    }

    private function persistPlan(array $plan): array
    {
        if(!$this->table('system_brain_runs'))return ['stored'=>false,'reason'=>'table_unavailable'];
        $q=$this->db->prepare('INSERT INTO system_brain_runs(cycle_id,status,risk_score,signal_count,plan_json,created_at) VALUES(?,?,?,?,?,NOW())');
        $q->execute([$plan['cycle_id'],$plan['status'],(int)$plan['risk_score'],(int)$plan['signal_count'],json_encode($plan,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
        $runId=(int)$this->db->lastInsertId(); $stored=0;$suppressed=0;
        foreach(($plan['signals']??[]) as $s){
            $fingerprint=hash('sha256',(string)$s['signal_type'].'|'.(string)$s['severity'].'|'.json_encode($s['context'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            if($this->cooldownActive($fingerprint)){$suppressed++;$this->touchDecision($fingerprint);continue;}
            $this->recordDecision((string)$s['signal_type'],(string)$s['severity'],(int)$s['risk_score'],'recommended',$s['context'],30,$fingerprint,$runId);$stored++;
        }
        return ['stored'=>true,'run_id'=>$runId,'decisions_stored'=>$stored,'decisions_suppressed_by_cooldown'=>$suppressed];
    }

    private function recordDecision(string $type,string $severity,int $score,string $status,array $context,int $cooldown,string $fingerprint=null,?int $runId=null): void
    {
        if(!$this->table('system_brain_decisions'))return;
        $fingerprint??=hash('sha256',$type.'|'.$severity.'|'.json_encode($context,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        $q=$this->db->prepare('SELECT id FROM system_brain_decisions WHERE fingerprint=? LIMIT 1');$q->execute([$fingerprint]);$id=$q->fetchColumn();
        if($id){$u=$this->db->prepare('UPDATE system_brain_decisions SET status=?,risk_score=?,occurrences=occurrences+1,cooldown_until=DATE_ADD(NOW(),INTERVAL ? MINUTE),last_run_id=? WHERE id=?');$u->execute([$status,$score,$cooldown,$runId,(int)$id]);return;}
        $i=$this->db->prepare('INSERT INTO system_brain_decisions(fingerprint,signal_type,severity,risk_score,status,occurrences,cooldown_until,last_run_id,context_json,created_at) VALUES(?,?,?,?,?,1,DATE_ADD(NOW(),INTERVAL ? MINUTE),?,?,NOW())');$i->execute([$fingerprint,$type,$severity,$score,$status,$cooldown,$runId,json_encode($context,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
    }
    private function cooldownActive(string $key): mixed
    {
        if(!$this->table('system_brain_decisions'))return null;
        $fingerprint=$key;
        if(!preg_match('/^[a-f0-9]{64}$/',$key)){$fingerprint=hash('sha256',$key);}
        $q=$this->db->prepare('SELECT cooldown_until FROM system_brain_decisions WHERE fingerprint=? AND cooldown_until>NOW() ORDER BY id DESC LIMIT 1');$q->execute([$fingerprint]);return $q->fetchColumn()?:null;
    }
    private function touchDecision(string $fingerprint): void {try{$this->db->prepare('UPDATE system_brain_decisions SET occurrences=occurrences+1 WHERE fingerprint=?')->execute([$fingerprint]);}catch(Throwable){}}
    private function signal(string $type,string $severity,int $score,string $title,string $reason,array $context=[]):array{return ['signal_type'=>$type,'severity'=>$severity,'risk_score'=>max(0,min(100,$score)),'title'=>$title,'reason'=>$reason,'context'=>$context,'automatic_action'=>false];}
    private function score(string $severity,string $confidence):int{$base=['critical'=>90,'high'=>75,'medium'=>50,'low'=>25][$severity]??40;$bonus=['high'=>8,'medium'=>3,'low'=>0][$confidence]??0;return min(100,$base+$bonus);}
    private function safe(callable $fn,array $fallback):array{try{$v=$fn();return is_array($v)?$v:$fallback;}catch(Throwable){return $fallback;}}
    private function table(string $name):bool{try{$q=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$name]);return (int)$q->fetchColumn()===1;}catch(Throwable){return false;}}
}
