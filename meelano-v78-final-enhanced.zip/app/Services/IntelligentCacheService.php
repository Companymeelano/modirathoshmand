<?php
declare(strict_types=1);
final class IntelligentCacheService
{
    public function __construct(private CacheService $cache, private PDO $db) {}

    public function remember(string $namespace, string $key, int $ttl, callable $resolver, array $options=[]): mixed
    {
        $ttl=max(1,min(86400,$ttl));
        $full=$this->fullKey($namespace,$key);
        $cached=$this->cache->get($full,null);
        if($cached!==null){$this->metric($namespace,'hit');return $cached;}
        $lockKey=$full.':lock';
        $lock=$this->cache->lock($lockKey,(int)($options['lock_ttl']??10));
        if(!$lock){
            usleep(min(250000,max(10000,(int)($options['wait_us']??50000))));
            $cached=$this->cache->get($full,null);
            if($cached!==null){$this->metric($namespace,'hit_after_wait');return $cached;}
        }
        $started=microtime(true);
        try{
            if($lock){
                $cached=$this->cache->get($full,null);
                if($cached!==null){$this->metric($namespace,'hit_after_lock');return $cached;}
            }
            $value=$resolver();
            $this->cache->put($full,$value,$ttl);
            $this->metric($namespace,'miss',microtime(true)-$started);
            return $value;
        } finally { if($lock)$this->cache->unlock($lockKey); }
    }

    public function forget(string $namespace,string $key):bool{return $this->cache->forget($this->fullKey($namespace,$key));}
    public function flushNamespace(string $namespace):int
    {
        // Namespace generation invalidation avoids directory-wide scans on shared hosting.
        $genKey='cache-generation:'.$namespace;
        $gen=(int)$this->cache->get($genKey,0)+1;
        $this->cache->put($genKey,$gen,86400*365);
        $this->metric($namespace,'namespace_flush');
        return $gen;
    }
    public function stats(int $hours=24):array
    {
        if(!$this->table())return ['status'=>'unavailable'];
        $hours=max(1,min(168,$hours));
        $q=$this->db->prepare('SELECT event_type,COUNT(*) count,ROUND(AVG(duration_ms),3) avg_duration_ms FROM system_cache_metrics WHERE created_at>=DATE_SUB(NOW(),INTERVAL ? HOUR) GROUP BY event_type ORDER BY count DESC');
        $q->execute([$hours]);
        $rows=$q->fetchAll(PDO::FETCH_ASSOC)?:[];
        $total=0;$hits=0;
        foreach($rows as $r){$n=(int)$r['count'];$total+=$n;if(in_array($r['event_type'],['hit','hit_after_wait','hit_after_lock'],true))$hits+=$n;}
        return ['status'=>'ok','hours'=>$hours,'events'=>$rows,'hit_rate'=>$total>0?round($hits/$total*100,2):0];
    }
    private function fullKey(string $namespace,string $key):string
    {
        $gen=(int)$this->cache->get('cache-generation:'.$namespace,0);
        return 'v75:'.$namespace.':'.$gen.':'.hash('sha256',$key);
    }
    private function metric(string $namespace,string $event,?float $duration=null):void
    {try{if($this->table()){$q=$this->db->prepare('INSERT INTO system_cache_metrics(namespace,event_type,duration_ms,created_at) VALUES(?,?,?,NOW())');$q->execute([$namespace,$event,$duration===null?null:round($duration*1000,3)]);}}catch(Throwable){} }
    private function table():bool{try{$q=$this->db->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='system_cache_metrics'");return (int)$q->fetchColumn()===1;}catch(Throwable){return false;}}
}
