<?php
declare(strict_types=1);
final class AutonomousPerformanceService
{
    public function __construct(
        private PDO $db,
        private ProductionObservabilityService $observability,
        private CacheObservabilityService $cache,
        private AdaptiveIndexPlannerService $planner,
        private QueueOptimizationService $queue,
        private QueueRecoveryPlannerService $recovery,
        private IncidentRecoveryCenterService $incidents
    ) {}

    public function plan(): array
    {
        $obs=$this->observability->snapshot();
        $cache=$this->cache->report(24);
        $query=$this->planner->plan();
        $queue=$this->queue->report();
        $recovery=$this->recovery->preview(50);
        $actions=[];
        foreach(($obs['checks']??[]) as $component=>$check){
            if(($check['status']??'pass')==='fail') $actions[]=$this->action('incident_reconcile','critical','high','اجرای reconcile برای ثبت/به‌روزرسانی Incident مربوط به '.$component,'کم‌خطر؛ فقط وضعیت Incident را همگام می‌کند.');
        }
        if((int)($obs['queue']['stale_processing']??0)>0 || (int)($recovery['candidate_count']??0)>0){
            $actions[]=$this->action('queue_recovery_review','high','high','بررسی Jobهای Processing منقضی‌شده','انتشار خودکار انجام نمی‌شود؛ Jobهای دارای شناسه مقصد باید reconcile و بقیه دستی بررسی شوند.');
        }
        foreach(($cache['recommendations']??[]) as $r){
            $ns=(string)($r['namespace']??'');
            $actions[]=$this->action('cache_review','medium','medium','بازبینی Cache namespace: '.$ns,'پیشنهاد TTL/Invalidation؛ flush خودکار پیش‌فرض نیست.', ['namespace'=>$ns]);
        }
        foreach(($query['recommendations']??[]) as $r){
            $actions[]=$this->action('index_review',(string)($r['severity']??'medium'),'medium','بازبینی Index برای Query: '.(string)($r['query']??''),'Planner فقط پیشنهاد می‌دهد و Index را خودکار تغییر نمی‌دهد.');
        }
        if(($queue['status']??'')==='ok' && (int)($queue['counts']['Queued']??0)>1000){
            $actions[]=$this->action('queue_capacity_review','medium','medium','بررسی ظرفیت Worker و cadence صف','Concurrency و batch فقط به‌صورت recommendation ارائه می‌شوند.');
        }
        $priority=$this->priority($actions);
        return ['status'=>$actions?'attention':'healthy','generated_at'=>gmdate('c'),'priority'=>$priority,'summary'=>['actions'=>count($actions),'critical'=>count(array_filter($actions,static fn($a)=>$a['severity']==='critical')),'high'=>count(array_filter($actions,static fn($a)=>$a['severity']==='high'))],'actions'=>$actions,'sources'=>['observability'=>$obs,'cache'=>$cache,'query_plan'=>$query,'queue'=>$queue,'queue_recovery'=>$recovery],'guardrails'=>['mode'=>'recommendation_first','automatic_mutation'=>false,'production_sql_write'=>false,'arbitrary_sql'=>false,'publishing_replay'=>false]];
    }

    public function persist(array $plan): ?int
    {
        if(!$this->table('system_autonomy_runs')) return null;
        $q=$this->db->prepare('INSERT INTO system_autonomy_runs(status,priority,plan_json,created_at) VALUES(?,?,?,NOW())');
        $q->execute([(string)($plan['status']??'unknown'),(string)($plan['priority']??'normal'),json_encode($plan,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
        return (int)$this->db->lastInsertId();
    }

    public function recent(int $limit=20): array
    {
        if(!$this->table('system_autonomy_runs')) return [];
        $limit=max(1,min(100,$limit));
        $q=$this->db->query('SELECT id,status,priority,plan_json,created_at FROM system_autonomy_runs ORDER BY id DESC LIMIT '.$limit);
        return $q->fetchAll(PDO::FETCH_ASSOC)?:[];
    }

    public function executeSafe(string $action): array
    {
        $action=trim($action);
        if($action!=='incident_reconcile') throw new DomainException('این Action فقط recommendation است و عملیات خودکار برای آن فعال نیست.');
        return ['action'=>$action,'executed'=>true,'result'=>$this->incidents->reconcile(),'guardrail'=>'incident state reconciliation only'];
    }

    private function action(string $type,string $severity,string $confidence,string $title,string $reason,array $context=[]):array{return ['id'=>hash('sha256',$type.'|'.$title.'|'.json_encode($context)),'type'=>$type,'severity'=>$severity,'confidence'=>$confidence,'title'=>$title,'reason'=>$reason,'context'=>$context,'auto_executable'=>in_array($type,['incident_reconcile'],true)];}
    private function priority(array $actions):string{foreach(['critical','high','medium'] as $s)foreach($actions as $a)if(($a['severity']??'')===$s)return $s;return 'normal';}
    private function table(string $t):bool{try{$q=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$t]);return (int)$q->fetchColumn()===1;}catch(Throwable){return false;}}
}
