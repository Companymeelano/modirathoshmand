<?php
declare(strict_types=1);
final class SocialPublishingStatusService {
 public function __construct(private PDO $db, private Audit $audit){}
 private function jobs(int $limit):array{
  $limit=max(1,min(50,$limit));
  $q=$this->db->query("SELECT j.*,a.id AS account_id,a.access_token_enc,a.account_name,a.external_account_id,a.scopes,a.metadata FROM social_publish_jobs j JOIN social_accounts a ON a.id=j.account_id WHERE j.status='Processing' AND j.external_post_id IS NOT NULL AND j.external_post_id<>'' AND a.status='active' ORDER BY j.updated_at ASC,j.id ASC LIMIT {$limit}");
  return $q->fetchAll(PDO::FETCH_ASSOC);
 }
 public function syncDue(int $limit=25,int $userId=0):array{
  $out=[];
  foreach($this->jobs($limit) as $job){
   $id=(int)$job['id']; $platform=(string)$job['platform'];
   try{
    if($platform==='tiktok'){$r=(new TikTokAdapter())->postStatus($job,(string)$job['external_post_id']);$data=$r['data']??[];$provider=(string)($data['status']??'UNKNOWN');$mapped=$this->mapTikTok($provider);$failReason=(string)($data['fail_reason']??$data['error']['message']??'TikTok publish failed');}
    elseif($platform==='youtube'){$r=(new YouTubeAdapter())->postStatus($job,(string)$job['external_post_id']);$data=$r['json']['items'][0]??[];$provider=(string)($data['processingDetails']['processingStatus']??$data['status']['uploadStatus']??'UNKNOWN');$mapped=$this->mapYouTube($provider);$failReason=(string)($data['processingDetails']['processingFailureReason']??'YouTube processing failed');}
    else{$out[]=['job_id'=>$id,'status'=>'Skipped','reason'=>'unsupported_platform'];continue;}
    $this->db->prepare('UPDATE social_publish_jobs SET provider_status=?,provider_checked_at=NOW(),last_error=CASE WHEN ?=\'Failed\' THEN ? ELSE NULL END,published_at=CASE WHEN ?=\'Completed\' THEN COALESCE(published_at,NOW()) ELSE published_at END,status=?,updated_at=NOW() WHERE id=? AND status=\'Processing\'')->execute([$provider,$mapped,$failReason,$mapped,$mapped,$id]);
    if($mapped==='Completed'){$this->db->prepare("UPDATE social_publish_jobs SET last_error=NULL WHERE id=?")->execute([$id]);}
    if($userId>0)$this->audit->log($userId,'social_publish_status_synced','social_publish_jobs',$id,$id,['platform'=>$platform,'provider_status'=>$provider,'status'=>$mapped]);
    $out[]=['job_id'=>$id,'provider_status'=>$provider,'status'=>$mapped,'data'=>$data];
   }catch(Throwable $e){
    $retry=$e instanceof SocialException && $e->retryable;
    $this->db->prepare('UPDATE social_publish_jobs SET provider_checked_at=NOW(),last_error=?,updated_at=NOW() WHERE id=?')->execute([mb_substr($e->getMessage(),0,500),$id]);
    $out[]=['job_id'=>$id,'status'=>'Error','retryable'=>$retry,'error'=>$e->getMessage()];
   }
  }
  return $out;
 }
 public function syncOne(int $jobId,int $userId=0):array{
  $q=$this->db->prepare("SELECT j.*,a.id AS account_id,a.access_token_enc,a.account_name,a.external_account_id,a.scopes,a.metadata FROM social_publish_jobs j JOIN social_accounts a ON a.id=j.account_id WHERE j.id=? LIMIT 1");$q->execute([$jobId]);$job=$q->fetch(PDO::FETCH_ASSOC);
  if(!$job)throw new InvalidArgumentException('Job یافت نشد.');
  if(!in_array((string)$job['platform'],['tiktok','youtube'],true))throw new DomainException('بررسی وضعیت این پلتفرم هنوز پیاده‌سازی نشده است.');
  if(trim((string)$job['external_post_id'])==='')throw new DomainException('publish_id برای این Job ثبت نشده است.');
  if((string)$job['platform']==='tiktok'){$r=(new TikTokAdapter())->postStatus($job,(string)$job['external_post_id']);$data=$r['data']??[];$provider=(string)($data['status']??'UNKNOWN');$mapped=$this->mapTikTok($provider);$failReason=(string)($data['fail_reason']??$data['error']['message']??'TikTok publish failed');}else{$r=(new YouTubeAdapter())->postStatus($job,(string)$job['external_post_id']);$data=$r['json']['items'][0]??[];$provider=(string)($data['processingDetails']['processingStatus']??$data['status']['uploadStatus']??'UNKNOWN');$mapped=$this->mapYouTube($provider);$failReason=(string)($data['processingDetails']['processingFailureReason']??'YouTube processing failed');}
  $this->db->prepare('UPDATE social_publish_jobs SET provider_status=?,provider_checked_at=NOW(),status=?,published_at=CASE WHEN ?=\'Completed\' THEN COALESCE(published_at,NOW()) ELSE published_at END,last_error=CASE WHEN ?=\'Failed\' THEN ? ELSE NULL END,updated_at=NOW() WHERE id=?')->execute([$provider,$mapped,$mapped,$mapped,$failReason,$jobId]);
  if($mapped==='Completed')$this->db->prepare('UPDATE social_publish_jobs SET last_error=NULL WHERE id=?')->execute([$jobId]);
  if($userId>0)$this->audit->log($userId,'social_publish_status_checked','social_publish_jobs',$jobId,$jobId,['provider_status'=>$provider,'status'=>$mapped]);
  return ['job_id'=>$jobId,'provider_status'=>$provider,'status'=>$mapped,'data'=>$data];
 }
 private function mapTikTok(string $status):string{return match($status){'PUBLISH_COMPLETE'=>'Completed','FAILED'=>'Failed','PROCESSING_UPLOAD','PROCESSING_DOWNLOAD','SEND_TO_USER_INBOX'=>'Processing',default=>'Processing'};}
 private function mapYouTube(string $status):string{return match(strtolower($status)){ 'succeeded','processed'=>'Completed','failed','rejected','terminated'=>'Failed', default=>'Processing'};}
}
