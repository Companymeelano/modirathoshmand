<?php
declare(strict_types=1);
final class SocialPublishingOrchestrator {
 public function __construct(private PDO $db, private Audit $audit, private ?SocialCapabilityRegistry $capabilityRegistry=null){}

 public function capabilities():array { return ($this->capabilityRegistry ?? new SocialCapabilityRegistry())->all(); }

 public function approveAndFanOut(int $contentId,array $accountIds,int $userId):array {
  $q=$this->db->prepare("SELECT id,approval_status FROM social_content_workflows WHERE content_id=? LIMIT 1"); $q->execute([$contentId]); $workflow=$q->fetch(PDO::FETCH_ASSOC);
  if(!$workflow) throw new InvalidArgumentException('رکورد workflow محتوا یافت نشد.');
  if(!in_array((string)$workflow['approval_status'],['draft','pending'],true)) throw new DomainException('این محتوا قابل تأیید نیست.');
  $items=$this->fanOut($contentId,$accountIds,$userId);
  $this->db->prepare("UPDATE social_content_workflows SET approval_status='approved',approved_by=?,approved_at=NOW(),updated_at=NOW() WHERE content_id=? AND approval_status IN ('draft','pending')")->execute([$userId,$contentId]);
  $this->audit->log($userId,'social_content_batch_approved','social_content_workflows',(int)$workflow['id'],(int)$workflow['id'],['content_id'=>$contentId,'targets'=>count($items)]);
  return $items;
 }

 public function fanOut(int $contentId,array $accountIds,int $userId):array {
  $accountIds=array_values(array_unique(array_filter(array_map('intval',$accountIds),fn(int $id):bool=>$id>0)));
  if(!$accountIds) throw new InvalidArgumentException('حداقل یک حساب اجتماعی الزامی است.');
  $content=$this->content($contentId);
  if(!$content) throw new InvalidArgumentException('محتوای اجتماعی یافت نشد.');
  $payload=json_decode((string)$content['metadata'],true);
  if(!is_array($payload)) $payload=[];
  $result=[];
  foreach($accountIds as $accountId){
   $result[]=$this->queueTarget($content,$payload,$accountId,$userId);
  }
  return $result;
 }

 public function queueTarget(array $content,array $payload,int $accountId,int $userId):array {
  $q=$this->db->prepare('SELECT * FROM social_accounts WHERE id=? LIMIT 1'); $q->execute([$accountId]); $account=$q->fetch(PDO::FETCH_ASSOC);
  if(!$account) throw new InvalidArgumentException('حساب اجتماعی یافت نشد: '.$accountId);
  if((string)$account['status']!=='active') throw new DomainException('حساب اجتماعی فعال نیست: '.$accountId);
  $platform=strtolower((string)$account['platform']);
  $contentPlatform=strtolower((string)$content['platform']);
  if($platform!==$contentPlatform) throw new DomainException('پلتفرم محتوا با حساب مقصد یکسان نیست.');
  $this->validateCapability($platform,$payload);

  $scheduled=$payload['scheduled_at']??null;
  $scheduled=$scheduled!==null&&trim((string)$scheduled)!==''?(string)$scheduled:date('Y-m-d H:i:s');
  $payload['content_id']=(int)$content['id'];
  $payload['user_id']=$userId;
  $payload['target_account_id']=$accountId;
  $idempotencyKey=PublishRecoveryService::idempotencyKey($accountId,(int)$content['id'],$payload);
  $json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);

  $this->db->beginTransaction();
  try {
   $existing=$this->db->prepare("SELECT id,status,idempotency_key FROM social_publish_jobs WHERE account_id=? AND content_id=? AND status IN ('Queued','Processing','Retrying') ORDER BY id DESC LIMIT 1");
   $existing->execute([$accountId,(int)$content['id']]); $row=$existing->fetch(PDO::FETCH_ASSOC);
   if($row){ $this->db->commit(); return ['job_id'=>(int)$row['id'],'account_id'=>$accountId,'platform'=>$platform,'deduplicated'=>true,'status'=>$row['status']]; }
   $batch=bin2hex(random_bytes(16));
   $ins=$this->db->prepare("INSERT INTO social_publish_jobs(batch_id,account_id,platform,content_id,idempotency_key,status,scheduled_at,attempts,payload,created_at,updated_at) VALUES(?,?,?,?,?, 'Queued',?,0,?,NOW(),NOW())");
   $ins->execute([$batch,$accountId,$platform,(int)$content['id'],$idempotencyKey,$scheduled,$json]);
   $jobId=(int)$this->db->lastInsertId();
   $this->db->prepare('INSERT INTO social_publish_targets(content_id,account_id,job_id,status,created_by,created_at,updated_at) VALUES(?,?,?,\'Queued\',?,NOW(),NOW()) ON DUPLICATE KEY UPDATE job_id=VALUES(job_id),status=VALUES(status),updated_at=NOW()')->execute([(int)$content['id'],$accountId,$jobId,$userId]);
   $this->db->commit();
   $this->audit->log($userId,'social_publish_target_queued','social_publish_targets',$jobId,$jobId,['content_id'=>(int)$content['id'],'account_id'=>$accountId,'platform'=>$platform]);
   return ['job_id'=>$jobId,'account_id'=>$accountId,'platform'=>$platform,'deduplicated'=>false,'status'=>'Queued'];
  } catch(Throwable $e){ if($this->db->inTransaction())$this->db->rollBack(); throw $e; }
 }

 public function syncTargetStates():int {
  $sql="UPDATE social_publish_targets t JOIN social_publish_jobs j ON j.id=t.job_id SET t.status=j.status,t.external_post_id=j.external_post_id,t.last_error=j.last_error,t.updated_at=NOW() WHERE t.status<>j.status OR COALESCE(t.external_post_id,'')<>COALESCE(j.external_post_id,'') OR COALESCE(t.last_error,'')<>COALESCE(j.last_error,'')";
  return $this->db->exec($sql) ?: 0;
 }

 public function content(int $id):?array { $q=$this->db->prepare('SELECT * FROM social_contents WHERE id=? LIMIT 1');$q->execute([$id]);$r=$q->fetch(PDO::FETCH_ASSOC);return $r?:null; }
 public function targets(int $contentId):array { $q=$this->db->prepare('SELECT t.*,a.account_name,a.platform,j.provider_status,j.provider_checked_at FROM social_publish_targets t JOIN social_accounts a ON a.id=t.account_id LEFT JOIN social_publish_jobs j ON j.id=t.job_id WHERE t.content_id=? ORDER BY t.id');$q->execute([$contentId]);return $q->fetchAll(PDO::FETCH_ASSOC); }
 private function validateCapability(string $platform,array $payload):void {
  ($this->capabilityRegistry ?? new SocialCapabilityRegistry())->assertPublishable($platform,(string)($payload['media_type']??'video'),$payload);
 }
}
