<?php
declare(strict_types=1);
final class CacheInvalidationService
{
    public function __construct(private IntelligentCacheService $cache, private PDO $db) {}
    public function product(): int { return $this->flush('active_products','product_write'); }
    public function inventory(): int { return $this->flush('active_products','inventory_write'); }
    public function shipping(): int { return $this->flush('shipping_rules','shipping_write'); }
    public function social(): int { return $this->flush('social_performance_summary','social_performance_write'); }
    public function categories(): int { return $this->flush('category_tree','category_write'); }
    public function dashboard(): int { return $this->record('query.dashboard',$this->cache->flushNamespace('query.dashboard'),'dashboard_write'); }
    public function flush(string $name,string $reason='manual'): int { $name=trim($name); if(!preg_match('/^[a-z0-9_]+$/',$name))throw new InvalidArgumentException('Cache namespace نامعتبر است.'); return $this->record('query.'.$name,$this->cache->flushNamespace('query.'.$name),$reason); }
    private function record(string $namespace,int $generation,string $reason):int{try{if($this->table()){$q=$this->db->prepare('INSERT INTO system_cache_invalidation_events(namespace,reason,created_at) VALUES(?,?,NOW())');$q->execute([$namespace,substr($reason,0,100)]);}}catch(Throwable){}return $generation;}
    private function table():bool{try{$q=$this->db->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='system_cache_invalidation_events'");return (int)$q->fetchColumn()===1;}catch(Throwable){return false;}}
}
