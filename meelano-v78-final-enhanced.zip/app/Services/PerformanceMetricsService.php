<?php
declare(strict_types=1);
final class PerformanceMetricsService
{
    public function __construct(private PDO $db) {}

    public function record(array $metric): ?int
    {
        if (!$this->table('system_performance_metrics')) return null;
        $q=$this->db->prepare('INSERT INTO system_performance_metrics(request_id,action,http_method,http_status,duration_ms,memory_peak_bytes,source,created_at) VALUES(?,?,?,?,?,?,?,NOW())');
        $q->execute([
            (string)($metric['request_id']??''), (string)($metric['action']??''),
            (string)($metric['http_method']??''), (int)($metric['http_status']??200),
            round((float)($metric['duration_ms']??0),3), (int)($metric['memory_peak_bytes']??0),
            (string)($metric['source']??'http')
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function recent(int $limit=100, ?string $action=null): array
    {
        if (!$this->table('system_performance_metrics')) return [];
        $limit=max(1,min(500,$limit));
        if ($action!==null && $action!=='') {
            $q=$this->db->prepare('SELECT id,request_id,action,http_method,http_status,duration_ms,memory_peak_bytes,source,created_at FROM system_performance_metrics WHERE action=? ORDER BY id DESC LIMIT '.$limit);
            $q->execute([$action]);
        } else $q=$this->db->query('SELECT id,request_id,action,http_method,http_status,duration_ms,memory_peak_bytes,source,created_at FROM system_performance_metrics ORDER BY id DESC LIMIT '.$limit);
        return $q->fetchAll(PDO::FETCH_ASSOC)?:[];
    }

    public function report(int $minutes=60): array
    {
        if (!$this->table('system_performance_metrics')) return ['status'=>'unavailable','sample_count'=>0];
        $minutes=max(1,min(10080,$minutes));
        $q=$this->db->prepare('SELECT duration_ms,http_status,action FROM system_performance_metrics WHERE created_at>=DATE_SUB(NOW(),INTERVAL ? MINUTE) ORDER BY duration_ms ASC');
        $q->execute([$minutes]); $rows=$q->fetchAll(PDO::FETCH_ASSOC)?:[];
        $n=count($rows); if(!$n) return ['status'=>'insufficient_data','minutes'=>$minutes,'sample_count'=>0,'p50_ms'=>null,'p95_ms'=>null,'p99_ms'=>null,'max_ms'=>null,'error_rate'=>0,'slowest_actions'=>[]];
        $dur=array_map(static fn($r)=>(float)$r['duration_ms'],$rows); sort($dur,SORT_NUMERIC);
        $pct=static function(array $a,float $p):float{$i=max(0,min(count($a)-1,(int)ceil($p*count($a))-1));return round((float)$a[$i],3);};
        $errors=0;$by=[];
        foreach($rows as $r){if((int)$r['http_status']>=500)$errors++;$a=(string)$r['action'];if(!isset($by[$a]))$by[$a]=['action'=>$a,'count'=>0,'total'=>0,'max'=>0];$by[$a]['count']++;$by[$a]['total']+=(float)$r['duration_ms'];$by[$a]['max']=max($by[$a]['max'],(float)$r['duration_ms']);}
        foreach($by as &$v){$v['avg_ms']=round($v['total']/max(1,$v['count']),3);unset($v['total']);} unset($v);
        usort($by,static fn($a,$b)=>$b['avg_ms']<=>$a['avg_ms']);
        return ['status'=>'ok','minutes'=>$minutes,'sample_count'=>$n,'p50_ms'=>$pct($dur,.50),'p95_ms'=>$pct($dur,.95),'p99_ms'=>$pct($dur,.99),'max_ms'=>round(max($dur),3),'error_rate'=>round($errors/$n*100,2),'slowest_actions'=>array_slice($by,0,10)];
    }

    public function queueThroughput(): array
    {
        $out=['available'=>false];
        if(!$this->table('social_publish_jobs')) return $out;
        $out['available']=true;
        $sql="SELECT
            SUM(status IN ('Queued','Retrying')) pending,
            SUM(status='Processing') processing,
            SUM(status IN ('Failed','DeadLetter','deadletter')) failed,
            SUM(status='Completed') completed,
            SUM(created_at>=DATE_SUB(NOW(),INTERVAL 1 HOUR)) created_last_hour,
            SUM(updated_at>=DATE_SUB(NOW(),INTERVAL 1 HOUR) AND status='Completed') completed_last_hour
            FROM social_publish_jobs";
        $r=$this->db->query($sql)->fetch(PDO::FETCH_ASSOC)?:[];
        foreach($r as $k=>$v)$r[$k]=(int)$v;
        $out+= $r;
        $out['completion_rate_per_hour']=$r['completed_last_hour'];
        return $out;
    }

    public function indexAdvisor(): array
    {
        $tables=['orders'=>[['user_id'],['order_status'],['created_at'],['payment_status']], 'order_items'=>[['order_id'],['product_id'],['variant_id']], 'product_inventory'=>[['product_id','warehouse_id'],['variant_id','warehouse_id']], 'social_publish_jobs'=>[['status','scheduled_at'],['status','claim_expires_at'],['account_id','status']], 'social_ai_video_director_jobs'=>[['status'],['platform','status']], 'system_incidents'=>[['status','last_seen_at'],['fingerprint']], 'admin_notifications'=>[['read_at','created_at']]];
        $advice=[];
        foreach($tables as $table=>$wanted){ if(!$this->table($table)) continue; $existing=$this->indexes($table); foreach($wanted as $cols){$key=implode('|',$cols);$covered=false;foreach($existing as $idx){$prefix=array_slice($idx['columns'],0,count($cols));if($prefix===$cols){$covered=true;break;}} if(!$covered)$advice[]=['table'=>$table,'columns'=>$cols,'recommendation'=>'Consider composite/covering index after EXPLAIN and production workload validation.'];}}
        return ['generated_at'=>gmdate('c'),'status'=>'ok','recommendations'=>$advice,'count'=>count($advice)];
    }

    private function indexes(string $table):array
    {
        $q=$this->db->prepare('SELECT INDEX_NAME,COLUMN_NAME,SEQ_IN_INDEX FROM information_schema.statistics WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? ORDER BY INDEX_NAME,SEQ_IN_INDEX');$q->execute([$table]);$out=[];foreach($q as $r){$n=(string)$r['INDEX_NAME'];$out[$n]['name']=$n;$out[$n]['columns'][]=(string)$r['COLUMN_NAME'];}return array_values($out);
    }
    private function table(string $name):bool { try{$q=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$name]);return (int)$q->fetchColumn()===1;}catch(Throwable){return false;} }
}
