<?php
declare(strict_types=1);
final class VideoQualityGateService {
 public function inspect(string $path,string $platform,array $directive=[]):array {
  if(!is_file($path)) return $this->fail('FILE_MISSING','فایل ویدئو وجود ندارد.');
  $ffprobe=trim((string)Env::get('MEELANO_FFPROBE_PATH',''));
  if($ffprobe===''||!is_executable($ffprobe)) $ffprobe=trim((string)@shell_exec('command -v ffprobe 2>/dev/null'));
  if($ffprobe==='') return ['status'=>'needs_manual_review','score'=>0,'checks'=>[],'technical'=>[],'error_code'=>'FFPROBE_UNAVAILABLE','error'=>'FFprobe در سرور در دسترس نیست؛ این ویدیو نیاز به بررسی دستی کیفیت دارد.','timestamp'=>date('c')];
  $cmd=escapeshellarg($ffprobe).' -v error -print_format json -show_streams -show_format '.escapeshellarg($path).' 2>&1';
  $raw=shell_exec($cmd); $meta=json_decode((string)$raw,true);
  if(!is_array($meta)) return $this->fail('PROBE_INVALID','اطلاعات فنی ویدئو قابل خواندن نیست.');
  $video=null;$audio=null;foreach(($meta['streams']??[]) as $s){if(($s['codec_type']??'')==='video'&&!$video)$video=$s;if(($s['codec_type']??'')==='audio'&&!$audio)$audio=$s;}
  if(!$video) return $this->fail('VIDEO_STREAM_MISSING','Video stream یافت نشد.');
  $w=(int)($video['width']??0);$h=(int)($video['height']??0);$duration=(float)($meta['format']['duration']??$video['duration']??0);$fps=$this->fps((string)($video['avg_frame_rate']??$video['r_frame_rate']??'0/1'));$codec=(string)($video['codec_name']??'');$container=(string)($meta['format']['format_name']??'');
  $expected=$this->expected($platform);$targetDuration=(float)($directive['duration']??8);$ratio=$h>0?$w/$h:0;$expectedRatio=$expected['ratio'];
  $checks=[
   'container_mp4'=>str_contains($container,'mp4'),
   'video_codec'=>in_array($codec,['h264','hevc','av1','vp9'],true),
   'resolution_min'=>min($w,$h)>=720,
   'aspect_ratio'=>abs($ratio-$expectedRatio)<=0.035,
   'duration'=> $duration>=2 && $duration<=15 && abs($duration-$targetDuration)<=4,
   'frame_rate'=> $fps>=23 && $fps<=61,
  ];
  $score=(int)round(100*count(array_filter($checks))/count($checks));
  $status=$score>=100?'pass':($score>=83?'warn':'fail');
  return ['status'=>$status,'score'=>$score,'checks'=>$checks,'technical'=>['width'=>$w,'height'=>$h,'duration'=>round($duration,3),'fps'=>round($fps,3),'codec'=>$codec,'container'=>$container,'has_audio'=>(bool)$audio],'platform'=>$platform,'expected'=>$expected,'target_duration'=>$targetDuration,'timestamp'=>date('c')];
 }
 private function expected(string $p):array{return match($p){'youtube'=>['ratio'=>16/9,'orientation'=>'landscape','min_width'=>720,'min_height'=>720],'linkedin'=>['ratio'=>1.0,'orientation'=>'square','min_width'=>720,'min_height'=>720],default=>['ratio'=>9/16,'orientation'=>'portrait','min_width'=>720,'min_height'=>720]};}
 private function fps(string $v):float{if(str_contains($v,'/')){$a=explode('/',$v,2);$n=(float)($a[0]??0);$d=(float)($a[1]??1);return $d?($n/$d):0;}return (float)$v;}
 private function fail(string $code,string $message):array{return ['status'=>'fail','score'=>0,'checks'=>[],'technical'=>[],'error_code'=>$code,'error'=>$message,'timestamp'=>date('c')];}
}
