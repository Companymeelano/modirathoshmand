<?php
declare(strict_types=1);
final class SocialCommandService {
 public function __construct(private PDO $db,private Audit $audit,private ?PublishRecoveryService $recovery=null){}
 public function accounts():array{$q=$this->db->query("SELECT id,platform,account_name,external_account_id,status,scopes,token_expires_at,metadata,created_at,updated_at FROM social_accounts ORDER BY platform,account_name");return $q->fetchAll(PDO::FETCH_ASSOC);}
 public function saveAccount(array $data,int $userId):int{$platform=strtolower(trim((string)($data['platform']??'')));$name=trim((string)($data['account_name']??''));$token=(string)($data['access_token']??'');$refresh=(string)($data['refresh_token']??'');if($platform===''||$name==='')throw new InvalidArgumentException('platform و account_name الزامی است.');$id=(int)($data['id']??0);$scopes=is_array($data['scopes']??null)?json_encode(array_values($data['scopes']),JSON_UNESCAPED_UNICODE):((string)($data['scopes']??'[]'));$meta=is_array($data['metadata']??null)?json_encode($data['metadata'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):((string)($data['metadata']??'{}'));$enc=$token!==''?SocialTokenCipher::encrypt($token):null;$renc=$refresh!==''?SocialTokenCipher::encrypt($refresh):null;if($id>0){$sets='platform=?,account_name=?,external_account_id=?,status=?,scopes=?,metadata=?';$args=[$platform,$name,(string)($data['external_account_id']??''),(string)($data['status']??'active'),$scopes,$meta];if($enc!==null){$sets.=',access_token_enc=?';$args[]=$enc;}if($renc!==null){$sets.=',refresh_token_enc=?';$args[]=$renc;}$sets.=',token_expires_at=?,updated_at=NOW()';$args[]=$data['token_expires_at']??null;$args[]=$id;$this->db->prepare('UPDATE social_accounts SET '.$sets.' WHERE id=?')->execute($args);}else{$this->db->prepare('INSERT INTO social_accounts(platform,account_name,external_account_id,status,scopes,access_token_enc,refresh_token_enc,token_expires_at,metadata,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,NOW(),NOW())')->execute([$platform,$name,(string)($data['external_account_id']??''),(string)($data['status']??'active'),$scopes,$enc,$renc,$data['token_expires_at']??null,$meta]);$id=(int)$this->db->lastInsertId();}$this->audit->log($userId,'social_account_saved','social_accounts',$id,$id,['platform'=>$platform]);return $id;}
 public function enqueue(int $accountId,array $content,int $userId,?string $scheduledAt=null):int{$q=$this->db->prepare('SELECT id,platform,status FROM social_accounts WHERE id=? LIMIT 1');$q->execute([$accountId]);$a=$q->fetch(PDO::FETCH_ASSOC);if(!$a)throw new InvalidArgumentException('حساب شبکه اجتماعی یافت نشد.');if($a['status']!=='active')throw new DomainException('حساب شبکه اجتماعی فعال نیست.');$platform=$a['platform'];$this->validateContent($platform,$content);$cid=$this->createContent($platform,$content,$userId);$batch=bin2hex(random_bytes(16));$when=$scheduledAt?:date('Y-m-d H:i:s');$payload=json_encode($content,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);$key=PublishRecoveryService::idempotencyKey($accountId,$cid,$content);$this->db->prepare('INSERT INTO social_publish_jobs(batch_id,account_id,platform,content_id,idempotency_key,status,scheduled_at,attempts,payload,created_at,updated_at) VALUES(?,?,?,?,?,\'Queued\',?,0,?,NOW(),NOW())')->execute([$batch,$accountId,$platform,$cid,$key,$when,$payload]);$id=(int)$this->db->lastInsertId();$this->audit->log($userId,'social_job_enqueued','social_publish_jobs',$id,$id,['platform'=>$platform,'account_id'=>$accountId]);return $id;}
 private function createContent(string $platform,array $content,int $userId):int{$this->db->prepare('INSERT INTO social_contents(platform,caption,media_type,media_url,media_urls,metadata,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,NOW(),NOW())')->execute([$platform,(string)($content['caption']??''),(string)($content['media_type']??''),(string)($content['media_url']??''),json_encode($content['media_urls']??[],JSON_UNESCAPED_SLASHES),json_encode($content,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$userId]);return (int)$this->db->lastInsertId();}
 private function validateContent(string $platform,array $content):void{if($platform==='tiktok'){(new TikTokAdapter())->validate(['access_token_enc'=>'configured'],$content);}elseif($platform==='linkedin'){(new LinkedInAdapter())->validate(['access_token_enc'=>'configured'],$content);}else{if(empty($content['caption'])&&empty($content['media_url']))throw new InvalidArgumentException('محتوای انتشار خالی است.');}}
 public function processDue(int $limit=10):array{
  $recovery=$this->recovery;
  if($recovery===null)$recovery=new PublishRecoveryService($this->db,$this->audit);
  $limit=max(1,min(50,$limit));
  $q=$this->db->query("SELECT j.*,a.id AS account_id,a.access_token_enc,a.account_name,a.external_account_id,a.scopes,a.metadata FROM social_publish_jobs j JOIN social_accounts a ON a.id=j.account_id WHERE j.status IN ('Queued','Retrying') AND j.scheduled_at<=NOW() AND a.status='active' ORDER BY j.scheduled_at,j.id LIMIT {$limit}");
  $jobs=$q->fetchAll(PDO::FETCH_ASSOC);$out=[];
  foreach($jobs as $candidate){
   $id=(int)$candidate['id'];$payload=json_decode((string)$candidate['payload'],true)?:[];
   $key=(string)($candidate['idempotency_key']??'');
   if($key===''){$key=$recovery->ensureKey($id,$payload);$candidate['idempotency_key']=$key;}
   $from=(string)$candidate['status'];$job=$recovery->claim($id,$from,10);if(!$job)continue;
   $job['idempotency_key']=$key;$attempt=(int)$job['attempts'];$recovery->startAttempt($job);
   try{
    $content=$payload;$content['user_id']=(int)($content['user_id']??0);$content['job_id']=$id;$content['idempotency_key']=$key;
    $result=SocialAdapterFactory::make((string)$job['platform'])->publish($job,$content);
    $external=(string)($result['external_post_id']??'');$provider=(string)($result['provider_status']??'INITIATED');
    $this->db->prepare("UPDATE social_publish_jobs SET status='Processing',external_post_id=?,provider_status=?,provider_checked_at=NULL,last_error=NULL,claim_token=NULL,claim_expires_at=NULL,updated_at=NOW() WHERE id=? AND status='Processing' AND claim_token=?")->execute([$external,$provider,$id,(string)$job['claim_token']]);
    $recovery->finishAttempt($id,$attempt,'accepted',$result,null);
    $out[]=['id'=>$id,'status'=>'Processing','result'=>$result];
   }catch(Throwable $e){
    $recovery->finishAttempt($id,$attempt,'failed',null,$e);
    $retry=($e instanceof SocialException&&$e->retryable&&(int)$job['attempts']<3);
    $status=$retry?'Retrying':'Failed';
    $this->db->prepare("UPDATE social_publish_jobs SET status=?,scheduled_at=CASE WHEN ?='Retrying' THEN DATE_ADD(NOW(),INTERVAL POW(2,attempts) MINUTE) ELSE scheduled_at END,last_error=?,claim_token=NULL,claim_expires_at=NULL,updated_at=NOW() WHERE id=? AND status='Processing' AND claim_token=?")->execute([$status,$status,mb_substr($e->getMessage(),0,500),$id,(string)$job['claim_token']]);
    $out[]=['id'=>$id,'status'=>$status,'error'=>$e->getMessage()];
   }
  }
  return $out;
 }
}
