<?php
declare(strict_types=1);
final class PublishRecoveryService {
 public function __construct(private PDO $db, private Audit $audit, private ?AdminNotificationService $notifications=null){}

 public static function idempotencyKey(int $accountId,int $contentId,array $payload):string {
  $normalized=self::normalize($payload);
  $hash=hash('sha256',json_encode($normalized,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));
  return 'spj_'.$accountId.'_'.$contentId.'_'.substr($hash,0,64);
 }
 private static function normalize(array $value):array {
  ksort($value);
  foreach($value as $k=>$v){
   if(is_array($v))$value[$k]=self::normalize($v);
   elseif(is_string($v))$value[$k]=trim($v);
  }
  return $value;
 }
 public static function staleDecision(string $status,bool $hasExternalId,bool $leaseExpired):string {
  if($status!=='Processing'||!$leaseExpired)return 'ignore';
  return $hasExternalId?'reconcile':'manual_review';
 }
 public function ensureKey(int $jobId,array $payload):string {
  $q=$this->db->prepare('SELECT account_id,content_id,idempotency_key FROM social_publish_jobs WHERE id=? LIMIT 1');$q->execute([$jobId]);$j=$q->fetch(PDO::FETCH_ASSOC);
  if(!$j)throw new InvalidArgumentException('Job یافت نشد.');
  $existing=trim((string)($j['idempotency_key']??''));if($existing!=='')return $existing;
  $key=self::idempotencyKey((int)$j['account_id'],(int)($j['content_id']??0),$payload);
  $this->db->prepare('UPDATE social_publish_jobs SET idempotency_key=? WHERE id=? AND (idempotency_key IS NULL OR idempotency_key=\'\')')->execute([$key,$jobId]);
  return $key;
 }
 public function claim(int $jobId,string $fromStatus='Queued',int $leaseMinutes=10):?array {
  $token=bin2hex(random_bytes(16));$lease=max(2,min(60,$leaseMinutes));
  $sql="UPDATE social_publish_jobs SET status='Processing',claim_token=?,claim_expires_at=DATE_ADD(NOW(),INTERVAL {$lease} MINUTE),last_attempt_at=NOW(),attempts=attempts+1,updated_at=NOW() WHERE id=? AND status=? AND (claim_expires_at IS NULL OR claim_expires_at<NOW())";
  $st=$this->db->prepare($sql);$st->execute([$token,$jobId,$fromStatus]);
  if($st->rowCount()!==1)return null;
  $q=$this->db->prepare('SELECT * FROM social_publish_jobs WHERE id=? LIMIT 1');$q->execute([$jobId]);return $q->fetch(PDO::FETCH_ASSOC)?:null;
 }
 public function reclaimStale(int $limit=25,int $userId=0):array {
  $limit=max(1,min(100,$limit));
  $q=$this->db->query("SELECT j.id,j.account_id,j.platform,j.content_id,j.status,j.external_post_id,j.claim_expires_at,j.recovery_count,j.attempts,a.account_name FROM social_publish_jobs j JOIN social_accounts a ON a.id=j.account_id WHERE j.status='Processing' AND j.claim_expires_at IS NOT NULL AND j.claim_expires_at<NOW() ORDER BY j.claim_expires_at,j.id LIMIT {$limit}");
  $out=[];
  foreach($q->fetchAll(PDO::FETCH_ASSOC) as $j){
   $id=(int)$j['id'];$decision=self::staleDecision('Processing',trim((string)$j['external_post_id'])!=='',true);
   if($decision==='reconcile'){
    $this->db->prepare("UPDATE social_publish_jobs SET claim_token=NULL,claim_expires_at=NULL,provider_checked_at=NULL,recovery_count=recovery_count+1,updated_at=NOW() WHERE id=? AND status='Processing' AND claim_expires_at<NOW()")->execute([$id]);
    $this->event($id,'stale_released','Processing','Processing','lease_expired_with_external_id',null,$userId);
    $out[]=['job_id'=>$id,'action'=>'reconcile','status'=>'Processing'];
    continue;
   }
   $this->db->prepare("UPDATE social_publish_jobs SET status='RecoveryRequired',claim_token=NULL,claim_expires_at=NULL,recovery_count=recovery_count+1,last_error=?,updated_at=NOW() WHERE id=? AND status='Processing' AND claim_expires_at<NOW()")->execute(['انتشار قبلی ممکن است توسط سرویس مقصد پذیرفته شده باشد؛ برای جلوگیری از انتشار تکراری نیاز به بررسی دستی است.',$id]);
   $this->event($id,'manual_review_required','Processing','RecoveryRequired','lease_expired_without_external_id',null,$userId);
   if($this->notifications){try{$this->notifications->create('publish_recovery_required','بازیابی انتشار نیازمند بررسی دستی است',['job_id'=>$id,'platform'=>$j['platform'],'account_name'=>$j['account_name']]);}catch(Throwable $e){error_log('[MeeLano] recovery notification failed: '.$e->getMessage());}}
   $out[]=['job_id'=>$id,'action'=>'manual_review','status'=>'RecoveryRequired'];
  }
  return $out;
 }
 public function attempts(int $jobId,int $limit=50):array {
  $limit=max(1,min(100,$limit));$q=$this->db->prepare("SELECT * FROM social_publish_attempts WHERE job_id=? ORDER BY attempt_no DESC LIMIT {$limit}");$q->execute([$jobId]);return $q->fetchAll(PDO::FETCH_ASSOC);
 }
 public function startAttempt(array $job):int {
  $attempt=(int)$job['attempts'];$this->db->prepare('INSERT INTO social_publish_attempts(job_id,attempt_no,status,idempotency_key,started_at,created_at) VALUES(?,?,?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE status=VALUES(status),idempotency_key=VALUES(idempotency_key),started_at=VALUES(started_at)')->execute([(int)$job['id'],$attempt,'started',(string)($job['idempotency_key']??'')]);return $attempt;
 }
 public function finishAttempt(int $jobId,int $attempt,string $status,?array $result=null,?Throwable $error=null):void {
  $external=$result?trim((string)($result['external_post_id']??'')):'';$provider=$result?(string)($result['provider_status']??''):'';$code=$error instanceof SocialException?(string)$error->httpStatus:'';$msg=$error?mb_substr($error->getMessage(),0,500):null;
  $json=$result===null?null:json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  $this->db->prepare('UPDATE social_publish_attempts SET status=?,finished_at=NOW(),provider_status=?,external_post_id=?,error_code=?,error_message=?,response_json=? WHERE job_id=? AND attempt_no=?')->execute([$status,$provider!==''?$provider:null,$external!==''?$external:null,$code!==''?$code:null,$msg,$json,(int)$jobId,$attempt]);
 }
 public function recoverJob(int $jobId,int $userId=0):array {
  $q=$this->db->prepare('SELECT * FROM social_publish_jobs WHERE id=? LIMIT 1');$q->execute([$jobId]);$j=$q->fetch(PDO::FETCH_ASSOC);if(!$j)throw new InvalidArgumentException('Job یافت نشد.');
  $status=(string)$j['status'];if($status!=='RecoveryRequired')throw new DomainException('این Job در وضعیت RecoveryRequired نیست.');
  if((int)$j['recovery_count']>=5){throw new DomainException('سقف بازیابی این Job پر شده است.');}
  $this->db->prepare("UPDATE social_publish_jobs SET status='Retrying',scheduled_at=NOW(),claim_token=NULL,claim_expires_at=NULL,last_error=NULL,recovery_count=recovery_count+1,updated_at=NOW() WHERE id=? AND status='RecoveryRequired'")->execute([$jobId]);
  $this->event($jobId,'manual_requeue','RecoveryRequired','Retrying','operator_requested_requeue',null,$userId);
  if($userId>0)$this->audit->log($userId,'social_publish_recovery_requeued','social_publish_jobs',$jobId,$jobId,['recovery_count'=>(int)$j['recovery_count']+1]);
  return ['job_id'=>$jobId,'status'=>'Retrying'];
 }
 public function processRecovery(int $limit=25,int $userId=0):array { return $this->reclaimStale($limit,$userId); }
 private function event(int $jobId,string $type,string $from,?string $to,?string $reason,?array $meta, int $userId):void {
  try{$this->db->prepare('INSERT INTO social_publish_recovery_events(job_id,event_type,from_status,to_status,reason,metadata_json,created_by,created_at) VALUES(?,?,?,?,?,?,?,NOW())')->execute([$jobId,$type,$from,$to,$reason,$meta===null?null:json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$userId>0?$userId:null]);}catch(Throwable $e){error_log('[MeeLano] recovery event failed: '.$e->getMessage());}
 }
}
