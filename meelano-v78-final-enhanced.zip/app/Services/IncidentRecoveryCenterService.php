<?php
declare(strict_types=1);
final class IncidentRecoveryCenterService
{
    public function __construct(private PDO $db, private ?AdminNotificationService $notifications = null) {}

    public function overview(int $limit = 50): array
    {
        $limit=max(1,min(100,$limit));
        $incidents=$this->table('system_incidents') ? $this->rows('SELECT id,fingerprint,severity,status,component,title,message,occurrences,first_seen_at,last_seen_at,resolved_at,created_at FROM system_incidents ORDER BY last_seen_at DESC LIMIT '.$limit) : [];
        return ['generated_at'=>gmdate('c'),'summary'=>$this->summary(),'incidents'=>$incidents,'timeline'=>$this->timeline($limit)];
    }

    public function reconcile(): array
    {
        $observability=(new ProductionObservabilityService($this->db))->snapshot();
        $recovery=(new DisasterRecoveryService($this->db))->audit();
        $issues=[];
        foreach (($observability['checks']??[]) as $component=>$check) if(($check['status']??'pass')==='fail') $issues[]=['severity'=>'critical','component'=>$component,'title'=>'Runtime check failed','message'=>$component.' is unavailable or failed its health check'];
        if((int)($observability['queue']['stale_processing']??0)>0) $issues[]=['severity'=>'warning','component'=>'publish_queue','title'=>'Stale publishing jobs detected','message'=>'There are '.$observability['queue']['stale_processing'].' stale Processing jobs'];
        foreach (($recovery['checks']??[]) as $component=>$check) if(($check['status']??'pass')==='fail') $issues[]=['severity'=>'critical','component'=>'recovery.'.$component,'title'=>'Recovery readiness check failed','message'=>'Recovery check '.$component.' failed'];
        $upserted=[]; foreach($issues as $issue) $upserted[]=$this->upsert($issue);
        if(!$issues && $this->table('system_incidents')) $this->resolveRecovered();
        return ['status'=>$issues?'degraded':'healthy','issues'=>$upserted,'count'=>count($issues),'observability'=>$observability,'recovery'=>$recovery];
    }

    public function acknowledge(int $id, int $userId): array
    {
        if($id<1) throw new InvalidArgumentException('incident_id نامعتبر است.');
        $q=$this->db->prepare("UPDATE system_incidents SET status='acknowledged',acknowledged_by=?,acknowledged_at=NOW() WHERE id=? AND status='open'");$q->execute([$userId?:null,$id]);
        if($q->rowCount()!==1) throw new DomainException('Incident قابل acknowledge نیست یا قبلاً تغییر کرده است.');
        return ['id'=>$id,'status'=>'acknowledged'];
    }

    public function resolve(int $id, int $userId): array
    {
        if($id<1) throw new InvalidArgumentException('incident_id نامعتبر است.');
        $q=$this->db->prepare("UPDATE system_incidents SET status='resolved',resolved_by=?,resolved_at=NOW() WHERE id=? AND status IN ('open','acknowledged')");$q->execute([$userId?:null,$id]);
        if($q->rowCount()!==1) throw new DomainException('Incident قابل resolve نیست یا قبلاً بسته شده است.');
        return ['id'=>$id,'status'=>'resolved'];
    }

    public function timeline(int $limit=50): array
    {
        $limit=max(1,min(100,$limit));$events=[];
        if($this->table('system_incident_events')) foreach($this->rows('SELECT id,severity,component,event_type,message,metadata_json,created_at FROM system_incident_events ORDER BY id DESC LIMIT '.$limit) as $r)$events[]=['source'=>'incident_event','id'=>(int)$r['id'],'severity'=>$r['severity'],'component'=>$r['component'],'type'=>$r['event_type'],'message'=>$r['message'],'created_at'=>$r['created_at']];
        if($this->table('admin_notifications')) foreach($this->rows('SELECT id,severity,title,message,entity_type,entity_id,created_at FROM admin_notifications ORDER BY id DESC LIMIT '.$limit) as $r)$events[]=['source'=>'notification','id'=>(int)$r['id'],'severity'=>$r['severity'],'component'=>$r['entity_type']?:'system','type'=>'notification','message'=>$r['title'].': '.$r['message'],'entity_id'=>$r['entity_id']? (int)$r['entity_id']:null,'created_at'=>$r['created_at']];
        if($this->table('social_publish_recovery_events')) foreach($this->rows('SELECT id,event_type,job_id,metadata_json,created_at FROM social_publish_recovery_events ORDER BY id DESC LIMIT '.$limit) as $r)$events[]=['source'=>'publish_recovery','id'=>(int)$r['id'],'severity'=>'warning','component'=>'social_publish','type'=>$r['event_type'],'message'=>'Publish recovery event for job #'.$r['job_id'],'entity_id'=>(int)$r['job_id'],'created_at'=>$r['created_at']];
        usort($events,fn($a,$b)=>strcmp((string)$b['created_at'],(string)$a['created_at'])); return array_slice($events,0,$limit);
    }

    private function upsert(array $issue): array
    {
        $fingerprint=hash('sha256',(string)$issue['severity'].'|'.(string)$issue['component'].'|'.(string)$issue['title'].'|'.(string)$issue['message']);
        $q=$this->db->prepare('SELECT id,occurrences,status FROM system_incidents WHERE fingerprint=? LIMIT 1');$q->execute([$fingerprint]);$old=$q->fetch(PDO::FETCH_ASSOC);
        if($old){$status=in_array($old['status'],['resolved'],true)?'open':$old['status'];$this->db->prepare('UPDATE system_incidents SET status=?,severity=?,message=?,occurrences=occurrences+1,last_seen_at=NOW(),resolved_at=IF(?="open",NULL,resolved_at) WHERE id=?')->execute([$status,$issue['severity'],$issue['message'],$status,(int)$old['id']]);$id=(int)$old['id'];}
        else {$this->db->prepare('INSERT INTO system_incidents(fingerprint,severity,status,component,title,message,occurrences,first_seen_at,last_seen_at,created_at) VALUES(?,?,?,?,?,?,1,NOW(),NOW(),NOW())')->execute([$fingerprint,$issue['severity'],'open',$issue['component'],$issue['title'],$issue['message']]);$id=(int)$this->db->lastInsertId();}
        try{$this->db->prepare('INSERT INTO system_incident_events(severity,component,event_type,message,metadata_json,created_at) VALUES(?,?,?,?,?,NOW())')->execute([$issue['severity'],$issue['component'],'incident_detected',$issue['message'],json_encode(['incident_id'=>$id,'fingerprint'=>$fingerprint],JSON_UNESCAPED_UNICODE)]);}catch(Throwable){}
        if($this->notifications && $issue['severity']==='critical') $this->notifications->notify('system_incident_critical','Critical MeeLano incident',$issue['message'],'system_incidents',$id,'critical',['component'=>$issue['component']]);
        return ['id'=>$id,'fingerprint'=>$fingerprint,'severity'=>$issue['severity'],'component'=>$issue['component'],'status'=>'open'];
    }

    private function resolveRecovered(): void { $this->db->exec("UPDATE system_incidents SET status='resolved',resolved_at=NOW() WHERE status IN ('open','acknowledged') AND last_seen_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE)"); }
    private function summary(): array { $out=['open'=>0,'acknowledged'=>0,'resolved'=>0,'critical'=>0]; if(!$this->table('system_incidents')) return $out; foreach($this->rows('SELECT status,severity,COUNT(*) c FROM system_incidents GROUP BY status,severity') as $r){$s=(string)$r['status'];$v=(int)$r['c'];if(isset($out[$s]))$out[$s]+=$v;if($r['severity']==='critical')$out['critical']+=$v;}return $out; }
    private function rows(string $sql):array { try{return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC)?:[];}catch(Throwable){return [];} }
    private function table(string $name):bool { try{$q=$this->db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$name]);return (int)$q->fetchColumn()===1;}catch(Throwable){return false;} }
}
