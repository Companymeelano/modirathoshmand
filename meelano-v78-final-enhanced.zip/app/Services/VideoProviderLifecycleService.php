<?php
declare(strict_types=1);
final class VideoProviderLifecycleService {
 public static function isSoraModel(string $model):bool{return str_starts_with(strtolower(trim($model)),'sora-');}
 public static function soraApiAllowed(?DateTimeImmutable $now=null):bool{
  $date=(string)Env::get('MEELANO_SORA_API_SHUTDOWN_DATE','2026-09-24');
  try{$shutdown=new DateTimeImmutable($date.' 00:00:00',new DateTimeZone('UTC'));}catch(Throwable){return false;}
  $now=$now?:new DateTimeImmutable('now',new DateTimeZone('UTC'));
  return $now < $shutdown;
 }
 public static function assertAllowed(string $provider,string $model):void{
  if(strtolower($provider)==='openai' && self::isSoraModel($model) && !self::soraApiAllowed())
   throw new RuntimeException('OPENAI_SORA_API_RETIRED: Sora API is no longer available. Configure Gemini/Veo or another supported video provider.');
 }
 public static function providerStatus(array $p):array{
  $code=strtolower((string)($p['provider_code']??''));$model=(string)($p['model_code']??'');
  $retired=$code==='openai'&&self::isSoraModel($model)&&!self::soraApiAllowed();
  return ['provider'=>$code,'model'=>$model,'available'=>!$retired,'reason'=>$retired?'SORA_API_RETIRED':null,'shutdown_date'=>(string)Env::get('MEELANO_SORA_API_SHUTDOWN_DATE','2026-09-24')];
 }
}
