<?php
declare(strict_types=1);
final class InstagramAnalyticsService {
 public function __construct(private PDO $db, private Audit $audit){}
 private function account(int $id):array{
  $q=$this->db->prepare("SELECT * FROM social_accounts WHERE id=? AND platform='instagram' AND status='active' LIMIT 1");
  $q->execute([$id]);$a=$q->fetch(PDO::FETCH_ASSOC);
  if(!$a) throw new InvalidArgumentException('حساب Instagram فعال یافت نشد.');
  return $a;
 }
 private function request(string $method,string $url,array $params):array{
  $ch=curl_init($url);$headers=['Accept: application/json'];
  if($method==='GET'){$url.=(str_contains($url,'?')?'&':'?').http_build_query($params);curl_setopt($ch,CURLOPT_URL,$url);}
  else {curl_setopt($ch,CURLOPT_POST,true);curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($params));$headers[]='Content-Type: application/x-www-form-urlencoded';}
  curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>45,CURLOPT_CONNECTTIMEOUT=>12,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
  $raw=curl_exec($ch);if($raw===false){$e=curl_error($ch);curl_close($ch);throw new SocialException('Instagram analytics HTTP error: '.$e,0,true);}
  $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$json=json_decode((string)$raw,true);if(!is_array($json))$json=[];
  if($status<200||$status>=300){$msg=(string)($json['error']['message']??'Instagram analytics request failed');throw new SocialException($msg,$status,$status>=500||$status===429);}
  return $json;
 }
 private function token(array $a):string{$t=SocialTokenCipher::decrypt($a['access_token_enc']??null);if($t==='')throw new DomainException('توکن Instagram قابل استفاده نیست.');return $t;}
 private function base():string{return 'https://graph.instagram.com/'.trim((string)Env::get('META_GRAPH_VERSION','v25.0'));}
 private function metricData(array $response):array{
  $out=[];foreach(($response['data']??[]) as $item){$name=(string)($item['name']??'');if($name==='')continue;$vals=$item['values']??[];$value=end($vals);if(is_array($value)&&array_key_exists('value',$value))$value=$value['value'];$out[$name]=is_numeric($value)?(float)$value:$value;}return $out;
 }
 public function sync(int $accountId,int $userId=0):array{
  $a=$this->account($accountId);$token=$this->token($a);$ig=(string)$a['external_account_id'];if($ig==='')throw new DomainException('Instagram Professional Account ID تنظیم نشده است.');
  $base=$this->base();$captured=date('Y-m-d H:i:s');
  $accountMetrics=[];$accountRaw=null;$errors=[];
  // Meta changes/availability differ by account/API access; request a broad set and persist only returned metrics.
  $requested='views,reach,accounts_engaged,total_interactions,likes,comments,shares,saves,follows_and_unfollows,profile_links_taps,website_clicks';
  try{$accountRaw=$this->request('GET',$base.'/'.$ig.'/insights',['metric'=>$requested,'period'=>'day','access_token'=>$token]);$accountMetrics=$this->metricData($accountRaw);}catch(Throwable $e){$errors[]='account_insights:'.$e->getMessage();}
  $this->db->prepare('INSERT INTO social_instagram_insights(account_id,captured_at,period,metrics,raw_response) VALUES(?,?,?,?,?)')->execute([$accountId,$captured,'day',json_encode($accountMetrics,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$accountRaw?json_encode($accountRaw,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null]);
  $mediaCount=0;$mediaErrors=0;$mediaRaw=[];$mediaMetrics=[];
  try{
   $page=$this->request('GET',$base.'/'.$ig.'/media',['fields'=>'id,caption,media_type,media_product_type,permalink,timestamp,like_count,comments_count','limit'=>25,'access_token'=>$token]);
   foreach(($page['data']??[]) as $m){$mid=(string)($m['id']??'');if($mid==='')continue;$metrics=[];$raw=null;try{$raw=$this->request('GET',$base.'/'.$mid.'/insights',['metric'=>'views,reach,likes,comments,shares,saved,total_interactions','access_token'=>$token]);$metrics=$this->metricData($raw);}catch(Throwable $e){$mediaErrors++;$metrics=['_error'=>$e->getMessage()];}
    $published=null;if(!empty($m['timestamp'])){$ts=strtotime((string)$m['timestamp']);if($ts)$published=date('Y-m-d H:i:s',$ts);}
    $this->db->prepare('INSERT INTO social_instagram_media_insights(account_id,external_media_id,captured_at,media_type,media_product_type,permalink,caption,published_at,metrics,raw_response) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute([$accountId,$mid,$captured,$m['media_type']??null,$m['media_product_type']??null,$m['permalink']??null,$m['caption']??null,$published,json_encode($metrics,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$raw?json_encode($raw,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null]);
    $mediaCount++;$mediaMetrics[$mid]=$metrics;$mediaRaw[$mid]=$raw;
   }
  }catch(Throwable $e){$errors[]='media_list:'.$e->getMessage();}
  $meta=json_decode((string)($a['metadata']??'{}'),true)?:[];$meta['instagram_analytics']=['last_sync'=>$captured,'account_metrics'=>array_keys($accountMetrics),'media_sample'=>$mediaCount,'errors'=>$errors];
  $this->db->prepare('UPDATE social_accounts SET metadata=?,last_sync_at=?,last_error=?,updated_at=NOW() WHERE id=?')->execute([json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$captured,$errors?mb_substr(implode(' | ',$errors),0,500):null,$accountId]);
  if($userId>0)$this->audit->log($userId,'instagram_analytics_synced','social_accounts',$accountId,$accountId,['media_sample'=>$mediaCount,'errors'=>count($errors),'media_errors'=>$mediaErrors]);
  return ['account_id'=>$accountId,'captured_at'=>$captured,'account_metrics'=>$accountMetrics,'media_sample'=>$mediaCount,'media_errors'=>$mediaErrors,'errors'=>$errors];
 }
 public function latest(int $accountId):?array{$q=$this->db->prepare('SELECT * FROM social_instagram_insights WHERE account_id=? ORDER BY captured_at DESC,id DESC LIMIT 1');$q->execute([$accountId]);$r=$q->fetch(PDO::FETCH_ASSOC);if(!$r)return null;$r['metrics']=json_decode((string)$r['metrics'],true)?:[];return $r;}
 public function topMedia(int $accountId,int $limit=20):array{$limit=max(1,min(50,$limit));$q=$this->db->prepare("SELECT * FROM social_instagram_media_insights WHERE account_id=? ORDER BY captured_at DESC,id DESC LIMIT $limit");$q->execute([$accountId]);$out=[];foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r){$r['metrics']=json_decode((string)$r['metrics'],true)?:[];$out[]=$r;}return $out;}
 public function allLatest():array{
  $q=$this->db->query('SELECT i.*,a.account_name,a.external_account_id FROM social_instagram_insights i JOIN (SELECT account_id,MAX(id) id FROM social_instagram_insights GROUP BY account_id) x ON x.id=i.id JOIN social_accounts a ON a.id=i.account_id ORDER BY a.account_name');
  $out=[];foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r){$r['metrics']=json_decode((string)$r['metrics'],true)?:[];$out[]=$r;}return $out;
 }
}
