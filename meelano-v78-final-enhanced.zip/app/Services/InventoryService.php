<?php
declare(strict_types=1);
final class InventoryService {
    private ?ReservationLedger $ledger = null;
    public function __construct(private PDO $db) { $this->ledger = class_exists('ReservationLedger') ? new ReservationLedger($db) : null; }

    public function reserve(int $productId,int $warehouseId,float $qty,?int $orderId=null,?int $variantId=null,?int $orderItemId=null):void {
        $this->runAtomically(fn()=> $this->reserveWithinTransaction($productId,$warehouseId,$qty,$orderId,$variantId,$orderItemId));
    }
    public function reserveWithinTransaction(int $productId,int $warehouseId,float $qty,?int $orderId=null,?int $variantId=null,?int $orderItemId=null):void {
        if($qty<=0) throw new InvalidArgumentException('تعداد باید بیشتر از صفر باشد.');
        $r=$this->lockRow($productId,$warehouseId,$variantId);
        $available=(float)$r['current_stock']-(float)$r['reserved_stock'];
        if($available<$qty) throw new RuntimeException('موجودی کافی نیست.');
        $this->db->prepare('UPDATE product_inventory SET reserved_stock=reserved_stock+?,updated_at=NOW() WHERE id=?')->execute([$qty,$r['id']]);
        $this->movement($productId,$variantId,$warehouseId,'adjust',$qty,'order_reserve',$orderId,'Reservation'); if($this->ledger && $orderId!==null)$this->ledger->record($orderId,$orderItemId,$productId,$variantId,$warehouseId,$qty,'reserved');
    }
    public function commit(int $productId,int $warehouseId,float $qty,?int $orderId=null,?int $variantId=null,?int $orderItemId=null):void {
        $this->runAtomically(fn()=> $this->commitWithinTransaction($productId,$warehouseId,$qty,$orderId,$variantId));
    }
    public function commitWithinTransaction(int $productId,int $warehouseId,float $qty,?int $orderId=null,?int $variantId=null,?int $orderItemId=null):void {
        if($qty<=0) throw new InvalidArgumentException('تعداد باید بیشتر از صفر باشد.');
        $r=$this->lockRow($productId,$warehouseId,$variantId);
        if((float)$r['reserved_stock']<$qty) throw new RuntimeException('موجودی رزرو شده کافی نیست.');
        $this->db->prepare('UPDATE product_inventory SET current_stock=current_stock-?,reserved_stock=reserved_stock-?,updated_at=NOW() WHERE id=?')->execute([$qty,$qty,$r['id']]);
        $this->movement($productId,$variantId,$warehouseId,'out',$qty,'order_commit',$orderId,'Reservation committed'); if($this->ledger && $orderId!==null){ if($orderItemId!==null)$this->ledger->transitionForItem($orderItemId,'reserved','committed',$qty); else $this->ledger->transitionOrder($orderId,'reserved','committed'); }
    }
    public function release(int $productId,int $warehouseId,float $qty,?int $orderId=null,?int $variantId=null,?int $orderItemId=null):void {
        $this->runAtomically(fn()=> $this->releaseWithinTransaction($productId,$warehouseId,$qty,$orderId,$variantId));
    }
    public function releaseWithinTransaction(int $productId,int $warehouseId,float $qty,?int $orderId=null,?int $variantId=null,?int $orderItemId=null):void {
        if($qty<=0) throw new InvalidArgumentException('تعداد باید بیشتر از صفر باشد.');
        $r=$this->lockRow($productId,$warehouseId,$variantId);
        $release=min($qty,(float)$r['reserved_stock']);
        if($release<=0)return;
        $this->db->prepare('UPDATE product_inventory SET reserved_stock=reserved_stock-?,updated_at=NOW() WHERE id=?')->execute([$release,$r['id']]);
        $this->movement($productId,$variantId,$warehouseId,'adjust',$release,'order_release',$orderId,'Reservation released'); if($this->ledger && $orderId!==null){ if($orderItemId!==null)$this->ledger->transitionForItem($orderItemId,'reserved','released',$release); else $this->ledger->transitionOrder($orderId,'reserved','released'); }
    }
    private function lockRow(int $productId,int $warehouseId,?int $variantId):array {
        $sql='SELECT id,current_stock,reserved_stock FROM product_inventory WHERE product_id=? AND warehouse_id=? AND '.($variantId===null?'variant_id IS NULL':'variant_id=?').' FOR UPDATE';
        $params=$variantId===null?[$productId,$warehouseId]:[$productId,$warehouseId,$variantId];
        $q=$this->db->prepare($sql);$q->execute($params);$r=$q->fetch(PDO::FETCH_ASSOC);
        if(!$r)throw new RuntimeException('رکورد موجودی پیدا نشد.');
        return $r;
    }
    private function runAtomically(callable $fn):void {
        $outer=$this->db->inTransaction(); if(!$outer)$this->db->beginTransaction();
        try{$fn();if(!$outer)$this->db->commit();}catch(Throwable $e){if(!$outer&&$this->db->inTransaction())$this->db->rollBack();throw $e;}
    }
    private function movement(int $p,?int $v,int $w,string $type,float $q,string $refType,?int $refId,?string $note):void {
        $this->db->prepare('INSERT INTO inventory_movements(product_id,variant_id,warehouse_id,movement_type,quantity,reference_type,reference_id,note) VALUES(?,?,?,?,?,?,?,?)')->execute([$p,$v,$w,$type,$q,$refType,$refId,$note]);
    }
}
