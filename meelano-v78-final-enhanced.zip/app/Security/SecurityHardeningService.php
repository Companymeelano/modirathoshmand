<?php
declare(strict_types=1);
final class SecurityHardeningService {
    public function __construct(private PDO $db, private string $root) {}
    public function audit(): array {
        $checks=[];
        $checks[]=$this->check('https',!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','HTTPS فعال است.');
        $checks[]=$this->check('session_cookie',$this->sessionCookieHardened(),'Session cookie باید HttpOnly و SameSite باشد.');
        $checks[]=$this->check('security_headers',$this->headersPresent(),'Security headers پایه باید ارسال شوند.');
        $checks[]=$this->check('app_key',(string)Env::get('APP_KEY','')!=='','APP_KEY تنظیم شده است.');
        foreach(['pdo_mysql','curl','openssl','json','mbstring'] as $ext)$checks[]=$this->check('extension_'.$ext,extension_loaded($ext),'Extension '.$ext.' موجود باشد.');
        foreach(['.env','config','app','database','storage','uploads'] as $path)$checks[]=$this->pathCheck($path);
        $checks[]=$this->check('protected_uploads',$this->fileExists('uploads/.htaccess')&&$this->fileExists('storage/.htaccess'),'Uploads و Storage از دسترسی مستقیم وب محافظت می‌شوند.');
        $ra=$this->routePermissionAudit(); $checks[]=$this->check('route_permissions',$ra['failures']===0,'Endpointهای protected باید Permission داشته باشند.');
        $ss=$this->secretScan(); $checks[]=$this->check('secret_scan',$ss['hits']===0,'Secret خام نباید داخل source باشد.');
        $checks[]=$this->check('debug_off',!in_array(strtolower((string)Env::get('APP_DEBUG','false')),['1','true','yes','on'],true),'APP_DEBUG در Production خاموش باشد.');
        $pass=count(array_filter($checks,static fn(array $c):bool=>$c['status']==='pass')); $fail=count(array_filter($checks,static fn(array $c):bool=>$c['status']==='fail')); $warn=count($checks)-$pass-$fail;
        return ['status'=>$fail===0?'pass':($pass>0?'degraded':'fail'),'score'=>$checks?round(($pass/count($checks))*100):0,'pass'=>$pass,'warn'=>$warn,'fail'=>$fail,'checks'=>$checks,'route_audit'=>$ra,'secret_scan'=>$ss];
    }
    public function persist(array $report): int {$this->db->prepare('INSERT INTO security_audit_runs(status,score,pass_count,warn_count,fail_count,report_json,created_at) VALUES(?,?,?,?,?,?,NOW())')->execute([$report['status'],(int)$report['score'],(int)$report['pass'],(int)$report['warn'],(int)$report['fail'],json_encode($report,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);return (int)$this->db->lastInsertId();}
    public function recent(int $limit=20): array {$limit=max(1,min(100,$limit));$q=$this->db->query('SELECT id,status,score,pass_count,warn_count,fail_count,created_at FROM security_audit_runs ORDER BY id DESC LIMIT '.$limit);return $q?$q->fetchAll(PDO::FETCH_ASSOC):[];}
    public function routePermissionAudit(): array {$files=glob($this->root.'/api/routes/*.php')?:[];$failures=[];$checked=0;foreach($files as $file){$text=(string)file_get_contents($file);if(preg_match_all("/case\\s+'([^']+)'\\s*:/",$text,$m))foreach($m[1] as $action){if(in_array($action,['health','csrf','login','logout'],true)||str_contains($action,'webhook')||$action==='social_media_public')continue;$checked++;$pos=strpos($text,"case '$action':");$chunk=$pos===false?'':substr($text,$pos,700);if(!str_contains($chunk,'Permission::require'))$failures[]=['action'=>$action,'file'=>basename($file)];}}return ['checked'=>$checked,'failures'=>count($failures),'items'=>$failures];}
    public function secretScan(): array {$dirs=[$this->root.'/app',$this->root.'/api',$this->root.'/config',$this->root.'/cron',$this->root.'/scripts'];$hits=[];$patterns=['/sk-[A-Za-z0-9]{20,}/','/AIza[0-9A-Za-z_-]{20,}/','/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/','/password\\s*[:=]\\s*["\'][^"\']{8,}["\']/i'];foreach($dirs as $dir)foreach($this->phpFiles($dir) as $f){$t=(string)file_get_contents($f);foreach($patterns as $p)if(preg_match($p,$t)){ $hits[]=str_replace($this->root.'/','',$f);break;}}return ['hits'=>count(array_unique($hits)),'files'=>array_values(array_unique($hits))];}
    private function headersPresent(): bool {if(function_exists('headers_list')&&in_array('X-Content-Type-Options: nosniff',headers_list(),true))return true;return isset($_SERVER['HTTP_X_CONTENT_TYPE_OPTIONS']);}
    private function sessionCookieHardened(): bool {$p=session_get_cookie_params();return (bool)($p['httponly']??false)&&(($p['samesite']??'')!=='');}
    private function pathCheck(string $rel): array{return $this->check('path_'.$rel,file_exists($this->root.'/'.$rel),$rel.' باید وجود داشته باشد.');}
    private function fileExists(string $rel): bool{return is_file($this->root.'/'.$rel);}
    private function phpFiles(string $dir): array{if(!is_dir($dir))return [];$out=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS));foreach($it as $f)if($f->isFile()&&$f->getExtension()==='php')$out[]=$f->getPathname();return $out;}
    private function check(string $id,bool $ok,string $note): array{return ['id'=>$id,'status'=>$ok?'pass':'fail','note'=>$note];}
}
