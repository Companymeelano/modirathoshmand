<?php
declare(strict_types=1);
final class ProductRepository {
 public function __construct(private PDO $db){}
 public function find(int $id):?array{$q=$this->db->prepare('SELECT * FROM products WHERE id=?');$q->execute([$id]);$r=$q->fetch(PDO::FETCH_ASSOC);return $r?:null;}
 public function variants(int $productId):array{$q=$this->db->prepare('SELECT * FROM product_variants WHERE product_id=? ORDER BY id');$q->execute([$productId]);return $q->fetchAll(PDO::FETCH_ASSOC);}
 public function search(string $term='',int $limit=50):array{$limit=max(1,min(100,$limit));$q=$this->db->prepare("SELECT id,title,slug,sku,barcode,sale_price_retail,status,featured FROM products WHERE (title LIKE ? OR sku LIKE ? OR barcode LIKE ?) ORDER BY id DESC LIMIT $limit");$like='%'.$term.'%';$q->execute([$like,$like,$like]);return $q->fetchAll(PDO::FETCH_ASSOC);}
}
