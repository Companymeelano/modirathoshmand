<?php
declare(strict_types=1);
final class RateLimiter {
    public function __construct(private PDO $db){}
    public function hit(string $key,int $limit,int $windowSeconds):bool{
        $now=time();$row=$this->db->prepare('SELECT attempts,window_started FROM rate_limit_buckets WHERE bucket_key=?');$row->execute([$key]);$r=$row->fetch(PDO::FETCH_ASSOC);
        if(!$r || $now-(int)$r['window_started'] >= $windowSeconds){$this->db->prepare('INSERT INTO rate_limit_buckets(bucket_key,attempts,window_started,updated_at) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE attempts=VALUES(attempts),window_started=VALUES(window_started),updated_at=NOW()')->execute([$key,1,$now]);return true;}
        if((int)$r['attempts'] >= $limit)return false;
        $this->db->prepare('UPDATE rate_limit_buckets SET attempts=attempts+1,updated_at=NOW() WHERE bucket_key=?')->execute([$key]);return true;
    }
}
