<?php
declare(strict_types=1);
final class Database { private static ?PDO $pdo=null; public static function pdo():PDO { if(self::$pdo)return self::$pdo; $host=getenv('DB_HOST')?:'localhost';$db=getenv('DB_NAME')?:'';$user=getenv('DB_USER')?:'';$pass=getenv('DB_PASS')?:''; if($db==='') throw new RuntimeException('Database is not configured'); self::$pdo=new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);return self::$pdo;}}
