<?php
declare(strict_types=1);
final class Audit { public function __construct(private PDO $db){} public function log(?int $userId,string $action,string $module,?string $entityType=null,?int $entityId=null,array $meta=[]):void{$s=$this->db->prepare("INSERT INTO audit_logs(user_id,action,module,entity_type,entity_id,metadata,created_at) VALUES(?,?,?,?,?,?,NOW())");$s->execute([$userId,$action,$module,$entityType,$entityId,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);} }
