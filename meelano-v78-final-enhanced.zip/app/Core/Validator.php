<?php
declare(strict_types=1);
final class Validator { public static function required(array $data,array $fields):array{$e=[];foreach($fields as $f){if(!isset($data[$f])||$data[$f]==='')$e[$f]='required';}return $e;} public static function int($v):?int{return filter_var($v,FILTER_VALIDATE_INT)!==false?(int)$v:null;} public static function money($v):?float{return is_numeric($v)?round((float)$v,2):null;} }
