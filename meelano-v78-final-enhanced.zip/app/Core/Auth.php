<?php
declare(strict_types=1);
final class Auth {
    public static function user():?array{return $_SESSION['user']??null;}
    public static function requireLogin():array{$u=self::user();if(!$u)Response::error('ورود به سامانه الزامی است.','AUTH_REQUIRED',401);return $u;}
    public static function login(array $u):void{session_regenerate_id(true);$_SESSION['user']=$u;$_SESSION['login_at']=time();}
    public static function logout():void{$_SESSION=[];if(ini_get('session.use_cookies')){setcookie(session_name(),'',time()-42000,['path'=>'/','httponly'=>true,'secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'samesite'=>'Lax']);}session_destroy();}
}
