<?php
declare(strict_types=1);
final class Autoloader {
    private static array $map = [];
    private static bool $registered = false;
    public static function register(string $root): void {
        if (self::$registered) return;
        self::$registered = true;
        foreach (self::phpFiles($root) as $file) {
            $class = basename($file, '.php');
            if (isset(self::$map[$class]) && self::$map[$class] !== $file) {
                throw new RuntimeException('Duplicate autoload class: '.$class);
            }
            self::$map[$class] = $file;
        }
        spl_autoload_register(static function(string $class): void {
            if (isset(self::$map[$class])) require_once self::$map[$class];
        }, true, true);
    }
    private static function phpFiles(string $root): array {
        $out=[];
        $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach($it as $f) if($f->isFile() && strtolower($f->getExtension())==='php') $out[]=$f->getPathname();
        sort($out,SORT_STRING);
        return $out;
    }
}
