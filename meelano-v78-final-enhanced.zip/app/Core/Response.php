<?php
declare(strict_types=1);
final class Response {
 public static function json(array $data,int $status=200):never { http_response_code($status); $rid=$_SERVER['REQUEST_ID']??bin2hex(random_bytes(16)); header('Content-Type: application/json; charset=utf-8'); header('X-Request-ID',$rid); $data['request_id']=$rid; echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
 public static function ok(mixed $data=null,array $meta=[]):never{self::json(['status'=>'success','data'=>$data,'meta'=>$meta]);}
 public static function error(string $message,string $code='ERROR',int $status=400):never{self::json(['status'=>'error','message'=>$message,'code'=>$code],$status);}
}
