<?php
declare(strict_types=1);
final class Container {
    private array $bindings = [];
    private array $instances = [];
    private array $resolving = [];
    public function __construct(array $bindings = []) { $this->bindings = $bindings; }
    public function singleton(string $id, callable $factory): void { $this->bindings[$id] = ['factory'=>$factory,'singleton'=>true]; }
    public function bind(string $id, callable $factory, bool $singleton=false): void { $this->bindings[$id] = ['factory'=>$factory,'singleton'=>$singleton]; }
    public function instance(string $id, mixed $value): void { $this->instances[$id] = $value; }
    public function has(string $id): bool { return isset($this->bindings[$id]) || array_key_exists($id,$this->instances); }
    public function make(string $id): mixed {
        if (array_key_exists($id, $this->instances)) return $this->instances[$id];
        if (isset($this->resolving[$id])) {
            $chain = implode(' -> ', array_keys($this->resolving));
            throw new RuntimeException('Circular dependency detected: '.$chain.' -> '.$id);
        }
        $this->resolving[$id] = true;
        try {
            if (isset($this->bindings[$id])) {
                $v = ($this->bindings[$id]['factory'])($this);
                if ($this->bindings[$id]['singleton']) $this->instances[$id] = $v;
                return $v;
            }
            if (!class_exists($id)) throw new RuntimeException('Container cannot resolve '.$id);
            $r = new ReflectionClass($id);
            if (!$r->isInstantiable()) throw new RuntimeException('Container cannot instantiate '.$id);
            $ctor = $r->getConstructor();
            if ($ctor === null) return new $id();
            $args=[];
            foreach ($ctor->getParameters() as $p) {
                $t=$p->getType();
                if ($t instanceof ReflectionNamedType && !$t->isBuiltin()) {
                    $args[]=$this->make($t->getName());
                } elseif ($p->isDefaultValueAvailable()) {
                    $args[]=$p->getDefaultValue();
                } else {
                    throw new RuntimeException('Unresolvable dependency '.$p->getName().' for '.$id);
                }
            }
            return $r->newInstanceArgs($args);
        } finally { unset($this->resolving[$id]); }
    }
}
