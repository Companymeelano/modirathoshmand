<?php
declare(strict_types=1);
final class ProductController {public function __construct(private ProductRepository $repo){} public function show(int $id):array{$p=$this->repo->find($id);if(!$p)throw new RuntimeException('محصول یافت نشد.');$p['variants']=$this->repo->variants($id);return $p;} public function search(string $q,int $limit=50):array{return $this->repo->search($q,$limit);}}
