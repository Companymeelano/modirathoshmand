<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
if(empty($_SESSION['csrf_token']))$_SESSION['csrf_token']=bin2hex(random_bytes(32));
$pdo=Database::pdo();$action=Request::str('action');
try{
 if($action==='social_media_public') {
 $assetId=(int)($_GET['asset_id']??0);$exp=(int)($_GET['expires']??0);$sig=(string)($_GET['sig']??'');$key=(string)Env::get('APP_KEY','');
 if($assetId<1||$exp<time()||$key===''||!hash_equals(hash_hmac('sha256',$assetId.'|'.$exp,$key),$sig)){http_response_code(403);exit;}
 $q=$pdo->prepare('SELECT relative_path,mime_type,file_size,status FROM social_media_assets WHERE id=? LIMIT 1');$q->execute([$assetId]);$a=$q->fetch(PDO::FETCH_ASSOC);$root=dirname(__DIR__);$path=$root.'/'.ltrim((string)($a['relative_path']??''),'/');
 if(!$a||$a['status']!=='ready'||!is_file($path)){http_response_code(404);exit;}
 header('Content-Type: '.($a['mime_type']?:'application/octet-stream'));header('Content-Length: '.(int)$a['file_size']);header('Cache-Control: public,max-age=300');readfile($path);exit;
}
if(in_array($action,['health','csrf','login','social_tiktok_webhook'],true)){
   // CSRF is intentionally skipped for the bootstrap endpoints; all state-changing authenticated endpoints below require it.
 } else Request::csrf();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !in_array($action,['login','social_tiktok_webhook'],true) && Auth::user()) { $ip=(string)($_SERVER['REMOTE_ADDR']??'unknown'); if (!$container->make(RateLimiter::class)->hit('api:'.hash('sha256',$ip.'|'.$action),60,60)) Response::error('تعداد درخواست‌ها بیش از حد مجاز است.','RATE_LIMITED',429); }

 $route_not_handled=false;
 $routeFile=null;
 if ($action==='health'||$action==='csrf'||$action==='login'||$action==='logout'||$action==='system_status'||$action==='ai_run'||$action==='ai_provider_test'||$action==='ai_provider_secret'||$action==='ai_copilot'||$action==='ai_cost_report'||$action==='social_publish_rollback'||str_starts_with($action,'system_incident') || str_starts_with($action,'system_security') || str_starts_with($action,'system_performance') || str_starts_with($action,'system_database_intelligence') || str_starts_with($action,'system_cache') || str_starts_with($action,'system_queue') || str_starts_with($action,'system_autonomy') || str_starts_with($action,'system_brain')) $routeFile=__DIR__.'/routes/system.php';
 elseif (str_starts_with($action,'ai_social_video') || $action==='identity_manual_review') $routeFile=__DIR__.'/routes/ai_video.php';
 elseif (str_starts_with($action,'product_ad_') || str_starts_with($action,'ai_media_') || str_starts_with($action,'media_')) $routeFile=__DIR__.'/routes/ai_image.php';
 elseif (str_starts_with($action,'ai_content_') || str_starts_with($action,'ai_campaign') || str_starts_with($action,'ai_creative') || str_starts_with($action,'social_content_brief')) $routeFile=__DIR__.'/routes/ai_content.php';
 elseif ($action==='social_publish_rollback_run' || $action==='social_publish_rollback_get' || str_starts_with($action,'social_') || str_starts_with($action,'linkedin_') || $action==='instagram_analytics' || $action==='instagram_analytics_sync') $routeFile=__DIR__.'/routes/social.php';
 else $routeFile=__DIR__.'/routes/commerce.php';
 require $routeFile;
 if($route_not_handled) Response::error('Endpoint پیدا نشد.','NOT_FOUND',404);
}catch(Throwable $e){
 error_log('[MeeLano]['.date('c').']['.(string)($_SERVER['REQUEST_ID']??'n/a').'] '.get_class($e).': '.$e->getMessage());
 if($e instanceof DomainException) Response::error($e->getMessage(),'VALIDATION',422);
 if($e instanceof InvalidArgumentException) Response::error($e->getMessage(),'VALIDATION',422);
 if($e instanceof PDOException) Response::error('خطای پایگاه داده رخ داد.','DATABASE_ERROR',500);
 Response::error('عملیات انجام نشد.','INTERNAL_ERROR',500);
}
