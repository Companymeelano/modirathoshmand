<?php
declare(strict_types=1);
if (empty($_SERVER['REQUEST_ID'])) { $_SERVER['REQUEST_ID'] = bin2hex(random_bytes(16)); }

$__secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
header('Cross-Origin-Opener-Policy: same-origin');
if ($__secure) header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
require_once __DIR__.'/../app/Core/Autoloader.php';
Autoloader::register(__DIR__.'/../app');
Env::load(dirname(__DIR__).'/.env');
$container = new Container();
$container->singleton(PDO::class, static fn() => Database::pdo());
$container->singleton(Audit::class, static fn(Container $c) => new Audit($c->make(PDO::class)));
$container->singleton(SocialHttp::class, static fn() => new SocialHttp());
$container->singleton(Validator::class, static fn() => new Validator());
$container->singleton(RateLimiter::class, static fn(Container $c) => new RateLimiter($c->make(PDO::class)));
$container->singleton(SecurityHardeningService::class, static fn(Container $c) => new SecurityHardeningService($c->make(PDO::class), dirname(__DIR__)));
$container->singleton(DeploymentSafetyService::class, static fn(Container $c) => new DeploymentSafetyService($c->make(PDO::class), __DIR__.'/../database/migrations'));
$container->singleton(ProductionObservabilityService::class, static fn(Container $c) => new ProductionObservabilityService($c->make(PDO::class)));
$container->singleton(PerformanceMetricsService::class, static fn(Container $c) => new PerformanceMetricsService($c->make(PDO::class)));
$container->singleton(DatabaseIntelligenceService::class, static fn(Container $c) => new DatabaseIntelligenceService($c->make(PDO::class)));
$container->singleton(CacheService::class, static fn() => new CacheService());
$container->singleton(IntelligentCacheService::class, static fn(Container $c) => new IntelligentCacheService($c->make(CacheService::class), $c->make(PDO::class)));
$container->singleton(QueryCacheService::class, static fn(Container $c) => new QueryCacheService($c->make(PDO::class), $c->make(IntelligentCacheService::class)));
$container->singleton(CacheInvalidationService::class, static fn(Container $c) => new CacheInvalidationService($c->make(IntelligentCacheService::class), $c->make(PDO::class)));
$container->singleton(CacheObservabilityService::class, static fn(Container $c) => new CacheObservabilityService($c->make(PDO::class)));
$container->singleton(AdaptiveIndexPlannerService::class, static fn(Container $c) => new AdaptiveIndexPlannerService($c->make(PDO::class), $c->make(QueryCacheService::class)));
$container->singleton(QueueRecoveryPlannerService::class, static fn(Container $c) => new QueueRecoveryPlannerService($c->make(PDO::class)));
$container->singleton(QueueOptimizationService::class, static fn(Container $c) => new QueueOptimizationService($c->make(PDO::class)));
$container->singleton(AssetPerformanceService::class, static fn() => new AssetPerformanceService(dirname(__DIR__)));
$container->singleton(AutonomousPerformanceService::class, static fn(Container $c) => new AutonomousPerformanceService($c->make(PDO::class), $c->make(ProductionObservabilityService::class), $c->make(CacheObservabilityService::class), $c->make(AdaptiveIndexPlannerService::class), $c->make(QueueOptimizationService::class), $c->make(QueueRecoveryPlannerService::class), $c->make(IncidentRecoveryCenterService::class)));
$container->singleton(UnifiedSystemBrainService::class, static fn(Container $c) => new UnifiedSystemBrainService($c->make(PDO::class), $c->make(AutonomousPerformanceService::class), $c->make(SecurityHardeningService::class), $c->make(DeploymentSafetyService::class), $c->make(DisasterRecoveryService::class), $c->make(IncidentRecoveryCenterService::class)));
$__perf_start=microtime(true);
register_shutdown_function(static function() use ($container, $__perf_start): void { try { $container->make(PerformanceMetricsService::class)->record(['request_id'=>$_SERVER['REQUEST_ID']??'', 'action'=>$_GET['action']??$_POST['action']??'', 'http_method'=>$_SERVER['REQUEST_METHOD']??'CLI', 'http_status'=>http_response_code() ?: 200, 'duration_ms'=>(microtime(true)-$__perf_start)*1000, 'memory_peak_bytes'=>memory_get_peak_usage(true), 'source'=>PHP_SAPI==='cli'?'cli':'http']); } catch(Throwable) {} });
if (session_status() !== PHP_SESSION_ACTIVE) { session_name(getenv('SESSION_NAME') ?: 'MEELANOSESSID'); ini_set('session.use_strict_mode','1'); ini_set('session.use_only_cookies','1'); ini_set('session.cookie_httponly','1'); ini_set('session.cookie_samesite','Lax'); session_set_cookie_params(['httponly'=>true,'secure'=>$__secure,'samesite'=>'Lax','path'=>'/']); session_start(); }
