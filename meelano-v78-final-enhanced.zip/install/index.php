<?php
declare(strict_types=1);
require __DIR__.'/../config/bootstrap.php';
if (is_file(__DIR__.'/../storage/.installed')) { http_response_code(410); exit('MeeLano is already installed.'); }
if (empty($_SESSION['installer_nonce'])) $_SESSION['installer_nonce']=bin2hex(random_bytes(24));
$ok=false; $message='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        if (!hash_equals((string)$_SESSION['installer_nonce'], (string)($_POST['nonce']??''))) throw new RuntimeException('INSTALLER_CSRF');
        $pdo=Database::pdo();
        $svc=new DeploymentSafetyService($pdo,__DIR__.'/../database/migrations');
        $pre=$svc->preflight();
        if(!$pre['ok']) throw new RuntimeException('INSTALLER_PREFLIGHT_FAILED');
        $runner=new MigrationRunner($pdo,__DIR__.'/../database/migrations');
        $done=$runner->run();
        file_put_contents(__DIR__.'/../storage/.installed',date('c'),LOCK_EX);
        $ok=true; $message='Installation completed: '.count($done).' migrations applied.';
    } catch(Throwable $e) { $message='Installation could not be completed. Check server configuration and logs.'; error_log('MeeLano installer: '.get_class($e).': '.$e->getMessage()); }
}
?><!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MeeLano Installer</title><style>body{font-family:system-ui;max-width:720px;margin:10vh auto;padding:24px;background:#111;color:#eee}button{padding:12px 20px;border:0;border-radius:10px}code{background:#222;padding:3px 6px}p{line-height:1.8}</style><h1>MeeLano Installer</h1><p>نصب‌کننده امن MeeLano تنظیمات <code>.env</code> را بررسی کرده و Migrationها را با قفل Upgrade اجرا می‌کند.</p><?php if($message):?><p><?=htmlspecialchars($message,ENT_QUOTES,'UTF-8')?></p><?php endif;?><?php if(!$ok):?><form method="post"><input type="hidden" name="nonce" value="<?=htmlspecialchars($_SESSION['installer_nonce'],ENT_QUOTES,'UTF-8')?>"><button>اجرای نصب امن</button></form><?php else:?><p>نصب با موفقیت انجام شد. دسترسی وب به پوشه <code>/install</code> مسدود است.</p><?php endif;?></html>
